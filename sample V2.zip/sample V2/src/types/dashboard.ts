export interface MetricStats {
  totalTickets: number;
  activeAgents: number;
  totalCasesProcessed: number;
  failedCases: number;
}

export type AgentStatus = 'active' | 'inactive';

export interface AgentRun {
  id: string;
  name: string;
  date: string;
  lastRunAgo: string;
  status: AgentStatus;
}

export type TicketStatus = 'resolved' | 'processing' | 'failed';

export interface TicketMapping {
  id: string;
  ticketNo: string;
  agentName: string;
  agentId: string;
  status: TicketStatus;
}

export interface CaseWorked {
  id: string;
  count: number;
  agentName: string;
}

export interface AvailableAgent {
  id: string;
  name: string;
}

export interface Incident {
  id: string;
  agentName: string;
  caseNumber: string;
}

export interface DashboardData {
  metrics: MetricStats;
  agentRuns: AgentRun[];
  ticketMappings: TicketMapping[];
  casesWorked: CaseWorked[];
  availableAgents: AvailableAgent[];
  incidents: Incident[];
}
