import type { AgentStatus } from './dashboard';

export type LogType = 'info' | 'error' | 'warning';

export interface AgentLog {
  id: string;
  timestamp: string;
  record: string;
  type: LogType;
}

export interface TokenDataPoint {
  platform: string;
  value: number;
}

export interface TimeDataPoint {
  month: string;
  value: number;
}

export interface AgentDetailMetrics {
  warnings: number;
  errors: number;
  aiChatRequests: number;
  avgLatencyMs: number;
  costUsd: number;
  cpuUsage: number;
  memoryUsage: number;
  accuracyScore: number;
  processingTime1: number;
  processingTime2: number;
  processingTime3: number;
  messagesPerTask: number;
  tasksCompleted: number;
}

export interface AgentDetails {
  id: string;
  name: string;
  status: AgentStatus;
  metrics: AgentDetailMetrics;
  logs: AgentLog[];
  inputTokensData: TokenDataPoint[];
  outputTokensData: TimeDataPoint[];
}
