import type { FC } from 'react';
import type { TicketMapping, TicketStatus } from '../../types/dashboard';
import { DataTable, type TableColumn } from '../common/DataTable';

const STATUS_LABELS: Record<TicketStatus, string> = {
  resolved: 'RESOLVED',
  processing: 'PROCESSING',
  failed: 'FAILED',
};

const COLUMNS: TableColumn<TicketMapping>[] = [
  {
    key: 'ticketNo',
    label: 'Ticket No',
    clickable: true,
    render: row => row.ticketNo,
  },
  {
    key: 'agentName',
    label: 'Agent Name',
    clickable: true,
    render: row => row.agentName,
  },
  {
    key: 'status',
    label: 'Status',
    render: row => (
      <span className={`dt-badge dt-badge--${row.status}`}>
        {STATUS_LABELS[row.status]}
      </span>
    ),
  },
];

interface TicketAgentMappingProps {
  tickets: TicketMapping[];
  onTicketClick?: (ticket: TicketMapping) => void;
}

export const TicketAgentMapping: FC<TicketAgentMappingProps> = ({ tickets, onTicketClick }) => (
  <DataTable columns={COLUMNS} data={tickets} onRowClick={onTicketClick} />
);
