import { useState, useRef, useEffect } from 'react';
import { UserPlus } from 'lucide-react';
import { Modal } from './Modal';
import { Button } from './Button';
import './OnboardingModal.css';

interface OnboardingModalProps {
  isOpen: boolean;
  onClose: () => void;
  onCreate: (name: string) => Promise<void>;
}

export function OnboardingModal({ isOpen, onClose, onCreate }: OnboardingModalProps) {
  const [name,    setName]    = useState('');
  const [loading, setLoading] = useState(false);
  const [error,   setError]   = useState('');
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isOpen) {
      setName('');
      setError('');
      setLoading(false);
      setTimeout(() => inputRef.current?.focus(), 80);
    }
  }, [isOpen]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = name.trim();
    if (!trimmed) { setError('Agent name is required.'); return; }
    setError('');
    setLoading(true);
    try {
      await onCreate(trimmed);
      onClose();
    } catch {
      setError('Failed to create agent. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose}>
      <div className="ob-modal">
        <div className="ob-modal-header">
          <span className="ob-modal-icon"><UserPlus size={20} /></span>
          <div>
            <h2 className="ob-modal-title">Onboarding New Agent</h2>
            <p className="ob-modal-sub">Add a new agent to the platform</p>
          </div>
        </div>

        <form className="ob-modal-form" onSubmit={handleSubmit} noValidate>
          <div className="ob-field">
            <label className="ob-label" htmlFor="agent-name">Agent Name</label>
            <input
              ref={inputRef}
              id="agent-name"
              className={`ob-input${error ? ' ob-input--error' : ''}`}
              type="text"
              value={name}
              onChange={e => { setName(e.target.value); setError(''); }}
              placeholder="e.g. CCSY_GENAI-API-Gateway"
              autoComplete="off"
              disabled={loading}
            />
            {error && <p className="ob-error">{error}</p>}
          </div>

          <div className="ob-modal-actions">
            <Button variant="secondary" type="button" onClick={onClose} disabled={loading}>
              Cancel
            </Button>
            <Button variant="primary" type="submit" loading={loading}>
              Create New Agent
            </Button>
          </div>
        </form>
      </div>
    </Modal>
  );
}
