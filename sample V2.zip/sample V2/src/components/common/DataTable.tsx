import { useState } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import type { ReactNode } from 'react';
import './DataTable.css';

export interface TableColumn<T> {
  key: string;
  label: string;
  render: (row: T) => ReactNode;
  clickable?: boolean;
  className?: string;
}

interface DataTableProps<T extends { id: string }> {
  columns: TableColumn<T>[];
  data: T[];
  pageSize?: number;
  emptyText?: string;
  onRowClick?: (row: T) => void;
}

export function DataTable<T extends { id: string }>({
  columns,
  data,
  pageSize,
  emptyText = 'No data available.',
  onRowClick,
}: DataTableProps<T>) {
  const [page, setPage] = useState(1);

  const totalPages = pageSize ? Math.max(1, Math.ceil(data.length / pageSize)) : 1;
  const slice = pageSize ? data.slice((page - 1) * pageSize, page * pageSize) : data;

  const pageNumbers = Array.from({ length: totalPages }, (_, i) => i + 1);

  return (
    <div className="dt-wrapper">
      <div className="dt-scroll">
        <table className="dt-table">
          <thead>
            <tr>
              {columns.map(col => (
                <th key={col.key} className={col.className ?? ''}>{col.label}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {slice.length === 0 ? (
              <tr>
                <td colSpan={columns.length} className="dt-empty">{emptyText}</td>
              </tr>
            ) : (
              slice.map(row => (
                <tr
                  key={row.id}
                  onClick={onRowClick ? () => onRowClick(row) : undefined}
                  style={onRowClick ? { cursor: 'pointer' } : undefined}
                >
                  {columns.map(col => (
                    <td
                      key={col.key}
                      className={[
                        col.clickable ? 'dt-cell--clickable' : '',
                        col.className ?? '',
                      ].filter(Boolean).join(' ')}
                    >
                      {col.render(row)}
                    </td>
                  ))}
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {pageSize && totalPages > 1 && (
        <div className="dt-pagination">
          <button
            className="dt-page-btn dt-page-btn--nav"
            onClick={() => setPage(p => p - 1)}
            disabled={page === 1}
            aria-label="Previous page"
          >
            <ChevronLeft size={14} />
          </button>

          {pageNumbers.map(n => (
            <button
              key={n}
              className={`dt-page-btn${n === page ? ' dt-page-btn--active' : ''}`}
              onClick={() => setPage(n)}
            >
              {n}
            </button>
          ))}

          <button
            className="dt-page-btn dt-page-btn--nav"
            onClick={() => setPage(p => p + 1)}
            disabled={page === totalPages}
            aria-label="Next page"
          >
            <ChevronRight size={14} />
          </button>

          <span className="dt-page-info">
            {(page - 1) * pageSize + 1}–{Math.min(page * pageSize, data.length)} of {data.length}
          </span>
        </div>
      )}
    </div>
  );
}
