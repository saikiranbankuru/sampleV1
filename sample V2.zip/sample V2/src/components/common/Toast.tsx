import { useEffect, useState } from 'react';
import { createPortal } from 'react-dom';
import { CheckCircle, X, AlertCircle } from 'lucide-react';
import './Toast.css';

export type ToastType = 'success' | 'error';

interface ToastProps {
  message: string;
  type?: ToastType;
  duration?: number;
  onDismiss: () => void;
}

export function Toast({ message, type = 'success', duration = 3000, onDismiss }: ToastProps) {
  const [visible, setVisible] = useState(true);

  useEffect(() => {
    const t = setTimeout(() => setVisible(false), duration - 300);
    const u = setTimeout(onDismiss, duration);
    return () => { clearTimeout(t); clearTimeout(u); };
  }, [duration, onDismiss]);

  const Icon = type === 'success' ? CheckCircle : AlertCircle;

  return createPortal(
    <div className={`toast toast--${type}${visible ? ' toast--in' : ' toast--out'}`} role="status">
      <Icon size={16} className="toast-icon" />
      <span className="toast-msg">{message}</span>
      <button className="toast-close" onClick={() => { setVisible(false); onDismiss(); }} aria-label="Dismiss">
        <X size={13} />
      </button>
    </div>,
    document.body,
  );
}

/* ── useToast hook ── */
export interface ToastState {
  id: number;
  message: string;
  type: ToastType;
}

let _counter = 0;

export function useToast() {
  const [toasts, setToasts] = useState<ToastState[]>([]);

  const show = (message: string, type: ToastType = 'success') => {
    const id = ++_counter;
    setToasts(prev => [...prev, { id, message, type }]);
  };

  const dismiss = (id: number) =>
    setToasts(prev => prev.filter(t => t.id !== id));

  const ToastContainer = () => (
    <>
      {toasts.map(t => (
        <Toast key={t.id} message={t.message} type={t.type} onDismiss={() => dismiss(t.id)} />
      ))}
    </>
  );

  return { show, ToastContainer };
}
