import { useRef } from 'react';
import { Search, X } from 'lucide-react';
import './SearchInput.css';

interface SearchInputProps {
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  className?: string;
}

export function SearchInput({
  value,
  onChange,
  placeholder = 'Search…',
  className = '',
}: SearchInputProps) {
  const inputRef = useRef<HTMLInputElement>(null);

  return (
    <div className={`si-wrap ${className}`.trim()} onClick={() => inputRef.current?.focus()}>
      <Search size={14} className="si-icon" />
      <input
        ref={inputRef}
        className="si-input"
        type="text"
        value={value}
        onChange={e => onChange(e.target.value)}
        placeholder={placeholder}
        autoComplete="off"
        spellCheck={false}
      />
      {value && (
        <button
          className="si-clear"
          onClick={e => { e.stopPropagation(); onChange(''); inputRef.current?.focus(); }}
          aria-label="Clear search"
          tabIndex={-1}
        >
          <X size={12} />
        </button>
      )}
    </div>
  );
}
