import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ChevronLeft, RefreshCw } from 'lucide-react';
import { DataTable, type TableColumn } from '../../components/common/DataTable';
import { fetchAllTickets } from '../../services/dashboardApi';
import type { TicketMapping, TicketStatus } from '../../types/dashboard';
import './TicketListPage.css';

const STATUS_LABELS: Record<TicketStatus, string> = {
  resolved: 'RESOLVED',
  processing: 'PROCESSING',
  failed: 'FAILED',
};

const COLUMNS: TableColumn<TicketMapping>[] = [
  {
    key: 'ticketNo',
    label: 'Ticket No',
    clickable: true,
    render: row => row.ticketNo,
  },
  {
    key: 'agentName',
    label: 'Agent Name',
    clickable: true,
    render: row => row.agentName,
  },
  {
    key: 'status',
    label: 'Status',
    render: row => (
      <span className={`dt-badge dt-badge--${row.status}`}>
        {STATUS_LABELS[row.status]}
      </span>
    ),
  },
];

const PAGE_SIZE = 10;

export default function TicketListPage() {
  const navigate = useNavigate();
  const [tickets, setTickets] = useState<TicketMapping[]>([]);
  const [loading, setLoading] = useState(true);
  const [spinning, setSpinning] = useState(false);

  const load = async () => {
    setSpinning(true);
    try {
      const data = await fetchAllTickets();
      setTickets(data);
    } finally {
      setLoading(false);
      setSpinning(false);
    }
  };

  useEffect(() => { load(); }, []); // eslint-disable-line react-hooks/exhaustive-deps

  return (
    <div className="tl-page">
      <div className="tl-header">
        <div className="tl-breadcrumb">
          <span className="tl-breadcrumb-link" onClick={() => navigate('/home')}>Home</span>
          <span className="tl-breadcrumb-sep">&rsaquo;</span>
          <span className="tl-breadcrumb-current">Ticket List</span>
        </div>

        <div className="tl-actions">
          <button className="tl-back-btn" onClick={() => navigate('/home')}>
            <ChevronLeft size={14} />
            Back
          </button>
          <button
            className={`tl-refresh-btn${spinning ? ' tl-refresh-btn--spinning' : ''}`}
            onClick={load}
            title="Refresh"
          >
            <RefreshCw size={14} />
            Refresh
          </button>
        </div>
      </div>
      
      <div className="tl-title-row">
        <h1 className="tl-title">Ticket to Agent Mapping</h1>
        <span className="tl-count">{loading ? '—' : `${tickets.length} tickets`}</span>
      </div>

      <div className="tl-card">
        <div className="tl-filter-row">
          <div className="tl-search-wrap">
            <svg className="tl-search-icon" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <circle cx="11" cy="11" r="8" /><line x1="21" y1="21" x2="16.65" y2="16.65" />
            </svg>
            <span className="tl-search-placeholder">Search tickets…</span>
          </div>
        </div>

        {loading ? (
          <div className="tl-skeleton-wrap">
            {[...Array(PAGE_SIZE)].map((_, i) => (
              <div key={i} className="tl-skeleton-row" />
            ))}
          </div>
        ) : (
          <DataTable
            columns={COLUMNS}
            data={tickets}
            pageSize={PAGE_SIZE}
            emptyText="No tickets found."
            onRowClick={ticket => navigate(`/tickets/${ticket.id}`)}
          />
        )}
      </div>
    </div>
  );
}
