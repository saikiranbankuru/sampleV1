import { useEffect, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { TimeRangePicker } from '../../components/common/TimeRangePicker';
import { DataTable, type TableColumn } from '../../components/common/DataTable';
import { LokiQueryAccordion } from '../../components/dashboard/LokiQueryAccordion';
import { fetchAllTickets } from '../../services/dashboardApi';
import type { TicketMapping, TicketStatus } from '../../types/dashboard';
import './TicketAgentMappingEditPage.css';

const STATUS_LABELS: Record<TicketStatus, string> = {
  resolved:   'RESOLVED',
  processing: 'PROCESSING',
  failed:     'FAILED',
};

const COLUMNS: TableColumn<TicketMapping>[] = [
  { key: 'ticketNo',  label: 'Ticket No',   render: row => row.ticketNo  },
  { key: 'agentName', label: 'Agent Name',   render: row => row.agentName },
  {
    key: 'status',
    label: 'Status',
    render: row => (
      <span className={`dt-badge dt-badge--${row.status}`}>
        {STATUS_LABELS[row.status]}
      </span>
    ),
  },
];

interface QueryItem {
  id: string;
  name: string;
  datasource: string;
}

export default function TicketAgentMappingEditPage() {
  const navigate = useNavigate();
  const [tickets, setTickets] = useState<TicketMapping[]>([]);
  const [timeRange, setTimeRange] = useState('Last 5 Minutes');
  const [activeTab, setActiveTab] = useState<'queries' | 'transformations'>('queries');
  const [queries, setQueries] = useState<QueryItem[]>([
    { id: 'q1', name: 'A', datasource: 'Prometheus' },
  ]);
  const queryIdRef = useRef(1);

  useEffect(() => {
    fetchAllTickets().then(setTickets);
  }, []);

  const renameQuery = (id: string, newName: string) => {
    setQueries(prev => prev.map(q => q.id === id ? { ...q, name: newName } : q));
  };

  const addQuery = () => {
    setQueries(prev => {
      queryIdRef.current += 1;
      const name = String.fromCharCode(65 + prev.length); // A=65, B=66, …
      return [
        ...prev,
        { id: `q${queryIdRef.current}`, name, datasource: 'Prometheus' },
      ];
    });
  };

  const duplicateQuery = (id: string) => {
    setQueries(prev => {
      const source = prev.find(q => q.id === id);
      if (!source) return prev;
      queryIdRef.current += 1;
      const name = String.fromCharCode(65 + prev.length);
      return [...prev, { id: `q${queryIdRef.current}`, name, datasource: source.datasource }];
    });
  };

  const deleteQuery = (id: string) => {
    setQueries(prev => prev.filter(q => q.id !== id));
  };

  return (
    <div className="tame-page">
      {/* ── Page header ── */}
      <div className="tame-header">
        <nav className="tame-breadcrumb" aria-label="breadcrumb">
          <button className="tame-breadcrumb-link" onClick={() => navigate('/home')}>
            Home
          </button>
          <span className="tame-breadcrumb-sep">&rsaquo;</span>
          <button className="tame-breadcrumb-link" onClick={() => navigate('/home')}>
            Dashboard
          </button>
          <span className="tame-breadcrumb-sep">&rsaquo;</span>
          <span className="tame-breadcrumb-current">Edit Ticket to Agent Mapping</span>
        </nav>

        <div className="tame-controls">
          <TimeRangePicker
            value={timeRange}
            onApply={r => setTimeRange(r.preset ?? 'Custom Range')}
          />
        </div>
      </div>

      {/* ── Section 1: Ticket List ── */}
      <div className="tame-section">
        <h2 className="tame-section-title">Ticket to Agent Mapping</h2>
        <DataTable columns={COLUMNS} data={tickets} pageSize={8} />
      </div>

      {/* ── Section 2: Tab Panel ── */}
      <div className="tame-section">
        {/* Tab headers */}
        <div className="tame-tabs-header" role="tablist">
          <button
            role="tab"
            aria-selected={activeTab === 'queries'}
            className={`tame-tab${activeTab === 'queries' ? ' tame-tab--active' : ''}`}
            onClick={() => setActiveTab('queries')}
          >
            Queries
            <span className="tame-tab-badge">{queries.length}</span>
          </button>
          <button
            role="tab"
            aria-selected={activeTab === 'transformations'}
            className={`tame-tab${activeTab === 'transformations' ? ' tame-tab--active' : ''}`}
            onClick={() => setActiveTab('transformations')}
          >
            Transformations
            <span className="tame-tab-badge tame-tab-badge--neutral">5</span>
          </button>
        </div>

        {/* Tab content */}
        <div className="tame-tab-content" role="tabpanel">
          {activeTab === 'queries' ? (
            <div className="tame-queries-tab">
              <div className="tame-query-list">
                {queries.map(q => (
                  <LokiQueryAccordion
                    key={q.id}
                    id={q.id}
                    name={q.name}
                    datasource={q.datasource}
                    onRename={renameQuery}
                    onDuplicate={duplicateQuery}
                    onDelete={deleteQuery}
                  />
                ))}
              </div>

              <div className="tame-query-actions">
                <button className="tame-action-btn" onClick={addQuery}>
                  Add Query
                </button>
                <button className="tame-action-btn">Expression</button>
              </div>
            </div>
          ) : (
            <div className="tame-transformations-tab" aria-label="Transformations — coming soon" />
          )}
        </div>
      </div>
    </div>
  );
}
