import { lazy, Suspense } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import Login from '@/pages/auth/Login';
import AppShell from '@/components/layout/AppShell';
import HomePage from '@/pages/home/HomePage';
import PlaceholderPage from '@/pages/common/PlaceholderPage';
import PluginsDataPage from '@/pages/admin/PluginsDataPage';
import CorrelationsPage from '@/pages/admin/CorrelationsPage';
import DashboardsPage from '@/pages/dashboards/DashboardsPage';
import ExplorePage from '@/pages/explore/ExplorePage';
import TicketListPage from '@/pages/tickets/TicketListPage';
import TicketAgentMappingEditPage from '@/pages/home/TicketAgentMappingEditPage';

const AgentDetailsPage       = lazy(() => import('@/pages/agents/AgentDetailsPage'));
const TicketDetailsPage      = lazy(() => import('@/pages/tickets/TicketDetailsPage'));
const AvailableAgentsPage    = lazy(() => import('@/pages/available-agents/AvailableAgentsPage'));

export default function AppRouter() {
  return (
    <BrowserRouter>
      <Routes>
        {/* Public */}
        <Route path="/login" element={<Login />} />

        {/* Authenticated — wrapped in AppShell */}
        <Route element={<AppShell />}>
          <Route index element={<Navigate to="/home" replace />} />
          <Route path="/home" element={<HomePage />} />

          {/* Bookmarks */}
          <Route path="/bookmarks" element={<PlaceholderPage title="Bookmarks" />} />
          <Route path="/bookmarks/recent" element={<PlaceholderPage title="Recent Bookmarks" />} />
          <Route path="/bookmarks/my" element={<PlaceholderPage title="My Bookmarks" />} />
          <Route path="/bookmarks/shared" element={<PlaceholderPage title="Shared With Me" />} />

          {/* Starred */}
          <Route path="/starred" element={<PlaceholderPage title="Starred" />} />
          <Route path="/starred/recent" element={<PlaceholderPage title="Recently Starred" />} />
          <Route path="/starred/all" element={<PlaceholderPage title="All Starred" />} />

          {/* Dashboards */}
          <Route path="/dashboards" element={<DashboardsPage />} />
          <Route path="/dashboards/playlists" element={<PlaceholderPage title="Playlists" />} />
          <Route path="/dashboards/snapshots" element={<PlaceholderPage title="Snapshots" />} />
          <Route path="/dashboards/library-panels" element={<PlaceholderPage title="Library Panels" />} />
          <Route path="/dashboards/shared" element={<PlaceholderPage title="Shared Dashboards" />} />

          {/* Explore */}
          <Route path="/explore" element={<ExplorePage />} />

          {/* Drilldown */}
          <Route path="/drilldown" element={<PlaceholderPage title="Drilldown" />} />
          <Route path="/explore/metrics" element={<PlaceholderPage title="Metrics" />} />
          <Route path="/explore/logs" element={<PlaceholderPage title="Logs" />} />
          <Route path="/explore/profiles" element={<PlaceholderPage title="Profiles" />} />

          {/* Alerting */}
          <Route path="/alerting" element={<PlaceholderPage title="Alerting" />} />
          <Route path="/alerting/rules" element={<PlaceholderPage title="Alert Rules" />} />
          <Route path="/alerting/contact-points" element={<PlaceholderPage title="Contact Points" />} />
          <Route path="/alerting/policies" element={<PlaceholderPage title="Notification Policies" />} />
          <Route path="/alerting/silences" element={<PlaceholderPage title="Silences" />} />
          <Route path="/alerting/active" element={<PlaceholderPage title="Active Notifications" />} />

          {/* Administration */}
          <Route path="/administration" element={<PlaceholderPage title="Administration" />} />
          <Route path="/admin/plugins" element={<PluginsDataPage />} />
          <Route path="/admin/plugins/correlations" element={<CorrelationsPage />} />

          {/* Available Agents */}
          <Route
            path="/available-agents"
            element={
              <Suspense fallback={<div style={{ padding: 32, color: 'var(--text-label)' }}>Loading…</div>}>
                <AvailableAgentsPage />
              </Suspense>
            }
          />

          {/* Ticket to Agent Mapping Edit */}
          <Route path="/home/ticket-mapping/edit" element={<TicketAgentMappingEditPage />} />

          {/* Ticket List */}
          <Route path="/tickets" element={<TicketListPage />} />

          {/* Ticket Details */}
          <Route
            path="/tickets/:id"
            element={
              <Suspense fallback={<div style={{ padding: 32, color: 'var(--text-label)' }}>Loading…</div>}>
                <TicketDetailsPage />
              </Suspense>
            }
          />

          {/* Agent Details */}
          <Route
            path="/agents/:id"
            element={
              <Suspense fallback={<div style={{ padding: 32, color: 'var(--text-label)' }}>Loading…</div>}>
                <AgentDetailsPage />
              </Suspense>
            }
          />
        </Route>
      </Routes>
    </BrowserRouter>
  );
}
