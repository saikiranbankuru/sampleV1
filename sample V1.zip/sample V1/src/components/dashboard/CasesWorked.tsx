import type { FC } from 'react';
import type { CaseWorked } from '../../types/dashboard';
import './DashboardWidgets.css';

interface CasesWorkedProps {
  cases: CaseWorked[];
}

export const CasesWorked: FC<CasesWorkedProps> = ({ cases }) => (
  <ul className="cases-list">
    {cases.map(c => (
      <li key={c.id} className="cases-item">
        <span className="cases-count">{String(c.count).padStart(2, '0')}</span>
        <span className="cases-name">{c.agentName}</span>
      </li>
    ))}
  </ul>
);
