import type { FC, ReactNode } from 'react';
import { MoreVertical } from 'lucide-react';
import { PanelMenu } from '../common/PanelMenu';
import type { PanelMenuItem } from '../common/PanelMenu';
import './SectionCard.css';

interface SectionCardProps {
  title: string;
  children: ReactNode;
  onViewMore?: () => void;
  className?: string;
  menuItems?: PanelMenuItem[];
}

export const SectionCard: FC<SectionCardProps> = ({
  title, children, onViewMore, className, menuItems,
}) => (
  <div className={`section-card${className ? ` ${className}` : ''}`}>
    <div className="section-card-header">
      <h3 className="section-card-title">{title}</h3>
      {menuItems && menuItems.length > 0 ? (
        <PanelMenu items={menuItems} />
      ) : (
        <button className="section-card-menu" aria-label="More options">
          <MoreVertical size={16} />
        </button>
      )}
    </div>
    <div className="section-card-body">{children}</div>
    {onViewMore !== undefined && (
      <div className="section-card-footer">
        <button className="section-view-more" onClick={onViewMore}>
          View More..
        </button>
      </div>
    )}
  </div>
);
