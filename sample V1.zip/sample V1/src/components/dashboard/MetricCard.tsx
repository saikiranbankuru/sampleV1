import type { FC } from 'react';
import './MetricCard.css';

interface MetricCardProps {
  label: string;
  value: number;
}

export const MetricCard: FC<MetricCardProps> = ({ label, value }) => (
  <div className="metric-card">
    <div className="metric-circle">
      <span className="metric-value">{value}</span>
    </div>
    <span className="metric-label">{label}</span>
  </div>
);
