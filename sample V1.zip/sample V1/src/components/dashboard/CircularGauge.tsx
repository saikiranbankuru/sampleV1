import { memo } from 'react';
import type { FC } from 'react';
import './CircularGauge.css';

export type GaugeVariant = 'full' | 'semi';

interface CircularGaugeProps {
  value: number;
  max?: number;
  color: string;
  size?: number;
  strokeWidth?: number;
  variant?: GaugeVariant;
  valueSize?: number;
}

const TRACK = 'rgba(255,255,255,0.08)';

const CircularGauge: FC<CircularGaugeProps> = ({
  value,
  max = 100,
  color,
  size = 96,
  strokeWidth = 10,
  variant = 'full',
  valueSize = 20,
}) => {
  const r   = (size - strokeWidth * 2) / 2;
  const cx  = size / 2;
  const cy  = size / 2;
  const C   = 2 * Math.PI * r;
  const pct = Math.min(Math.max(value / max, 0), 1);
  const display = String(value).padStart(2, '0');

  if (variant === 'semi') {
    // 240° sweep open at bottom — starts at 150°, sweeps CW to 30°
    const totalArc  = (240 / 360) * C;
    const filledArc = pct * totalArc;
    const clipH     = cy + r * 0.28; // crop just below center

    return (
      <div className="cg-semi-wrap">
        <svg
          width={size}
          height={clipH}
          viewBox={`0 0 ${size} ${clipH}`}
          style={{ overflow: 'visible' }}
        >
          {/* track */}
          <circle cx={cx} cy={cy} r={r} fill="none" stroke={TRACK}
            strokeWidth={strokeWidth} strokeLinecap="round"
            strokeDasharray={`${totalArc} ${C}`}
            transform={`rotate(150, ${cx}, ${cy})`}
          />
          {/* fill */}
          <circle cx={cx} cy={cy} r={r} fill="none" stroke={color}
            strokeWidth={strokeWidth} strokeLinecap="round"
            strokeDasharray={`${filledArc} ${C}`}
            transform={`rotate(150, ${cx}, ${cy})`}
            style={{ transition: 'stroke-dasharray 0.5s ease' }}
          />
          <text
            x={cx} y={cy + 4}
            textAnchor="middle" dominantBaseline="middle"
            fontSize={valueSize} fontWeight="700"
            fill="var(--text-primary)" fontFamily="Inter, sans-serif"
          >
            {display}
          </text>
        </svg>
      </div>
    );
  }

  // full circular gauge
  const filledArc = pct * C;

  return (
    <div className="cg-full-wrap">
      <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`}>
        {/* track */}
        <circle cx={cx} cy={cy} r={r} fill="none"
          stroke={TRACK} strokeWidth={strokeWidth}
        />
        {/* fill */}
        <circle cx={cx} cy={cy} r={r} fill="none"
          stroke={color} strokeWidth={strokeWidth} strokeLinecap="round"
          strokeDasharray={`${filledArc} ${C}`}
          transform={`rotate(-90, ${cx}, ${cy})`}
          style={{ transition: 'stroke-dasharray 0.5s ease' }}
        />
        <text
          x={cx} y={cy}
          textAnchor="middle" dominantBaseline="middle"
          fontSize={valueSize} fontWeight="700"
          fill="var(--text-primary)" fontFamily="Inter, sans-serif"
        >
          {display}
        </text>
      </svg>
    </div>
  );
};

export default memo(CircularGauge);
