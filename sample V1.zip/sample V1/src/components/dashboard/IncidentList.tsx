import type { FC } from 'react';
import type { Incident } from '../../types/dashboard';
import './DashboardWidgets.css';

interface IncidentListProps {
  incidents: Incident[];
}

export const IncidentList: FC<IncidentListProps> = ({ incidents }) => (
  <ul className="incident-list">
    {incidents.map(inc => (
      <li key={inc.id} className="incident-item">
        <p className="incident-field">
          <span className="incident-label">Agent Name:</span>
          <span className="incident-value">{inc.agentName}</span>
        </p>
        <p className="incident-field">
          <span className="incident-label">Case Number:</span>
          <span className="incident-value">{inc.caseNumber}</span>
        </p>
      </li>
    ))}
  </ul>
);
