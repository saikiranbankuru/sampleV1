import type { FC } from 'react';
import type { AgentRun } from '../../types/dashboard';
import './DashboardWidgets.css';

interface AgentsLastRunProps {
  agents: AgentRun[];
}

export const AgentsLastRun: FC<AgentsLastRunProps> = ({ agents }) => (
  <ul className="agent-run-list">
    {agents.map(agent => (
      <li key={agent.id} className="agent-run-item">
        <span className={`agent-status-dot agent-status-dot--${agent.status}`} />
        <div className="agent-run-info">
          <span className="agent-run-name">{agent.name}</span>
          <span className="agent-run-date">Date: {agent.date}</span>
        </div>
        <span className="agent-run-time">{agent.lastRunAgo}</span>
      </li>
    ))}
  </ul>
);
