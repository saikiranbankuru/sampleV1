import { useState } from 'react';
import { Outlet } from 'react-router-dom';
import Topbar from './Topbar';
import Sidebar from './Sidebar';
import './AppShell.css';

export default function AppShell() {
  const [sidebarOpen, setSidebarOpen] = useState(true);

  return (
    <div className={`app-shell${sidebarOpen ? '' : ' app-shell--collapsed'}`}>
      <Topbar onMenuToggle={() => setSidebarOpen(o => !o)} />
      <div className="app-body">
        <Sidebar isOpen={sidebarOpen} />
        <main className="app-main">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
