import { useState, useRef } from 'react';
import { createPortal } from 'react-dom';
import { NavLink, useLocation } from 'react-router-dom';
import {
  Home, Bookmark, Star, LayoutDashboard, Compass,
  Network, Bell, Shield, ChevronDown,
} from 'lucide-react';
import './Sidebar.css';

interface NavChild {
  label: string;
  path?: string;
  children?: NavChild[];
}

interface NavItem {
  id: string;
  label: string;
  icon: React.ElementType;
  path?: string;
  children?: NavChild[];
}

const NAV_ITEMS: NavItem[] = [
  { id: 'home', label: 'HOME', icon: Home, path: '/' },
  {
    id: 'bookmarks', label: 'BOOKMARKS', icon: Bookmark,
    path: '/bookmarks',
    children: [
      { label: 'Recent', path: '/bookmarks/recent' },
      { label: 'My Bookmarks', path: '/bookmarks/my' },
      { label: 'Shared With Me', path: '/bookmarks/shared' },
    ],
  },
  {
    id: 'starred', label: 'STARRED', icon: Star,
    path: '/starred',
    children: [
      { label: 'Recently Starred', path: '/starred/recent' },
      { label: 'All Starred', path: '/starred/all' },
    ],
  },
  {
    id: 'dashboards', label: 'DASHBOARDS', icon: LayoutDashboard,
    path: '/dashboards',
    children: [
      { label: 'Playlists', path: '/dashboards/playlists' },
      { label: 'Snapshots', path: '/dashboards/snapshots' },
      { label: 'Library Panels', path: '/dashboards/library-panels' },
      { label: 'Shared Dashboards', path: '/dashboards/shared' },
    ],
  },
  { id: 'explore', label: 'EXPLORE', icon: Compass, path: '/explore' },
  {
    id: 'drilldown', label: 'DRILLDOWN', icon: Network,
    path: '/drilldown',
    children: [
      { label: 'Metrics', path: '/explore/metrics' },
      { label: 'Logs', path: '/explore/logs' },
      { label: 'Profiles', path: '/explore/profiles' },
    ],
  },
  {
    id: 'alerting', label: 'ALERTING', icon: Bell,
    path: '/alerting',
    children: [
      { label: 'Alert Rules', path: '/alerting/rules' },
      { label: 'Contact Points', path: '/alerting/contact-points' },
      { label: 'Notification Policies', path: '/alerting/policies' },
      { label: 'Silences', path: '/alerting/silences' },
      { label: 'Active Notifications', path: '/alerting/active' },
    ],
  },
  {
    id: 'administration', label: 'ADMINISTRATION', icon: Shield,
    path: '/administration',
    children: [
      {
        label: 'Plugins and Data', path: '/admin/plugins',
        children: [
          { label: 'Correlations', path: '/admin/plugins/correlations' },
        ],
      },
    ],
  },
];

interface FlyoutState {
  id: string;
  label: string;
  children: NavChild[];
  top: number;
}

interface SidebarProps {
  isOpen: boolean;
}

function firstPath(children: NavChild[]): string {
  for (const c of children) {
    if (c.path) return c.path;
    if (c.children) {
      const p = firstPath(c.children);
      if (p !== '/') return p;
    }
  }
  return '/';
}

export default function Sidebar({ isOpen }: SidebarProps) {
  const location = useLocation();
  const [expanded, setExpanded] = useState<string[]>([]);
  const [flyout, setFlyout] = useState<FlyoutState | null>(null);
  const hideTimer = useRef<number>(0);

  const toggleExpand = (id: string) => {
    setExpanded(prev =>
      prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id],
    );
  };

  const isGroupActive = (item: NavItem): boolean => {
    // Active when on the item's own landing page
    if (item.path && location.pathname === item.path) return true;
    if (!item.children) return false;
    // Active when on any child page
    const check = (children: NavChild[]): boolean =>
      children.some(c =>
        (c.path ? location.pathname.startsWith(c.path) : false) ||
        (c.children ? check(c.children) : false),
      );
    return check(item.children);
  };

  /* ---- Flyout handlers (collapsed mode only) ---- */
  const openFlyout = (item: NavItem, el: HTMLElement) => {
    if (isOpen || !item.children) return;
    clearTimeout(hideTimer.current);
    const rect = el.getBoundingClientRect();
    setFlyout({ id: item.id, label: item.label, children: item.children, top: rect.top });
  };

  const scheduleFlyoutClose = () => {
    hideTimer.current = window.setTimeout(() => setFlyout(null), 120);
  };

  const cancelFlyoutClose = () => clearTimeout(hideTimer.current);

  const renderSubItems = (children: NavChild[]) =>
    children.map(child => {
      if (child.children) {
        return (
          <div key={child.label} className="sidebar-subgroup">
            {child.path ? (
              <NavLink
                to={child.path}
                className={({ isActive }) =>
                  `sidebar-subitem${isActive ? ' sidebar-subitem--active' : ''}`
                }
              >
                {child.label}
              </NavLink>
            ) : (
              <div className="sidebar-subgroup-header">{child.label}</div>
            )}
            {child.children.map(gc => (
              <NavLink
                key={gc.path}
                to={gc.path!}
                className={({ isActive }) =>
                  `sidebar-subitem sidebar-subitem--nested${isActive ? ' sidebar-subitem--active' : ''}`
                }
              >
                {gc.label}
              </NavLink>
            ))}
          </div>
        );
      }
      return (
        <NavLink
          key={child.path}
          to={child.path!}
          className={({ isActive }) =>
            `sidebar-subitem${isActive ? ' sidebar-subitem--active' : ''}`
          }
        >
          {child.label}
        </NavLink>
      );
    });

  const renderFlyoutItems = (children: NavChild[]) =>
    children.map(child => {
      if (child.children) {
        return (
          <div key={child.label} className="sidebar-flyout-subgroup">
            {child.path ? (
              <NavLink
                to={child.path}
                className={({ isActive }) =>
                  `sidebar-flyout-item${isActive ? ' sidebar-flyout-item--active' : ''}`
                }
                onClick={() => setFlyout(null)}
              >
                <span className="sidebar-flyout-arrow">→</span>
                {child.label}
              </NavLink>
            ) : (
              <div className="sidebar-flyout-subgroup-header">{child.label}</div>
            )}
            {child.children.map(gc => (
              <NavLink
                key={gc.path}
                to={gc.path!}
                className={({ isActive }) =>
                  `sidebar-flyout-item sidebar-flyout-item--nested${isActive ? ' sidebar-flyout-item--active' : ''}`
                }
                onClick={() => setFlyout(null)}
              >
                <span className="sidebar-flyout-arrow">→</span>
                {gc.label}
              </NavLink>
            ))}
          </div>
        );
      }
      return (
        <NavLink
          key={child.path}
          to={child.path!}
          className={({ isActive }) =>
            `sidebar-flyout-item${isActive ? ' sidebar-flyout-item--active' : ''}`
          }
          onClick={() => setFlyout(null)}
        >
          <span className="sidebar-flyout-arrow">→</span>
          {child.label}
        </NavLink>
      );
    });

  return (
    <>
      <aside className={`sidebar ${isOpen ? 'sidebar--open' : 'sidebar--collapsed'}`}>
        <nav className="sidebar-nav">
          {NAV_ITEMS.map(item => {
            const Icon = item.icon;
            const isExp = expanded.includes(item.id) && isOpen;

            if (item.children) {
              const groupActive = isGroupActive(item);
              const navPath = item.path ?? firstPath(item.children);
              return (
                <div
                  key={item.id}
                  className="sidebar-group"
                  onMouseEnter={e => openFlyout(item, e.currentTarget)}
                  onMouseLeave={scheduleFlyoutClose}
                >
                  {/* Row: NavLink (navigate) + chevron button (toggle submenu) */}
                  <div className={`sidebar-item-row${groupActive ? ' sidebar-item--active' : ''}`}>
                    <NavLink to={navPath} className="sidebar-item-nav">
                      <Icon size={17} className="sidebar-icon" />
                      <span className="sidebar-label">{item.label}</span>
                    </NavLink>
                    <button
                      className="sidebar-chevron-btn"
                      onClick={() => toggleExpand(item.id)}
                      tabIndex={isOpen ? 0 : -1}
                    >
                      <ChevronDown
                        size={13}
                        className={`sidebar-chevron${isExp ? ' sidebar-chevron--up' : ''}`}
                      />
                    </button>
                  </div>
                  {/* Expanded submenu (full sidebar mode only) */}
                  <div className={`sidebar-submenu${isExp ? ' sidebar-submenu--open' : ''}`}>
                    {renderSubItems(item.children)}
                  </div>
                </div>
              );
            }

            /* Leaf items (no children) — CSS tooltip in collapsed mode */
            return (
              <NavLink
                key={item.id}
                to={item.path!}
                data-tooltip={item.label}
                className={({ isActive }) =>
                  `sidebar-item${isActive ? ' sidebar-item--active' : ''}`
                }
              >
                <Icon size={17} className="sidebar-icon" />
                <span className="sidebar-label">{item.label}</span>
              </NavLink>
            );
          })}
        </nav>
      </aside>

      {/* Flyout panel — rendered in <body> to escape sidebar overflow:hidden */}
      {!isOpen && flyout && createPortal(
        <div
          className="sidebar-flyout"
          style={{ top: flyout.top }}
          onMouseEnter={cancelFlyoutClose}
          onMouseLeave={scheduleFlyoutClose}
        >
          <div className="sidebar-flyout-title">{flyout.label}</div>
          <div className="sidebar-flyout-list">
            {renderFlyoutItems(flyout.children)}
          </div>
        </div>,
        document.body,
      )}
    </>
  );
}
