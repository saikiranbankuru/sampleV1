import { useState, useEffect, useRef, useCallback } from 'react';
import { X, RefreshCw, ChevronDown } from 'lucide-react';
import './QueryInspectorOffcanvas.css';

/* ─── Types ───────────────────────────────────────────────── */
type TabId = 'stats' | 'query' | 'json' | 'data';

const TABS: { id: TabId; label: string }[] = [
  { id: 'stats', label: 'Stats' },
  { id: 'query', label: 'Query' },
  { id: 'json',  label: 'JSON'  },
  { id: 'data',  label: 'Data'  },
];

/* ─── Mock data ───────────────────────────────────────────── */
const MOCK_STATS: { label: string; value: string }[] = [
  { label: 'Total request time', value: '2 ms' },
  { label: 'Number of queries',  value: '0'    },
  { label: 'Total number rows',  value: '0'    },
];

const JSON_SOURCES = [
  {
    id:          'panel-data',
    label:       'Panel data',
    description: 'The raw model passed to the panel visualization',
    data:        { state: 'Done', series: [], annotations: [] },
  },
  {
    id:          'dataframe-json',
    label:       'DataFrame JSON (from Query)',
    description: 'The raw model passed to the panel visualization',
    data:        { state: 'Done', series: [], annotations: [] },
  },
];

/* ─── JSON helpers ────────────────────────────────────────── */
function prettyJson(data: unknown): string {
  return JSON.stringify(data, null, 2);
}

function highlightJson(raw: string): string {
  // Escape HTML first, then colorize tokens
  const safe = raw
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');

  return safe.replace(
    /("(?:\\u[a-fA-F0-9]{4}|\\[^u]|[^\\"])*"(?:\s*:)?|\b(?:true|false|null)\b|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?)/g,
    match => {
      let cls = 'qi-json-number';
      if (/^"/.test(match)) {
        cls = /:$/.test(match) ? 'qi-json-key' : 'qi-json-string';
      } else if (/true|false/.test(match)) {
        cls = 'qi-json-bool';
      } else if (/null/.test(match)) {
        cls = 'qi-json-null';
      }
      return `<span class="${cls}">${match}</span>`;
    },
  );
}

/* ═══════════════════════════════════════════════════════════
   Stats Panel
   ═══════════════════════════════════════════════════════════ */
function StatsPanel() {
  return (
    <div className="qi-panel">
      <h3 className="qi-panel-title">Stats</h3>
      <div className="qi-stats-table" role="table" aria-label="Query statistics">
        {MOCK_STATS.map((row, i) => (
          <div
            key={row.label}
            className={`qi-stats-row${i % 2 === 0 ? ' qi-stats-row--alt' : ''}`}
            role="row"
          >
            <span className="qi-stats-label" role="cell">{row.label}</span>
            <span className="qi-stats-value" role="cell">{row.value}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════
   Query Panel
   ═══════════════════════════════════════════════════════════ */
function QueryPanel() {
  const [refreshed, setRefreshed] = useState(false);

  return (
    <div className="qi-panel">
      <h3 className="qi-panel-title">Query inspector</h3>
      <p className="qi-panel-desc">
        Query inspector allows you to view raw request and response. To collect this data Grafana
        needs to issue a new query — click the refresh button below to trigger a new query.
      </p>
      <button
        className="qi-refresh-btn"
        onClick={() => setRefreshed(true)}
        aria-label="Refresh query to collect request and response data"
      >
        <RefreshCw size={15} aria-hidden="true" />
        Refresh
      </button>
      {!refreshed && (
        <p className="qi-panel-empty">
          No request and response collected yet. Hit refresh button
        </p>
      )}
      {refreshed && (
        <p className="qi-panel-empty qi-panel-empty--done">
          Query refreshed — no active queries to inspect.
        </p>
      )}
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════
   JSON Panel
   ═══════════════════════════════════════════════════════════ */
function JsonPanel() {
  const [sourceId,    setSourceId]    = useState('dataframe-json');
  const [ddOpen,      setDdOpen]      = useState(false);
  const wrapRef = useRef<HTMLDivElement>(null);

  const selected = JSON_SOURCES.find(s => s.id === sourceId) ?? JSON_SOURCES[1];
  const jsonText = prettyJson(selected.data);
  const lines    = jsonText.split('\n');

  useEffect(() => {
    if (!ddOpen) return;
    const handler = (e: MouseEvent) => {
      if (wrapRef.current && !wrapRef.current.contains(e.target as Node)) {
        setDdOpen(false);
      }
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, [ddOpen]);

  return (
    <div className="qi-panel">
      <h3 className="qi-panel-title">JSON</h3>

      {/* Source selector */}
      <div className="qi-json-src-group">
        <label className="qi-json-src-label">Select source</label>
        <div className="qi-json-dd-wrap" ref={wrapRef}>
          <button
            className={`qi-json-dd-trigger${ddOpen ? ' qi-json-dd-trigger--open' : ''}`}
            onClick={() => setDdOpen(v => !v)}
            aria-haspopup="listbox"
            aria-expanded={ddOpen}
            aria-label="Select JSON source"
          >
            <span>{selected.label}</span>
            <ChevronDown
              size={15}
              className={ddOpen ? 'qi-json-dd-chevron--open' : ''}
              aria-hidden="true"
            />
          </button>

          {ddOpen && (
            <div className="qi-json-dd-panel" role="listbox" aria-label="JSON source options">
              {JSON_SOURCES.map(src => (
                <div
                  key={src.id}
                  role="option"
                  aria-selected={src.id === sourceId}
                  className={`qi-json-dd-item${src.id === sourceId ? ' qi-json-dd-item--active' : ''}`}
                  onClick={() => { setSourceId(src.id); setDdOpen(false); }}
                  tabIndex={0}
                  onKeyDown={e => {
                    if (e.key === 'Enter' || e.key === ' ') {
                      setSourceId(src.id);
                      setDdOpen(false);
                    }
                  }}
                >
                  <span className="qi-json-dd-label">{src.label}</span>
                  <span className="qi-json-dd-desc">{src.description}</span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Code viewer with line numbers + syntax highlight */}
      <div className="qi-code-wrap" aria-label="JSON output">
        <div className="qi-code-gutter" aria-hidden="true">
          {lines.map((_, i) => (
            <div key={i} className="qi-code-linenum">{i + 1}</div>
          ))}
        </div>
        <pre
          className="qi-code-body"
          /* Safe: we control the JSON source (no user input goes in) */
          dangerouslySetInnerHTML={{
            __html: lines.map(line => highlightJson(line)).join('\n'),
          }}
        />
      </div>
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════
   Data Panel
   ═══════════════════════════════════════════════════════════ */
function DataPanel() {
  return (
    <div className="qi-panel">
      <h3 className="qi-panel-title">Data</h3>
      <p className="qi-panel-empty">No data available</p>
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════
   Main Offcanvas Export
   ═══════════════════════════════════════════════════════════ */
export interface QueryInspectorOffcanvasProps {
  isOpen:  boolean;
  onClose: () => void;
}

export function QueryInspectorOffcanvas({ isOpen, onClose }: QueryInspectorOffcanvasProps) {
  const [activeTab, setActiveTab] = useState<TabId>('stats');

  /* Prevent body scroll while panel is open */
  useEffect(() => {
    document.body.style.overflow = isOpen ? 'hidden' : '';
    return () => { document.body.style.overflow = ''; };
  }, [isOpen]);

  /* ESC to close */
  const handleKeyDown = useCallback((e: KeyboardEvent) => {
    if (e.key === 'Escape') onClose();
  }, [onClose]);

  useEffect(() => {
    if (!isOpen) return;
    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, handleKeyDown]);

  /* Arrow-key tab navigation */
  const handleTabKey = (e: React.KeyboardEvent, tabId: TabId) => {
    const ids  = TABS.map(t => t.id);
    const idx  = ids.indexOf(tabId);
    if (e.key === 'ArrowRight') {
      e.preventDefault();
      setActiveTab(ids[(idx + 1) % ids.length]);
    }
    if (e.key === 'ArrowLeft') {
      e.preventDefault();
      setActiveTab(ids[(idx - 1 + ids.length) % ids.length]);
    }
    if (e.key === 'Home') { e.preventDefault(); setActiveTab(ids[0]); }
    if (e.key === 'End')  { e.preventDefault(); setActiveTab(ids[ids.length - 1]); }
  };

  return (
    <>
      {/* Dim backdrop */}
      <div
        className={`qi-backdrop${isOpen ? ' qi-backdrop--visible' : ''}`}
        onClick={onClose}
        aria-hidden="true"
      />

      {/* Slide-up panel */}
      <div
        className={`qi-offcanvas${isOpen ? ' qi-offcanvas--open' : ''}`}
        role="dialog"
        aria-modal="true"
        aria-label="Query Inspector"
      >
        {/* ── Tab bar ── */}
        <div
          className="qi-tabbar"
          role="tablist"
          aria-label="Query inspector tabs"
        >
          {TABS.map(tab => (
            <button
              key={tab.id}
              role="tab"
              id={`qi-tab-${tab.id}`}
              aria-selected={activeTab === tab.id}
              aria-controls={`qi-tabpanel-${tab.id}`}
              className={`qi-tab${activeTab === tab.id ? ' qi-tab--active' : ''}`}
              onClick={() => setActiveTab(tab.id)}
              onKeyDown={e => handleTabKey(e, tab.id)}
              tabIndex={activeTab === tab.id ? 0 : -1}
            >
              {tab.label}
            </button>
          ))}

          <button
            className="qi-close-btn"
            onClick={onClose}
            aria-label="Close Query Inspector"
          >
            <X size={16} aria-hidden="true" />
          </button>
        </div>

        {/* ── Scrollable content ── */}
        <div className="qi-content-wrap">
          {TABS.map(tab => (
            <div
              key={tab.id}
              role="tabpanel"
              id={`qi-tabpanel-${tab.id}`}
              aria-labelledby={`qi-tab-${tab.id}`}
              hidden={activeTab !== tab.id}
            >
              {activeTab === tab.id && (
                <>
                  {tab.id === 'stats' && <StatsPanel />}
                  {tab.id === 'query' && <QueryPanel />}
                  {tab.id === 'json'  && <JsonPanel />}
                  {tab.id === 'data'  && <DataPanel />}
                </>
              )}
            </div>
          ))}
        </div>
      </div>
    </>
  );
}
