import { useState, useRef, useEffect } from 'react';
import { Search, ChevronDown, Check } from 'lucide-react';
import './DataSourceDropdown.css';

const DATA_SOURCES = [
  { id: 'loki-1',             label: 'Loki-1',              type: 'Loki'       },
  { id: 'prometheus',         label: 'Prometheus',           type: 'Prometheus' },
  { id: 'prometheus-default', label: 'Prometheus Default',   type: 'Prometheus' },
  { id: 'mixed',              label: '-- Mixed --',          type: 'Mixed'      },
];

interface DataSourceDropdownProps {
  value: string;
  onChange: (id: string) => void;
}

export function DataSourceDropdown({ value, onChange }: DataSourceDropdownProps) {
  const [isOpen,  setIsOpen]  = useState(false);
  const [search,  setSearch]  = useState('');
  const wrapRef = useRef<HTMLDivElement>(null);

  const selected = DATA_SOURCES.find(d => d.id === value) ?? DATA_SOURCES[1];

  useEffect(() => {
    if (!isOpen) return;
    const handler = (e: MouseEvent) => {
      if (wrapRef.current && !wrapRef.current.contains(e.target as Node)) {
        setIsOpen(false);
        setSearch('');
      }
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, [isOpen]);

  useEffect(() => {
    if (!isOpen) return;
    const handler = (e: KeyboardEvent) => {
      if (e.key === 'Escape') { setIsOpen(false); setSearch(''); }
    };
    document.addEventListener('keydown', handler);
    return () => document.removeEventListener('keydown', handler);
  }, [isOpen]);

  const filtered = DATA_SOURCES.filter(d =>
    d.label.toLowerCase().includes(search.toLowerCase())
  );

  const handleSelect = (id: string) => {
    onChange(id);
    setIsOpen(false);
    setSearch('');
  };

  return (
    <div className="dsd-wrap" ref={wrapRef}>
      <button
        className={`dsd-trigger${isOpen ? ' dsd-trigger--open' : ''}`}
        onClick={() => setIsOpen(v => !v)}
        aria-haspopup="listbox"
        aria-expanded={isOpen}
        aria-label="Select data source"
      >
        <Search size={14} className="dsd-search-icon" aria-hidden="true" />
        <span className="dsd-label">{selected.label}</span>
        <ChevronDown
          size={14}
          className={`dsd-chevron${isOpen ? ' dsd-chevron--open' : ''}`}
          aria-hidden="true"
        />
      </button>

      {isOpen && (
        <div className="dsd-panel" role="listbox" aria-label="Data sources">
          <div className="dsd-search-wrap">
            <Search size={13} className="dsd-panel-search-icon" aria-hidden="true" />
            <input
              className="dsd-search-input"
              placeholder="Filter data sources…"
              value={search}
              onChange={e => setSearch(e.target.value)}
              autoFocus
              aria-label="Filter data sources"
            />
          </div>
          <ul className="dsd-list">
            {filtered.map(ds => (
              <li
                key={ds.id}
                className={`dsd-item${ds.id === value ? ' dsd-item--active' : ''}`}
                role="option"
                aria-selected={ds.id === value}
                onClick={() => handleSelect(ds.id)}
              >
                <span className="dsd-item-check" aria-hidden="true">
                  {ds.id === value && <Check size={12} />}
                </span>
                <span className="dsd-item-label">{ds.label}</span>
                <span className="dsd-item-type">{ds.type}</span>
              </li>
            ))}
            {filtered.length === 0 && (
              <li className="dsd-empty">No data sources found</li>
            )}
          </ul>
        </div>
      )}
    </div>
  );
}
