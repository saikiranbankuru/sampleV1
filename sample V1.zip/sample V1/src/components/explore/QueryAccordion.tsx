import { useState, useRef, useEffect } from 'react';
import {
  ChevronRight, ChevronDown, HelpCircle, Copy, Eye, EyeOff,
  Trash2, Pencil, Check, X, Plus,
} from 'lucide-react';
import { Tooltip } from '../common/Tooltip';
import './QueryAccordion.css';

/* ─── Types ───────────────────────────────────────────────── */
interface LabelFilter {
  id: string;
  label: string;
  condition: string;
  value: string;
}

type LegendMode = 'Auto' | 'Verbose' | 'Custom';
type FormatType  = 'Time series' | 'Table' | 'Heatmap';
type QueryType   = 'Range' | 'Instant' | 'Both';

/* ─── Static mock data ────────────────────────────────────── */
const LABEL_OPTIONS = [
  '__name__', 'instance', 'job', 'namespace', 'pod', 'container', 'env', 'region', 'cluster',
];

const CONDITION_OPTIONS = ['=', '!=', '=~', '!~'];

const METRIC_OPTIONS = [
  'go_gc_duration_seconds',
  'http_requests_total',
  'node_cpu_seconds_total',
  'node_memory_MemTotal_bytes',
  'node_network_receive_bytes_total',
  'process_cpu_seconds_total',
  'prometheus_http_requests_total',
  'up',
];

const VALUE_OPTIONS = [
  'production', 'staging', 'development',
  'localhost:9090', 'localhost:9100', 'default', 'monitoring',
];

const OPERATIONS: Record<string, string[]> = {
  Aggregations:        ['sum', 'avg', 'min', 'max', 'count', 'stddev', 'stdvar', 'topk', 'bottomk'],
  'Range Functions':   ['rate', 'irate', 'increase', 'delta', 'deriv', 'idelta'],
  Functions:           ['abs', 'ceil', 'floor', 'round', 'sqrt', 'exp', 'ln', 'log2'],
  'Binary Operations': ['+ (add)', '- (subtract)', '* (multiply)', '/ (divide)', '% (modulo)'],
  Trigonometric:       ['sin', 'cos', 'tan', 'asin', 'acos', 'atan', 'atan2'],
  'Time Functions':    ['time()', 'timestamp()', 'day_of_month()', 'day_of_week()', 'year()'],
};

const LEGEND_OPTIONS: { value: LegendMode; title: string; description: string }[] = [
  { value: 'Auto',    title: 'Auto',    description: 'Only includes unique labels'    },
  { value: 'Verbose', title: 'Verbose', description: 'All label names and values'     },
  { value: 'Custom',  title: 'Custom',  description: 'Provide a naming template'      },
];

/* ═══════════════════════════════════════════════════════════
   Label Filter Row
   ═══════════════════════════════════════════════════════════ */
interface LabelFilterRowProps {
  filter: LabelFilter;
  onChange: (f: LabelFilter) => void;
  onRemove: () => void;
  onAdd: () => void;
  isLast: boolean;
}

function LabelFilterRow({ filter, onChange, onRemove, onAdd, isLast }: LabelFilterRowProps) {
  const [labelOpen, setLabelOpen] = useState(false);
  const [valueOpen, setValueOpen] = useState(false);
  const labelRef = useRef<HTMLDivElement>(null);
  const valueRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (labelRef.current && !labelRef.current.contains(e.target as Node)) setLabelOpen(false);
      if (valueRef.current && !valueRef.current.contains(e.target as Node)) setValueOpen(false);
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  return (
    <div className="qa-lf-row">
      {/* Label dropdown */}
      <div className="qa-lf-dd-wrap" ref={labelRef}>
        <button
          className="qa-lf-dd-trigger"
          onClick={() => setLabelOpen(v => !v)}
          aria-haspopup="listbox"
          aria-label="Select label"
        >
          <span className="qa-lf-dd-text">{filter.label || 'Select label'}</span>
          <ChevronDown size={11} aria-hidden="true" />
        </button>
        {labelOpen && (
          <div className="qa-lf-dd-panel" role="listbox">
            {LABEL_OPTIONS.map(opt => (
              <div
                key={opt}
                role="option"
                aria-selected={filter.label === opt}
                className={`qa-lf-dd-item${filter.label === opt ? ' qa-lf-dd-item--active' : ''}`}
                onClick={() => { onChange({ ...filter, label: opt }); setLabelOpen(false); }}
              >
                {opt}
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Condition select */}
      <select
        className="qa-lf-condition"
        value={filter.condition}
        onChange={e => onChange({ ...filter, condition: e.target.value })}
        aria-label="Filter condition"
      >
        {CONDITION_OPTIONS.map(c => (
          <option key={c} value={c}>{c}</option>
        ))}
      </select>

      {/* Value dropdown */}
      <div className="qa-lf-dd-wrap" ref={valueRef}>
        <button
          className="qa-lf-dd-trigger"
          onClick={() => setValueOpen(v => !v)}
          aria-haspopup="listbox"
          aria-label="Select value"
        >
          <span className="qa-lf-dd-text">{filter.value || 'Select value'}</span>
          <ChevronDown size={11} aria-hidden="true" />
        </button>
        {valueOpen && (
          <div className="qa-lf-dd-panel" role="listbox">
            {VALUE_OPTIONS.map(opt => (
              <div
                key={opt}
                role="option"
                aria-selected={filter.value === opt}
                className={`qa-lf-dd-item${filter.value === opt ? ' qa-lf-dd-item--active' : ''}`}
                onClick={() => { onChange({ ...filter, value: opt }); setValueOpen(false); }}
              >
                {opt}
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Remove */}
      <button className="qa-lf-icon-btn qa-lf-remove" onClick={onRemove} aria-label="Remove label filter">
        <X size={12} />
      </button>

      {/* Add (last row only) */}
      {isLast && (
        <button className="qa-lf-icon-btn qa-lf-add" onClick={onAdd} aria-label="Add label filter">
          <Plus size={12} />
        </button>
      )}
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════
   Operations Dropdown  (Step 2 – viewport-aware positioning)
   ═══════════════════════════════════════════════════════════ */
interface OperationsDropdownProps {
  onSelect: (op: string) => void;
}

function OperationsDropdown({ onSelect }: OperationsDropdownProps) {
  const [isOpen,   setIsOpen]   = useState(false);
  const [expanded, setExpanded] = useState<string | null>(null);
  const wrapRef  = useRef<HTMLDivElement>(null);
  const panelRef = useRef<HTMLDivElement>(null);

  /* Close on outside click */
  useEffect(() => {
    if (!isOpen) return;
    const handler = (e: MouseEvent) => {
      if (wrapRef.current && !wrapRef.current.contains(e.target as Node)) {
        setIsOpen(false);
        setExpanded(null);
      }
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, [isOpen]);

  /* Viewport-aware repositioning (Step 2) */
  useEffect(() => {
    if (!isOpen || !panelRef.current || !wrapRef.current) return;
    const panel    = panelRef.current;
    const wrapRect = wrapRef.current.getBoundingClientRect();
    const vpH      = window.innerHeight;
    const vpW      = window.innerWidth;

    // Reset imperative overrides first
    panel.style.top    = '';
    panel.style.bottom = '';
    panel.style.left   = '';
    panel.style.right  = '';

    const panelRect = panel.getBoundingClientRect();

    // Flip upward when not enough space below
    if (panelRect.bottom > vpH - 8) {
      panel.style.top    = 'auto';
      panel.style.bottom = `${wrapRect.height + 4}px`;
    }

    // Align to right edge when overflowing right side
    if (panelRect.right > vpW - 8) {
      panel.style.left  = 'auto';
      panel.style.right = '0';
    }
  }, [isOpen]);

  return (
    <div className="qa-ops-wrap" ref={wrapRef}>
      <button
        className="qa-ops-trigger"
        onClick={() => { setIsOpen(v => !v); setExpanded(null); }}
        aria-haspopup="true"
        aria-expanded={isOpen}
      >
        <span>Operations</span>
        <ChevronDown
          size={12}
          className={isOpen ? 'qa-ops-chevron--open' : ''}
          aria-hidden="true"
        />
      </button>

      {isOpen && (
        <div className="qa-ops-panel" ref={panelRef}>
          {Object.entries(OPERATIONS).map(([cat, ops]) => (
            <div key={cat} className="qa-ops-category">
              <button
                className="qa-ops-cat-btn"
                onClick={() => setExpanded(expanded === cat ? null : cat)}
                aria-expanded={expanded === cat}
              >
                <ChevronRight
                  size={11}
                  className={`qa-ops-cat-chevron${expanded === cat ? ' qa-ops-cat-chevron--open' : ''}`}
                  aria-hidden="true"
                />
                <span>{cat}</span>
              </button>
              {expanded === cat && (
                <div className="qa-ops-items">
                  {ops.map(op => (
                    <button
                      key={op}
                      className="qa-ops-item"
                      onClick={() => { onSelect(op); setIsOpen(false); setExpanded(null); }}
                    >
                      {op}
                    </button>
                  ))}
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════
   Legend Dropdown  (Step 3 – rich options with descriptions)
   ═══════════════════════════════════════════════════════════ */
interface LegendDropdownProps {
  value:    LegendMode;
  onChange: (v: LegendMode) => void;
}

function LegendDropdown({ value, onChange }: LegendDropdownProps) {
  const [isOpen, setIsOpen] = useState(false);
  const wrapRef  = useRef<HTMLDivElement>(null);
  const panelRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!isOpen) return;
    const handler = (e: MouseEvent) => {
      if (wrapRef.current && !wrapRef.current.contains(e.target as Node)) setIsOpen(false);
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, [isOpen]);

  /* Keyboard navigation */
  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Escape')   { setIsOpen(false); }
    if (e.key === 'ArrowDown' || e.key === 'Enter') { setIsOpen(true); }
  };

  /* Flip upward if too close to bottom */
  useEffect(() => {
    if (!isOpen || !panelRef.current || !wrapRef.current) return;
    const panel    = panelRef.current;
    const wrapRect = wrapRef.current.getBoundingClientRect();
    const vpH      = window.innerHeight;

    panel.style.top    = '';
    panel.style.bottom = '';

    const panelRect = panel.getBoundingClientRect();
    if (panelRect.bottom > vpH - 8) {
      panel.style.top    = 'auto';
      panel.style.bottom = `${wrapRect.height + 4}px`;
    }
  }, [isOpen]);

  return (
    <div className="qa-legend-wrap" ref={wrapRef}>
      <button
        className={`qa-legend-trigger${isOpen ? ' qa-legend-trigger--open' : ''}`}
        onClick={() => setIsOpen(v => !v)}
        onKeyDown={handleKeyDown}
        aria-haspopup="listbox"
        aria-expanded={isOpen}
        aria-label={`Legend mode: ${value}`}
      >
        <span className="qa-legend-trigger-text">{value}</span>
        <ChevronDown
          size={13}
          className={`qa-legend-chevron${isOpen ? ' qa-legend-chevron--open' : ''}`}
          aria-hidden="true"
        />
      </button>

      {isOpen && (
        <div
          className="qa-legend-panel"
          ref={panelRef}
          role="listbox"
          aria-label="Legend mode options"
        >
          {LEGEND_OPTIONS.map(opt => (
            <div
              key={opt.value}
              className={`qa-legend-option${value === opt.value ? ' qa-legend-option--active' : ''}`}
              role="option"
              aria-selected={value === opt.value}
              onClick={() => { onChange(opt.value); setIsOpen(false); }}
              tabIndex={0}
              onKeyDown={e => { if (e.key === 'Enter' || e.key === ' ') { onChange(opt.value); setIsOpen(false); } }}
            >
              <span className="qa-legend-opt-title">{opt.title}</span>
              <span className="qa-legend-opt-desc">{opt.description}</span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════
   Options Panel (nested accordion)
   ═══════════════════════════════════════════════════════════ */
interface OptionsPanelProps {
  isExpanded:         boolean;
  onToggle:           () => void;
  legend:             string;
  legendMode:         LegendMode;
  minStep:            string;
  format:             FormatType;
  queryType:          QueryType;
  exemplars:          boolean;
  onLegendChange:     (v: string) => void;
  onLegendModeChange: (v: LegendMode) => void;
  onMinStepChange:    (v: string) => void;
  onFormatChange:     (v: FormatType) => void;
  onQueryTypeChange:  (v: QueryType) => void;
  onExemplarsChange:  (v: boolean) => void;
}

function OptionsPanel({
  isExpanded, onToggle,
  legend, legendMode, minStep, format, queryType, exemplars,
  onLegendChange, onLegendModeChange, onMinStepChange,
  onFormatChange, onQueryTypeChange, onExemplarsChange,
}: OptionsPanelProps) {
  const queryTypeTooltips: Record<QueryType, string> = {
    Range:   'Run query over a range of time',
    Instant: 'Run query at a single point in time',
    Both:    'Run both instant and range queries',
  };

  return (
    <div className="qa-opts">
      <button className="qa-opts-header" onClick={onToggle} aria-expanded={isExpanded}>
        <ChevronRight
          size={13}
          className={`qa-opts-chevron${isExpanded ? ' qa-opts-chevron--open' : ''}`}
          aria-hidden="true"
        />
        <span className="qa-opts-title">Options</span>
      </button>

      {isExpanded && (
        <div className="qa-opts-body">

          {/* ── Legend (Step 3+4: rich dropdown, no plain select) ── */}
          <div className="qa-opts-row">
            <label className="qa-opts-label">Legend</label>
            <div className="qa-opts-field-group">
              <LegendDropdown value={legendMode} onChange={onLegendModeChange} />
              <Tooltip
                placement="top"
                content="Series name override or template. Example: {{hostname}} will be replaced with label value for each series."
              >
                <button className="qa-opts-info-btn" aria-label="Legend help">
                  <HelpCircle size={13} />
                </button>
              </Tooltip>
            </div>
          </div>

          {/* Custom template input — shown only when Custom mode is active */}
          {legendMode === 'Custom' && (
            <div className="qa-opts-row qa-opts-row--indent">
              <label className="qa-opts-label" htmlFor="legend-input">Template</label>
              <input
                id="legend-input"
                className="qa-opts-input qa-opts-input--wide"
                value={legend}
                onChange={e => onLegendChange(e.target.value)}
                placeholder="e.g. {{hostname}}"
              />
            </div>
          )}

          {/* ── Min Step ── */}
          <div className="qa-opts-row">
            <label className="qa-opts-label" htmlFor="minstep-input">Min step</label>
            <div className="qa-opts-field-group">
              <div className="qa-opts-input-wrap">
                <input
                  id="minstep-input"
                  className="qa-opts-input qa-opts-input--sm"
                  value={minStep}
                  onChange={e => onMinStepChange(e.target.value)}
                  placeholder="auto"
                />
                <Tooltip
                  placement="top"
                  content="Lower limit for the step parameter in Prometheus queries. Example: 1m, 30s, 1h."
                >
                  <button className="qa-opts-info-btn" aria-label="Min step help">
                    <HelpCircle size={13} />
                  </button>
                </Tooltip>
              </div>
            </div>
          </div>

          {/* ── Format ── */}
          <div className="qa-opts-row">
            <label className="qa-opts-label">Format</label>
            <select
              className="qa-opts-select"
              value={format}
              onChange={e => onFormatChange(e.target.value as FormatType)}
              aria-label="Query result format"
            >
              <option value="Time series">Time series</option>
              <option value="Table">Table</option>
              <option value="Heatmap">Heatmap</option>
            </select>
          </div>

          {/* ── Type + Exemplars ── */}
          <div className="qa-opts-row qa-opts-row--type">
            <label className="qa-opts-label">Type</label>
            <div className="qa-type-group" role="group" aria-label="Query type">
              {(['Range', 'Instant', 'Both'] as QueryType[]).map(qt => (
                <Tooltip key={qt} content={queryTypeTooltips[qt]} placement="top">
                  <button
                    className={`qa-type-btn${queryType === qt ? ' qa-type-btn--active' : ''}`}
                    onClick={() => onQueryTypeChange(qt)}
                    aria-pressed={queryType === qt}
                  >
                    {qt}
                  </button>
                </Tooltip>
              ))}
            </div>

            {queryType !== 'Instant' && (
              <div className="qa-exemplars">
                <span className="qa-exemplars-label">Exemplars</span>
                <button
                  className={`qa-toggle${exemplars ? ' qa-toggle--on' : ''}`}
                  onClick={() => onExemplarsChange(!exemplars)}
                  role="switch"
                  aria-checked={exemplars}
                  aria-label="Toggle exemplars"
                >
                  <span className="qa-toggle-thumb" />
                </button>
              </div>
            )}
          </div>

        </div>
      )}
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════
   Query Accordion (main export)
   ═══════════════════════════════════════════════════════════ */
export interface QueryAccordionProps {
  id:          string;
  name:        string;
  datasource:  string;
  onRename:    (id: string, name: string) => void;
  onDuplicate: (id: string) => void;
  onDelete:    (id: string) => void;
}

export function QueryAccordion({
  id, name, datasource, onRename, onDuplicate, onDelete,
}: QueryAccordionProps) {
  /* Header state */
  const [isExpanded, setIsExpanded] = useState(false);
  const [isVisible,  setIsVisible]  = useState(true);
  const [isEditing,  setIsEditing]  = useState(false);
  const [editName,   setEditName]   = useState(name);
  const [isHovered,  setIsHovered]  = useState(false);
  const nameInputRef = useRef<HTMLInputElement>(null);

  /* Builder / Code view */
  const [activeView, setActiveView] = useState<'builder' | 'code'>('builder');
  const [codeQuery,  setCodeQuery]  = useState('');

  /* Metric */
  const [metric,       setMetric]       = useState('');
  const [metricOpen,   setMetricOpen]   = useState(false);
  const [metricSearch, setMetricSearch] = useState('');
  const metricRef = useRef<HTMLDivElement>(null);

  /* Label filters */
  const [labelFilters, setLabelFilters] = useState<LabelFilter[]>([
    { id: 'lf1', label: '', condition: '=',  value: '' },
    { id: 'lf2', label: '', condition: '!=', value: '' },
  ]);

  /* Operations */
  const [selectedOp, setSelectedOp] = useState('');

  /* Options */
  const [optionsExpanded, setOptionsExpanded] = useState(false);
  const [legend,          setLegend]          = useState('');
  const [legendMode,      setLegendMode]      = useState<LegendMode>('Auto');
  const [minStep,         setMinStep]         = useState('');
  const [format,          setFormat]          = useState<FormatType>('Time series');
  const [queryType,       setQueryType]       = useState<QueryType>('Range');
  const [exemplars,       setExemplars]       = useState(true);

  /* Close metric panel on outside click */
  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (metricRef.current && !metricRef.current.contains(e.target as Node)) {
        setMetricOpen(false);
      }
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  /* Focus name input on edit */
  useEffect(() => {
    if (isEditing) nameInputRef.current?.focus();
  }, [isEditing]);

  const commitName = () => {
    const trimmed = editName.trim();
    onRename(id, trimmed || name);
    if (!trimmed) setEditName(name);
    setIsEditing(false);
  };

  const handleNameKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter')  commitName();
    if (e.key === 'Escape') { setEditName(name); setIsEditing(false); }
  };

  const addFilter = () =>
    setLabelFilters(prev => [
      ...prev,
      { id: String(Date.now()), label: '', condition: '=', value: '' },
    ]);

  const removeFilter = (fid: string) =>
    setLabelFilters(prev => {
      const next = prev.filter(f => f.id !== fid);
      return next.length === 0
        ? [{ id: String(Date.now()), label: '', condition: '=', value: '' }]
        : next;
    });

  const updateFilter = (fid: string, updated: LabelFilter) =>
    setLabelFilters(prev => prev.map(f => f.id === fid ? updated : f));

  const filteredMetrics = METRIC_OPTIONS.filter(m =>
    m.toLowerCase().includes(metricSearch.toLowerCase())
  );

  const activeLabelCount = labelFilters.filter(f => f.label || f.value).length;

  return (
    <div
      className={[
        'qa-accordion',
        isExpanded ? 'qa-accordion--expanded' : '',
        !isVisible ? 'qa-accordion--hidden'   : '',
      ].filter(Boolean).join(' ')}
    >
      {/* ══ Header ══ */}
      <div
        className="qa-header"
        onMouseEnter={() => setIsHovered(true)}
        onMouseLeave={() => setIsHovered(false)}
      >
        <div className="qa-header-left">
          {/* Expand toggle */}
          <button
            className="qa-expand-btn"
            onClick={() => setIsExpanded(v => !v)}
            aria-label={isExpanded ? 'Collapse query' : 'Expand query'}
            aria-expanded={isExpanded}
          >
            <ChevronRight
              size={15}
              className={`qa-expand-icon${isExpanded ? ' qa-expand-icon--open' : ''}`}
              aria-hidden="true"
            />
          </button>

          {/* Name — inline editable */}
          {isEditing ? (
            <div className="qa-name-edit-wrap">
              <input
                ref={nameInputRef}
                className="qa-name-input"
                value={editName}
                onChange={e => setEditName(e.target.value)}
                onBlur={commitName}
                onKeyDown={handleNameKeyDown}
                aria-label="Query name"
              />
              <button className="qa-name-confirm" onClick={commitName} aria-label="Confirm rename">
                <Check size={11} />
              </button>
              <button
                className="qa-name-cancel"
                onClick={() => { setEditName(name); setIsEditing(false); }}
                aria-label="Cancel rename"
              >
                <X size={11} />
              </button>
            </div>
          ) : (
            <div className="qa-name-display">
              <span className="qa-name-text">{name}</span>
              {isHovered && (
                <button
                  className="qa-name-edit-btn"
                  onClick={() => setIsEditing(true)}
                  aria-label="Rename query"
                >
                  <Pencil size={11} />
                </button>
              )}
            </div>
          )}

          <span className="qa-ds-badge">{datasource}</span>
        </div>

        {/* Right icons */}
        <div className="qa-header-actions">
          <Tooltip content="Show data source help" placement="top">
            <button className="qa-icon-btn" aria-label="Show data source help">
              <HelpCircle size={15} />
            </button>
          </Tooltip>
          <Tooltip content="Duplicate Query" placement="top">
            <button
              className="qa-icon-btn"
              aria-label="Duplicate Query"
              onClick={() => onDuplicate(id)}
            >
              <Copy size={15} />
            </button>
          </Tooltip>
          <Tooltip content={isVisible ? 'Hide response' : 'Show response'} placement="top">
            <button
              className={`qa-icon-btn${!isVisible ? ' qa-icon-btn--muted' : ''}`}
              aria-label={isVisible ? 'Hide response' : 'Show response'}
              onClick={() => setIsVisible(v => !v)}
            >
              {isVisible ? <Eye size={15} /> : <EyeOff size={15} />}
            </button>
          </Tooltip>
          <Tooltip content="Remove Query" placement="top">
            <button
              className="qa-icon-btn qa-icon-btn--danger"
              aria-label="Remove Query"
              onClick={() => onDelete(id)}
            >
              <Trash2 size={15} />
            </button>
          </Tooltip>
        </div>
      </div>

      {/* ══ Content ══ */}
      {isExpanded && (
        <div className="qa-content">
          {/* Top bar */}
          <div className="qa-content-topbar">
            <button className="qa-kick-btn">Kick start your query</button>
            <div className="qa-view-toggle" role="group" aria-label="Query editor view">
              {(['builder', 'code'] as const).map(v => (
                <button
                  key={v}
                  className={`qa-view-btn${activeView === v ? ' qa-view-btn--active' : ''}`}
                  onClick={() => setActiveView(v)}
                  aria-pressed={activeView === v}
                >
                  {v.charAt(0).toUpperCase() + v.slice(1)}
                </button>
              ))}
            </div>
          </div>

          {activeView === 'builder' ? (
            <div className="qa-builder">
              {/* Metric + Label Filters */}
              <div className="qa-fields-row">
                {/* Metric */}
                <div className="qa-metric-group">
                  <label className="qa-field-label">Metric</label>
                  <div className="qa-metric-dd-wrap" ref={metricRef}>
                    <button
                      className="qa-metric-trigger"
                      onClick={() => setMetricOpen(v => !v)}
                      aria-haspopup="listbox"
                      aria-label="Select metric"
                    >
                      <span className="qa-metric-text">{metric || 'Select metric'}</span>
                      <ChevronDown size={12} aria-hidden="true" />
                    </button>
                    {metricOpen && (
                      <div className="qa-metric-panel" role="listbox">
                        <div className="qa-metric-search-wrap">
                          <input
                            className="qa-metric-search"
                            placeholder="Search metrics…"
                            value={metricSearch}
                            onChange={e => setMetricSearch(e.target.value)}
                            autoFocus
                            aria-label="Search metrics"
                          />
                        </div>
                        <div className="qa-metric-list">
                          {filteredMetrics.map(m => (
                            <div
                              key={m}
                              role="option"
                              aria-selected={metric === m}
                              className={`qa-metric-item${metric === m ? ' qa-metric-item--active' : ''}`}
                              onClick={() => {
                                setMetric(m);
                                setMetricOpen(false);
                                setMetricSearch('');
                              }}
                            >
                              {m}
                            </div>
                          ))}
                          {filteredMetrics.length === 0 && (
                            <div className="qa-metric-empty">No metrics found</div>
                          )}
                        </div>
                      </div>
                    )}
                  </div>
                </div>

                {/* Label Filters */}
                <div className="qa-lf-group">
                  <label className="qa-field-label">Label filters</label>
                  <div className="qa-lf-rows">
                    {labelFilters.map((filter, idx) => (
                      <LabelFilterRow
                        key={filter.id}
                        filter={filter}
                        onChange={updated => updateFilter(filter.id, updated)}
                        onRemove={() => removeFilter(filter.id)}
                        onAdd={addFilter}
                        isLast={idx === labelFilters.length - 1}
                      />
                    ))}
                  </div>
                </div>
              </div>

              {/* Fetch series info */}
              <div className="qa-fetch-row">
                <span className="qa-fetch-num" aria-hidden="true">1</span>
                <span className="qa-fetch-text">
                  Fetch all series matching metric name and label filters.
                  {metric && <strong> Metric: {metric}.</strong>}
                  {activeLabelCount > 0 && <strong> Active filters: {activeLabelCount}.</strong>}
                </span>
              </div>

              {/* Operations */}
              <div className="qa-ops-row">
                <OperationsDropdown onSelect={op => setSelectedOp(op)} />
                {selectedOp && (
                  <div className="qa-selected-op">
                    <span>{selectedOp}</span>
                    <button
                      className="qa-op-remove"
                      onClick={() => setSelectedOp('')}
                      aria-label="Remove selected operation"
                    >
                      <X size={11} />
                    </button>
                  </div>
                )}
              </div>

              {/* Options nested accordion */}
              <OptionsPanel
                isExpanded={optionsExpanded}
                onToggle={() => setOptionsExpanded(v => !v)}
                legend={legend}
                legendMode={legendMode}
                minStep={minStep}
                format={format}
                queryType={queryType}
                exemplars={exemplars}
                onLegendChange={setLegend}
                onLegendModeChange={setLegendMode}
                onMinStepChange={setMinStep}
                onFormatChange={setFormat}
                onQueryTypeChange={setQueryType}
                onExemplarsChange={setExemplars}
              />
            </div>
          ) : (
            /* Code view */
            <div className="qa-code-view">
              {/* Inline metrics query toolbar */}
              <div className="qa-code-toolbar">
                <button className="qa-code-metrics-btn" aria-label="Open metrics browser">
                  Metrics browser
                  <ChevronRight size={13} aria-hidden="true" />
                </button>
                <input
                  className="qa-code-input"
                  value={codeQuery}
                  onChange={e => setCodeQuery(e.target.value)}
                  placeholder="Enter metrics query…"
                  aria-label="PromQL query"
                  spellCheck={false}
                />
                <button className="qa-code-run-btn">Run</button>
              </div>

              {/* Fetch series info */}
              <div className="qa-fetch-row">
                <span className="qa-fetch-num" aria-hidden="true">1</span>
                <span className="qa-fetch-text">
                  Fetch all series matching metric name and label filters.
                </span>
              </div>

              {/* Operations */}
              <div className="qa-ops-row">
                <OperationsDropdown onSelect={op => setSelectedOp(op)} />
                {selectedOp && (
                  <div className="qa-selected-op">
                    <span>{selectedOp}</span>
                    <button
                      className="qa-op-remove"
                      onClick={() => setSelectedOp('')}
                      aria-label="Remove selected operation"
                    >
                      <X size={11} />
                    </button>
                  </div>
                )}
              </div>

              {/* Options */}
              <OptionsPanel
                isExpanded={optionsExpanded}
                onToggle={() => setOptionsExpanded(v => !v)}
                legend={legend}
                legendMode={legendMode}
                minStep={minStep}
                format={format}
                queryType={queryType}
                exemplars={exemplars}
                onLegendChange={setLegend}
                onLegendModeChange={setLegendMode}
                onMinStepChange={setMinStep}
                onFormatChange={setFormat}
                onQueryTypeChange={setQueryType}
                onExemplarsChange={setExemplars}
              />
            </div>
          )}
        </div>
      )}
    </div>
  );
}
