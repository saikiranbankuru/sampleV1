import { useState, useEffect, useRef } from 'react';
import { Calendar, ChevronLeft, ChevronRight, Clock } from 'lucide-react';
import './DateTimePicker.css';

/* ─── types ──────────────────────────────────────────────── */
export interface DateTimePickerProps {
  label: string;
  value: string;          // ISO: YYYY-MM-DDTHH:MM
  onChange: (iso: string) => void;
}

/* ─── helpers ─────────────────────────────────────────────── */
const MONTH_NAMES = [
  'January','February','March','April','May','June',
  'July','August','September','October','November','December',
];
const DOW = ['Mo','Tu','We','Th','Fr','Sa','Su'];

function parseISO(iso: string): Date | null {
  if (!iso) return null;
  const d = new Date(iso);
  return isNaN(d.getTime()) ? null : d;
}

function toISO(y: number, mo: number, d: number, h: number, mi: number): string {
  const p = (n: number) => String(n).padStart(2, '0');
  return `${y}-${p(mo + 1)}-${p(d)}T${p(h)}:${p(mi)}`;
}

function formatDisplay(iso: string): string {
  const d = parseISO(iso);
  if (!d) return '';
  const p = (n: number) => String(n).padStart(2, '0');
  return `${p(d.getDate())}-${p(d.getMonth() + 1)}-${d.getFullYear()} ${p(d.getHours())}:${p(d.getMinutes())}`;
}

function daysInMonth(y: number, mo: number): number {
  return new Date(y, mo + 1, 0).getDate();
}

/* first weekday of month: Mon=0 … Sun=6 */
function firstWeekday(y: number, mo: number): number {
  return (new Date(y, mo, 1).getDay() + 6) % 7;
}

/* ─── component ───────────────────────────────────────────── */
export function DateTimePicker({ label, value, onChange }: DateTimePickerProps) {
  const now    = new Date();
  const parsed = parseISO(value);

  const [isOpen,  setIsOpen]  = useState(false);
  const [viewY,   setViewY]   = useState(parsed?.getFullYear()  ?? now.getFullYear());
  const [viewMo,  setViewMo]  = useState(parsed?.getMonth()     ?? now.getMonth());
  const [selY,    setSelY]    = useState(parsed?.getFullYear()  ?? now.getFullYear());
  const [selMo,   setSelMo]   = useState(parsed?.getMonth()     ?? now.getMonth());
  const [selD,    setSelD]    = useState(parsed?.getDate()      ?? now.getDate());
  const [hours,   setHours]   = useState(parsed?.getHours()     ?? now.getHours());
  const [minutes, setMinutes] = useState(parsed?.getMinutes()   ?? now.getMinutes());

  const wrapperRef = useRef<HTMLDivElement>(null);

  /* sync when value prop changes externally */
  useEffect(() => {
    const d = parseISO(value);
    if (!d) return;
    setViewY(d.getFullYear()); setViewMo(d.getMonth());
    setSelY(d.getFullYear());  setSelMo(d.getMonth());
    setSelD(d.getDate());
    setHours(d.getHours());    setMinutes(d.getMinutes());
  }, [value]);

  /* close on outside click */
  useEffect(() => {
    if (!isOpen) return;
    const h = (e: MouseEvent) => {
      if (wrapperRef.current && !wrapperRef.current.contains(e.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', h);
    return () => document.removeEventListener('mousedown', h);
  }, [isOpen]);

  /* close on ESC */
  useEffect(() => {
    if (!isOpen) return;
    const h = (e: KeyboardEvent) => { if (e.key === 'Escape') setIsOpen(false); };
    document.addEventListener('keydown', h);
    return () => document.removeEventListener('keydown', h);
  }, [isOpen]);

  /* calendar grid */
  const totalDays = daysInMonth(viewY, viewMo);
  const offset    = firstWeekday(viewY, viewMo);
  const cells: (number | null)[] = [
    ...Array(offset).fill(null),
    ...Array.from({ length: totalDays }, (_, i) => i + 1),
  ];
  while (cells.length % 7 !== 0) cells.push(null);

  const prevMonth = () => {
    if (viewMo === 0) { setViewMo(11); setViewY(y => y - 1); }
    else setViewMo(m => m - 1);
  };
  const nextMonth = () => {
    if (viewMo === 11) { setViewMo(0); setViewY(y => y + 1); }
    else setViewMo(m => m + 1);
  };

  const selectDay = (day: number) => {
    setSelD(day); setSelY(viewY); setSelMo(viewMo);
  };

  const goToday = () => {
    const t = new Date();
    setViewY(t.getFullYear()); setViewMo(t.getMonth());
    setSelY(t.getFullYear());  setSelMo(t.getMonth());
    setSelD(t.getDate());
    setHours(t.getHours());    setMinutes(t.getMinutes());
  };

  const handleApply = () => {
    onChange(toISO(selY, selMo, selD, hours, minutes));
    setIsOpen(false);
  };

  const handleCancel = () => {
    const d = parseISO(value);
    if (d) {
      setViewY(d.getFullYear()); setViewMo(d.getMonth());
      setSelY(d.getFullYear());  setSelMo(d.getMonth());
      setSelD(d.getDate());
      setHours(d.getHours());    setMinutes(d.getMinutes());
    }
    setIsOpen(false);
  };

  const clamp = (v: number, lo: number, hi: number) => Math.max(lo, Math.min(hi, v));

  const isSelected = (day: number) =>
    day === selD && viewY === selY && viewMo === selMo;

  const isToday = (day: number) =>
    day === now.getDate() && viewY === now.getFullYear() && viewMo === now.getMonth();

  return (
    <div className="dtp-wrapper" ref={wrapperRef}>

      {/* ── trigger field ── */}
      <div className="dtp-field">
        <span className="dtp-label">{label}</span>
        <div
          className={`dtp-trigger${isOpen ? ' dtp-trigger--open' : ''}`}
          onClick={() => setIsOpen(v => !v)}
          role="button"
          tabIndex={0}
          onKeyDown={e => e.key === 'Enter' && setIsOpen(v => !v)}
        >
          <Calendar size={14} className="dtp-cal-icon" />
          <span className="dtp-display">
            {formatDisplay(value) || 'Select date & time'}
          </span>
        </div>
      </div>

      {/* ── popup (absolute, stays inside trp-wrapper) ── */}
      {isOpen && (
        <div className="dtp-popup">
          {/* month navigation */}
          <div className="dtp-month-nav">
            <button className="dtp-nav-btn" onClick={prevMonth} title="Previous month">
              <ChevronLeft size={14} />
            </button>
            <span className="dtp-month-label">
              {MONTH_NAMES[viewMo]} {viewY}
            </span>
            <button className="dtp-nav-btn" onClick={nextMonth} title="Next month">
              <ChevronRight size={14} />
            </button>
          </div>

          {/* calendar grid */}
          <div className="dtp-grid">
            {DOW.map(d => <span key={d} className="dtp-dow">{d}</span>)}
            {cells.map((day, i) =>
              day === null
                ? <span key={`e${i}`} className="dtp-cell dtp-cell--empty" />
                : <button
                    key={`d${i}`}
                    className={[
                      'dtp-cell',
                      isSelected(day) ? 'dtp-cell--selected' : '',
                      isToday(day) && !isSelected(day) ? 'dtp-cell--today' : '',
                    ].join(' ').trim()}
                    onClick={() => selectDay(day)}
                  >{day}</button>
            )}
          </div>

          {/* time + today */}
          <div className="dtp-time-row">
            <Clock size={13} className="dtp-time-icon" />
            <input
              type="number"
              className="dtp-time-input"
              value={String(hours).padStart(2, '0')}
              min={0} max={23}
              onChange={e => setHours(clamp(parseInt(e.target.value) || 0, 0, 23))}
            />
            <span className="dtp-time-sep">:</span>
            <input
              type="number"
              className="dtp-time-input"
              value={String(minutes).padStart(2, '0')}
              min={0} max={59}
              onChange={e => setMinutes(clamp(parseInt(e.target.value) || 0, 0, 59))}
            />
            <button className="dtp-today-btn" onClick={goToday}>Today</button>
          </div>

          {/* actions */}
          <div className="dtp-actions">
            <button className="dtp-cancel-btn" onClick={handleCancel}>Cancel</button>
            <button className="dtp-apply-btn"  onClick={handleApply}>Apply</button>
          </div>
        </div>
      )}
    </div>
  );
}
