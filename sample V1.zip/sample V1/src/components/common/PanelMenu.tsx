import { useState, useRef, useEffect, useCallback } from 'react';
import { createPortal } from 'react-dom';
import { MoreVertical, ChevronRight } from 'lucide-react';
import './PanelMenu.css';

export interface PanelMenuItem {
  id: string;
  label: string;
  onAction?: () => void;
  children?: PanelMenuItem[];
}

interface PanelMenuProps {
  items: PanelMenuItem[];
  triggerClassName?: string;
}

export function PanelMenu({ items, triggerClassName }: PanelMenuProps) {
  const [open,    setOpen]    = useState(false);
  const [pos,     setPos]     = useState({ top: 0, right: 0 });
  const [hovered, setHovered] = useState<string | null>(null);

  const triggerRef  = useRef<HTMLButtonElement>(null);
  const menuRef     = useRef<HTMLDivElement>(null);
  const submenuRefs = useRef<Map<string, HTMLDivElement>>(new Map());

  // Guard so the overflow-correction effect only runs once per open
  const posAdjusted = useRef(false);

  /* ── Step 1: compute initial position below trigger ───────── */
  useEffect(() => {
    if (!open) { posAdjusted.current = false; return; }
    if (!triggerRef.current) return;
    const r = triggerRef.current.getBoundingClientRect();
    setPos({ top: r.bottom + 4, right: window.innerWidth - r.right });
  }, [open]);

  /* ── Step 2: flip above trigger when menu overflows bottom ── */
  useEffect(() => {
    if (!open || posAdjusted.current) return;
    if (!menuRef.current || !triggerRef.current) return;

    const menu    = menuRef.current;
    const trigger = triggerRef.current.getBoundingClientRect();
    const rect    = menu.getBoundingClientRect();

    if (rect.bottom > window.innerHeight - 8) {
      posAdjusted.current = true;
      setPos({
        top:   Math.max(8, trigger.top - rect.height - 4),
        right: window.innerWidth - trigger.right,
      });
    }
  }, [pos, open]);


  /* ── Close on scroll / resize — fixed pos becomes stale ─── */
  useEffect(() => {
    if (!open) return;
    const dismiss = () => { setOpen(false); setHovered(null); };
    // capture:true catches scroll fired on any scrollable ancestor
    window.addEventListener('scroll', dismiss, true);
    window.addEventListener('resize', dismiss);
    return () => {
      window.removeEventListener('scroll', dismiss, true);
      window.removeEventListener('resize', dismiss);
    };
  }, [open]);

  /* ── Close on outside click ─────────────────────────────── */
  useEffect(() => {
    if (!open) return;
    const handler = (e: MouseEvent) => {
      const t = e.target as Node;
      if (triggerRef.current?.contains(t) || menuRef.current?.contains(t)) return;
      setOpen(false);
      setHovered(null);
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, [open]);

  /* ── Close on Escape ────────────────────────────────────── */
  useEffect(() => {
    if (!open) return;
    const handler = (e: KeyboardEvent) => {
      if (e.key === 'Escape') { setOpen(false); setHovered(null); }
    };
    document.addEventListener('keydown', handler);
    return () => document.removeEventListener('keydown', handler);
  }, [open]);

  /* ── Flip submenu: left if overflows right, up if overflows bottom */
  useEffect(() => {
    if (!hovered) return;
    const el = submenuRefs.current.get(hovered);
    if (!el) return;

    // Reset
    el.style.left   = '';
    el.style.right  = '';
    el.style.top    = '';
    el.style.bottom = '';

    const rect = el.getBoundingClientRect();

    if (rect.right  > window.innerWidth  - 8) { el.style.left = 'auto'; el.style.right  = '100%'; }
    if (rect.bottom > window.innerHeight - 8) { el.style.top  = 'auto'; el.style.bottom = '0';    }
  }, [hovered]);

  const close = useCallback(() => { setOpen(false); setHovered(null); }, []);

  const handleItemClick = useCallback((item: PanelMenuItem) => {
    if (item.children) {
      setHovered(v => (v === item.id ? null : item.id));
    } else {
      item.onAction?.();
      close();
    }
  }, [close]);

  return (
    <>
      <div className="pm-wrap">
        <button
          ref={triggerRef}
          className={`pm-trigger${open ? ' pm-trigger--active' : ''}${triggerClassName ? ` ${triggerClassName}` : ''}`}
          onClick={() => { setOpen(v => !v); setHovered(null); }}
          aria-haspopup="true"
          aria-expanded={open}
          aria-label="Panel options"
        >
          <MoreVertical size={15} />
        </button>
      </div>

      {open && createPortal(
        <div
          ref={menuRef}
          className="pm-menu"
          role="menu"
          aria-label="Panel options"
          style={{ top: pos.top, right: pos.right }}
        >
          {items.map(item => (
            <div
              key={item.id}
              className="pm-item-wrap"
              onMouseEnter={() => setHovered(item.children ? item.id : null)}
              onMouseLeave={() => setHovered(v => (v === item.id ? null : v))}
            >
              <button
                className={`pm-item${hovered === item.id ? ' pm-item--hover' : ''}`}
                role="menuitem"
                tabIndex={0}
                aria-haspopup={item.children ? 'true' : undefined}
                aria-expanded={item.children ? hovered === item.id : undefined}
                onClick={() => handleItemClick(item)}
                onKeyDown={e => {
                  if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); handleItemClick(item); }
                  if (e.key === 'ArrowRight' && item.children) setHovered(item.id);
                  if (e.key === 'ArrowLeft') setHovered(null);
                  if (e.key === 'Escape') close();
                }}
              >
                <span className="pm-item-label">{item.label}</span>
                {item.children && (
                  <ChevronRight size={13} className="pm-item-chevron" aria-hidden="true" />
                )}
              </button>

              {item.children && hovered === item.id && (
                <div
                  className="pm-submenu"
                  role="menu"
                  ref={el => {
                    if (el) submenuRefs.current.set(item.id, el);
                    else    submenuRefs.current.delete(item.id);
                  }}
                >
                  {item.children.map(child => (
                    <button
                      key={child.id}
                      className="pm-item"
                      role="menuitem"
                      tabIndex={0}
                      onClick={() => { child.onAction?.(); close(); }}
                      onKeyDown={e => {
                        if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); child.onAction?.(); close(); }
                        if (e.key === 'ArrowLeft') setHovered(null);
                        if (e.key === 'Escape') close();
                      }}
                    >
                      <span className="pm-item-label">{child.label}</span>
                    </button>
                  ))}
                </div>
              )}
            </div>
          ))}
        </div>,
        document.body,
      )}
    </>
  );
}
