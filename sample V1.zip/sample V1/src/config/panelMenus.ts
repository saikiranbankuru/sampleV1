import type { PanelMenuItem } from '../components/common/PanelMenu';

export const DEFAULT_PANEL_MENU: PanelMenuItem[] = [
  { id: 'view', label: 'View', onAction: () => {} },
  { id: 'edit', label: 'Edit', onAction: () => {} },
  {
    id: 'share', label: 'Share',
    children: [
      { id: 'share-link',     label: 'Share link',     onAction: () => {} },
      { id: 'share-embed',    label: 'Share embed',    onAction: () => {} },
      { id: 'share-snapshot', label: 'Share snapshot', onAction: () => {} },
    ],
  },
  { id: 'explore', label: 'Explore', onAction: () => {} },
  {
    id: 'inspect', label: 'Inspect',
    children: [
      { id: 'inspect-data',  label: 'Data',       onAction: () => {} },
      { id: 'inspect-query', label: 'Query',       onAction: () => {} },
      { id: 'inspect-json',  label: 'Panel JSON',  onAction: () => {} },
    ],
  },
  {
    id: 'more', label: 'More',
    children: [
      { id: 'more-copy',  label: 'Copy',           onAction: () => {} },
      { id: 'more-alert', label: 'New alert rule', onAction: () => {} },
      { id: 'more-help',  label: 'Get help',       onAction: () => {} },
    ],
  },
];

export const NO_EXPLORE_MENU: PanelMenuItem[] = DEFAULT_PANEL_MENU.filter(
  item => item.id !== 'explore',
);
