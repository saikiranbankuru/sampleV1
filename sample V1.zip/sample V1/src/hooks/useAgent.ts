import { useState, useEffect } from 'react';
import type { AgentDetails } from '../types/agent';
import { fetchAgentById } from '../services/agentApi';

export interface UseAgentResult {
  agent: AgentDetails | null;
  loading: boolean;
  error: string | null;
}

export function useAgent(id: string): UseAgentResult {
  const [agent, setAgent] = useState<AgentDetails | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    setError(null);
    fetchAgentById(id)
      .then(data => { if (!cancelled) setAgent(data); })
      .catch(() => { if (!cancelled) setError('Failed to load agent details.'); })
      .finally(() => { if (!cancelled) setLoading(false); });
    return () => { cancelled = true; };
  }, [id]);

  return { agent, loading, error };
}
