import { useState, useEffect } from 'react';
import type { AgentLog, LogType } from '../types/agent';
import { fetchAgentLogs } from '../services/agentApi';

export interface UseAgentLogsResult {
  logs: AgentLog[];
  loading: boolean;
}

/**
 * Fetches logs for a specific agent + log type.
 * To switch to a real API, update fetchAgentLogs in agentApi.ts — this hook stays unchanged.
 */
export function useAgentLogs(agentId: string, type: LogType): UseAgentLogsResult {
  const [logs, setLogs]       = useState<AgentLog[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    setLogs([]);
    fetchAgentLogs(agentId, type)
      .then(data  => { if (!cancelled) setLogs(data); })
      .catch(()   => { if (!cancelled) setLogs([]);   })
      .finally(() => { if (!cancelled) setLoading(false); });
    return () => { cancelled = true; };
  }, [agentId, type]);

  return { logs, loading };
}
