import { NavLink } from 'react-router-dom';
import { Link2 } from 'lucide-react';
import './CorrelationsPage.css';

export default function CorrelationsPage() {
  return (
    <div className="correlations-page">
      <nav className="correlations-breadcrumb">
        <span className="correlations-breadcrumb-link">Home</span>
        <span className="correlations-sep">›</span>
        <span className="correlations-breadcrumb-link">Administration</span>
        <span className="correlations-sep">›</span>
        <NavLink to="/admin/plugins" className="correlations-breadcrumb-link">
          Plugins and Data
        </NavLink>
        <span className="correlations-sep">›</span>
        <span className="correlations-breadcrumb-current">Correlations</span>
      </nav>

      <h1 className="correlations-title">Correlations</h1>

      <div className="correlations-tabs">
        <NavLink to="/admin/plugins" end className={({ isActive }) => `correlations-tab${isActive ? ' correlations-tab--active' : ''}`}>
          Plugins
        </NavLink>
        <NavLink to="/admin/plugins/correlations" className={({ isActive }) => `correlations-tab${isActive ? ' correlations-tab--active' : ''}`}>
          Correlations
        </NavLink>
      </div>

      <div className="correlations-card">
        <div className="correlations-empty">
          <div className="correlations-empty-icon">
            <Link2 size={32} />
          </div>
          <p className="correlations-empty-title">No correlations defined yet</p>
          <p className="correlations-empty-desc">
            Correlations let you link data from different sources so you can jump between
            related metrics, logs, and traces directly from a panel.
          </p>
          <button className="correlations-add-btn">+ Add Correlation</button>
        </div>
      </div>
    </div>
  );
}
