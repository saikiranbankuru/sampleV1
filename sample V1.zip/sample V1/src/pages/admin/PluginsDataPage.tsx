import { NavLink } from 'react-router-dom';
import { Package, Database, BarChart2, Cloud, Activity, Layers } from 'lucide-react';
import './PluginsDataPage.css';

const PLUGINS = [
  { name: 'Prometheus', type: 'Data Source', version: '9.5.0', status: 'Active', icon: Activity },
  { name: 'MySQL', type: 'Data Source', version: '2.1.1', status: 'Active', icon: Database },
  { name: 'PostgreSQL', type: 'Data Source', version: '1.3.0', status: 'Active', icon: Database },
  { name: 'CloudWatch', type: 'Data Source', version: '3.2.0', status: 'Active', icon: Cloud },
  { name: 'Loki', type: 'Data Source', version: '5.0.0', status: 'Active', icon: Layers },
  { name: 'Panel Graph', type: 'Panel Plugin', version: '4.1.2', status: 'Active', icon: BarChart2 },
  { name: 'Alertmanager', type: 'Data Source', version: '1.0.1', status: 'Inactive', icon: Package },
];

export default function PluginsDataPage() {
  return (
    <div className="plugins-page">
      <nav className="plugins-breadcrumb">
        <span className="plugins-breadcrumb-link">Home</span>
        <span className="plugins-sep">›</span>
        <span className="plugins-breadcrumb-link">Administration</span>
        <span className="plugins-sep">›</span>
        <span className="plugins-breadcrumb-current">Plugins and Data</span>
      </nav>

      <h1 className="plugins-title">Plugins and Data</h1>

      <div className="plugins-tabs">
        <NavLink to="/admin/plugins" end className={({ isActive }) => `plugins-tab${isActive ? ' plugins-tab--active' : ''}`}>
          Plugins
        </NavLink>
        <NavLink to="/admin/plugins/correlations" className={({ isActive }) => `plugins-tab${isActive ? ' plugins-tab--active' : ''}`}>
          Correlations
        </NavLink>
      </div>

      <div className="plugins-card">
        <div className="plugins-filter-row">
          <input className="plugins-search" placeholder="Search plugins…" />
          <div className="plugins-filter-actions">
            <select className="plugins-select">
              <option>All Types</option>
              <option>Data Source</option>
              <option>Panel Plugin</option>
            </select>
            <select className="plugins-select">
              <option>All Status</option>
              <option>Active</option>
              <option>Inactive</option>
            </select>
          </div>
        </div>

        <div className="plugins-list">
          {PLUGINS.map(p => {
            const Icon = p.icon;
            return (
              <div key={p.name} className="plugins-item">
                <div className="plugins-item-icon-wrap">
                  <Icon size={18} className="plugins-item-icon" />
                </div>
                <div className="plugins-item-info">
                  <span className="plugins-item-name">{p.name}</span>
                  <span className="plugins-item-type">{p.type}</span>
                </div>
                <span className="plugins-item-version">v{p.version}</span>
                <span className={`plugins-item-status plugins-item-status--${p.status.toLowerCase()}`}>
                  {p.status}
                </span>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
