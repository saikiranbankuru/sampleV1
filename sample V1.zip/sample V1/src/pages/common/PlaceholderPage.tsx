import './PlaceholderPage.css';

interface PlaceholderPageProps {
  title: string;
}

export default function PlaceholderPage({ title }: PlaceholderPageProps) {
  return (
    <div className="placeholder-page">
      <nav className="placeholder-breadcrumb">
        <span>Home</span>
        <span className="placeholder-sep">&gt;</span>
        <span>{title}</span>
      </nav>
      <h1 className="placeholder-title">{title}</h1>
      <div className="placeholder-body">
        <p>This section is under construction.</p>
      </div>
    </div>
  );
}
