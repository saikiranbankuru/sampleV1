import { useState } from 'react';
import { User, Mail } from 'lucide-react';
import './Login.css';

export default function Login() {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');

  const handleSubmit = (e: { preventDefault: () => void }) => {
    e.preventDefault();
  };

  return (
    <div className="login-page">
      {/* Left Panel */}
      <div className="login-left">
        <div className="login-logo">
          <span className="login-logo-text">Logo here</span>
        </div>
      </div>

      {/* Right Panel */}
      <div className="login-right">
        <div className="login-form-wrapper">
          <h1 className="login-title">Login</h1>
          <p className="login-subtitle">Please fill your information below</p>

          <form onSubmit={handleSubmit} className="login-form">
            {/* Name Field */}
            <div className="login-input-group">
              <span className="login-input-icon">
                <User size={18} color="#6D706B" />
              </span>
              <input
                type="text"
                className="login-input"
                placeholder="Name"
                value={name}
                onChange={e => setName(e.target.value)}
                autoComplete="name"
              />
            </div>

            {/* Email Field */}
            <div className="login-input-group">
              <span className="login-input-icon">
                <Mail size={18} color="#6D706B" />
              </span>
              <input
                type="email"
                className="login-input"
                placeholder="E-mail"
                value={email}
                onChange={e => setEmail(e.target.value)}
                autoComplete="email"
              />
            </div>

            {/* Login Button */}
            <button type="submit" className="login-btn">
              Login
            </button>
          </form>

          {/* Footer */}
          <div className="login-footer">
            <span className="login-footer-text">Already have an account</span>
            <a href="#" className="login-footer-link">Login to your account</a>
          </div>
        </div>
      </div>
    </div>
  );
}
