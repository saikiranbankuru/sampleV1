import { useEffect, useState, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { RefreshCw, Share2, MoreVertical } from 'lucide-react';
import { TimeRangePicker } from '../../components/common/TimeRangePicker';
import { MetricCard } from '../../components/dashboard/MetricCard';
import { SectionCard } from '../../components/dashboard/SectionCard';
import { AgentsLastRun } from '../../components/dashboard/AgentsLastRun';
import { TicketAgentMapping } from '../../components/dashboard/TicketAgentMapping';
import { CasesWorked } from '../../components/dashboard/CasesWorked';
import { AvailableAgents } from '../../components/dashboard/AvailableAgents';
import { IncidentList } from '../../components/dashboard/IncidentList';
import { fetchAllDashboardData } from '../../services/dashboardApi';
import type { DashboardData } from '../../types/dashboard';
import { DEFAULT_PANEL_MENU, NO_EXPLORE_MENU } from '../../config/panelMenus';
import './HomePage.css';

export default function HomePage() {
  const navigate = useNavigate();
  const [data, setData] = useState<DashboardData | null>(null);
  const [loading, setLoading] = useState(true);
  const [spinning, setSpinning] = useState(false);
  const [timeRange, setTimeRange] = useState('Last 5 Minutes');

  const load = useCallback(async () => {
    setSpinning(true);
    setLoading(data === null);
    try {
      const result = await fetchAllDashboardData();
      setData(result);
    } finally {
      setLoading(false);
      setSpinning(false);
    }
  }, [data]);

  useEffect(() => { load(); }, []); // eslint-disable-line react-hooks/exhaustive-deps

  return (
    <div className="hp-page">
      {/* Page header */}
      <div className="hp-header">
        <nav className="hp-breadcrumb" aria-label="breadcrumb">
          <span className="hp-breadcrumb-link">Home</span>
          <span className="hp-breadcrumb-sep">&rsaquo;</span>
          <span className="hp-breadcrumb-current">Dashboard</span>
        </nav>

        <div className="hp-controls">
          <button className="hp-ctrl-btn" title="Share">
            <Share2 size={14} />
          </button>

          <button
            className={`hp-ctrl-btn hp-refresh-btn${spinning ? ' hp-refresh-btn--spinning' : ''}`}
            onClick={load}
            title="Refresh"
          >
            <RefreshCw size={14} />
            <span>Refresh</span>
          </button>

          <TimeRangePicker
            value={timeRange}
            onApply={r => setTimeRange(r.preset ?? 'Custom Range')}
          />

          <button className="hp-ctrl-btn" title="More options">
            <MoreVertical size={15} />
          </button>
        </div>
      </div>

      {/* Metric cards */}
      {loading ? (
        <div className="hp-metrics">
          {[...Array(4)].map((_, i) => (
            <div key={i} className="hp-metric-skeleton" />
          ))}
        </div>
      ) : (
        <div className="hp-metrics">
          <MetricCard label="Total Tickets" value={data!.metrics.totalTickets} />
          <MetricCard label="Active Agents" value={data!.metrics.activeAgents} />
          <MetricCard label="Total Cases Processed" value={data!.metrics.totalCasesProcessed} />
          <MetricCard label="Failed Cases" value={data!.metrics.failedCases} />
        </div>
      )}

      {/* Two-column flat grid — CSS grid aligns row heights automatically */}
      <div className="hp-grid">
        <SectionCard title="Agents &amp; Last Run" onViewMore={() => {}} menuItems={DEFAULT_PANEL_MENU}>
          <AgentsLastRun agents={data?.agentRuns ?? []} />
        </SectionCard>

        <SectionCard title="Ticket to Agent Mapping" onViewMore={() => navigate('/tickets')} menuItems={DEFAULT_PANEL_MENU}>
          <TicketAgentMapping tickets={data?.ticketMappings ?? []} />
        </SectionCard>

        <SectionCard title="Number of Cases Worked" onViewMore={() => {}} menuItems={DEFAULT_PANEL_MENU}>
          <CasesWorked cases={data?.casesWorked ?? []} />
        </SectionCard>

        <SectionCard title="Available Agents" onViewMore={() => {}} menuItems={NO_EXPLORE_MENU}>
          <AvailableAgents agents={data?.availableAgents ?? []} />
        </SectionCard>

        <SectionCard title="Incident" onViewMore={() => {}} menuItems={DEFAULT_PANEL_MENU}>
          <IncidentList incidents={data?.incidents ?? []} />
        </SectionCard>
      </div>
    </div>
  );
}
