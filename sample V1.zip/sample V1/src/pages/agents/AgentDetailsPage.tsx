import { useState, memo } from 'react';
import { useParams, Link } from 'react-router-dom';
import {
  RefreshCw, Share2, MoreVertical, ChevronDown, BarChart2, Info, Copy,
  AlertCircle, AlertTriangle,
} from 'lucide-react';
import { PanelMenu } from '../../components/common/PanelMenu';
import type { PanelMenuItem } from '../../components/common/PanelMenu';
import { DEFAULT_PANEL_MENU } from '../../config/panelMenus';
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid,
  ResponsiveContainer, Cell,
  LineChart, Line, Tooltip,
} from 'recharts';
import { SectionCard } from '../../components/dashboard/SectionCard';
import CircularGauge from '../../components/dashboard/CircularGauge';
import { useAgent } from '../../hooks/useAgent';
import type { LogType, AgentLog } from '../../types/agent';
import { Modal } from '../../components/common/Modal';
import { TimeRangePicker } from '../../components/common/TimeRangePicker';
import { useAgentLogs } from '../../hooks/useAgentLogs';
import './AgentDetailsPage.css';

/* ─── constants ─────────────────────────────────────────── */
const BAR_COLORS = ['#14B8A6', '#22D3EE', '#1E2A3A', '#FBBF24', '#A78BFA', '#34D399'];

const BADGE_METRICS = [
  { key: 'cpuUsage',      label: 'CPU Usage(%)',      color: '#F59E0B' },
  { key: 'memoryUsage',   label: 'Memory Usage(%)',   color: '#F43F5E' },
  { key: 'accuracyScore', label: 'Accuracy Score(%)', color: '#84CC16' },
] as const;

type MetricKey = typeof BADGE_METRICS[number]['key'];

/* ─── sub-components ────────────────────────────────────── */
const MetricGaugeCard = memo(({
  label, subLabel, value, max, color, variant, menuItems,
}: {
  label: string;
  subLabel?: string;
  value: number;
  max?: number;
  color: string;
  variant?: 'full' | 'semi';
  menuItems: PanelMenuItem[];
}) => (
  <div className="ad-gauge-card">
    <div className="ad-gauge-card-header">
      <div>
        <p className="ad-gauge-label">{label}</p>
        {subLabel && <p className="ad-gauge-sublabel">{subLabel}</p>}
      </div>
      <PanelMenu items={menuItems} />
    </div>
    <div className="ad-gauge-center">
      <CircularGauge value={value} max={max} color={color} size={88} strokeWidth={9} variant={variant} valueSize={20} />
    </div>
  </div>
));

const LatencyCard = memo(({ value, menuItems }: { value: number; menuItems: PanelMenuItem[] }) => (
  <div className="ad-gauge-card">
    <div className="ad-gauge-card-header">
      <div>
        <p className="ad-gauge-label">Avg Latency</p>
        <p className="ad-gauge-sublabel">(Ms)</p>
      </div>
      <PanelMenu items={menuItems} />
    </div>
    <div className="ad-latency-value">{value.toFixed(2)}</div>
  </div>
));

const BadgeMetric = memo(({
  value, label, color, menuItems,
}: {
  value: number; label: string; color: string; menuItems: PanelMenuItem[];
}) => (
  <div className="ad-badge-row">
    <span className="ad-badge-num" style={{ background: color }}>
      {String(value).padStart(2, '0')}
    </span>
    <span className="ad-badge-label">{label}</span>
    <PanelMenu items={menuItems} />
  </div>
));

/* ─── log context mock data ─────────────────────────────── */
const LOG_CTX: Record<LogType, {
  serviceName: string; agentName: string; action: string; target: string;
  confidence: number; details: string;
  extractedAction: string; extractedAgent: string; filepath: string; fn: string;
}> = {
  info: {
    serviceName: 'Agentic-AI-IT-Operations', agentName: 'retrieval_agent',
    action: 'knowledge_base_lookup', target: 'chroma_db',
    confidence: 0.1, details: 'Found 2 solutions (Avg similarity: 0.10)',
    extractedAction: 'external_research', extractedAgent: 'retrieval_agent',
    filepath: 'C:/Codes/resolutionAutogen/kb_lookup', fn: 'log_agent_action',
  },
  warning: {
    serviceName: 'Agentic-AI-IT-Operations', agentName: 'planning_agent',
    action: 'confidence_threshold_check', target: 'planning_module',
    confidence: 0.35, details: 'Confidence below threshold (0.35), escalating to review',
    extractedAction: 'threshold_warning', extractedAgent: 'planning_agent',
    filepath: 'C:/Codes/resolutionAutogen/planning/threshold_check', fn: 'log_agent_warning',
  },
  error: {
    serviceName: 'Agentic-AI-IT-Operations', agentName: 'execution_agent',
    action: 'code_execution', target: 'code_interpreter',
    confidence: 0.0, details: 'RuntimeError: execution timeout after 30s',
    extractedAction: 'execution_error', extractedAgent: 'execution_agent',
    filepath: 'C:/Codes/resolutionAutogen/executor/run_code', fn: 'log_agent_error',
  },
};

/* ─── log context modal content ─────────────────────────── */
const LogContextContent = memo(({ log }: { log: AgentLog }) => {
  const ctx = LOG_CTX[log.type];
  const [widenTags,  setWidenTags]  = useState<string[]>([`Service_name+"${ctx.serviceName}"`]);
  const [refineTags, setRefineTags] = useState<string[]>([`agent+ "${ctx.agentName}"`]);
  const [expandedRow, setExpandedRow] = useState<string | null>('Code_function');

  const logLine = JSON.stringify({
    timestamp: log.timestamp, record: log.record, agent: ctx.agentName,
    action: ctx.action, target: ctx.target, confidence: ctx.confidence, details: ctx.details,
  }, null, 2);

  const labels = [
    { name: 'Action',        value: ctx.extractedAction, detail: { note: 'Action: 1 of 1 rows have that label',        link: ctx.extractedAction, count: 1, pct: '100%' } },
    { name: 'Agent',         value: ctx.extractedAgent,  detail: { note: 'Agent: 1 of 1 rows have that label',         link: ctx.extractedAgent,  count: 1, pct: '100%' } },
    { name: 'Code_filepath', value: ctx.filepath,        detail: { note: 'Code_filepath: 1 of 1 rows have that label', link: ctx.filepath,        count: 1, pct: '100%' } },
    { name: 'Code_function', value: ctx.fn,              detail: { note: 'Code_function: 1 of 1 rows have that label', link: ctx.fn,              count: 1, pct: '100%' } },
  ];

  const handleCopy = () => { navigator.clipboard.writeText(logLine).catch(() => {}); };

  return (
    <div className="ad-log-ctx">

      {/* ── header ── */}
      <div className="ad-log-ctx-header">
        <h3 className="ad-log-ctx-title">Log Context</h3>
        <div className="ad-log-ctx-header-actions">
          <button className="ad-log-ctx-action-btn" title="Share"><Share2 size={14} /></button>
          <button className="ad-log-ctx-action-btn" title="Copy log line" onClick={handleCopy}><Copy size={14} /></button>
          <button className="ad-log-ctx-action-btn" title="More options"><MoreVertical size={14} /></button>
        </div>
      </div>

      {/* ── filter chips ── */}
      <div className="ad-log-ctx-filters">
        <span className="ad-log-ctx-chip ad-log-ctx-chip--blue">{`{service_name="${ctx.serviceName}"}`}</span>
        <span className="ad-log-ctx-sep"> | </span>
        <span className="ad-log-ctx-chip">json</span>
        <span className="ad-log-ctx-sep"> | </span>
        <span className="ad-log-ctx-chip ad-log-ctx-chip--green">agent = {ctx.agentName}</span>
        <span className="ad-log-ctx-sep"> | </span>
        <span className="ad-log-ctx-chip">label_format level=detected_level</span>
        <Info size={13} className="ad-log-ctx-info-icon" />
      </div>

      {/* ── widen search ── */}
      <div className="ad-log-ctx-section">
        <p className="ad-log-ctx-section-label">Widen the search</p>
        <p className="ad-log-ctx-section-desc">
          The initial log context query is created from all tables defining the stream for the
          selected log line. You can broaden your search by removing one or more of the label filters.
        </p>
        <div className="ad-log-ctx-tag-field">
          {widenTags.length === 0
            ? <span className="ad-log-ctx-tag-placeholder">No filters applied</span>
            : widenTags.map((tag, i) => (
              <span key={i} className="ad-log-ctx-tag-chip">
                <span className="ad-log-ctx-tag-chip-text">{tag}</span>
                <button
                  className="ad-log-ctx-tag-remove"
                  onClick={() => setWidenTags(prev => prev.filter((_, idx) => idx !== i))}
                  title="Remove filter"
                >×</button>
              </span>
            ))
          }
        </div>
      </div>

      {/* ── refine search ── */}
      <div className="ad-log-ctx-section">
        <p className="ad-log-ctx-section-label">Refine the search</p>
        <p className="ad-log-ctx-section-desc">
          By using a parser in your original query, you can use filters for extracted labels.
          Refine your search by applying extracted labels created from the selected log line.
        </p>
        <div className="ad-log-ctx-tag-field">
          {refineTags.length === 0
            ? <span className="ad-log-ctx-tag-placeholder">No filters applied</span>
            : refineTags.map((tag, i) => (
              <span key={i} className="ad-log-ctx-tag-chip">
                <span className="ad-log-ctx-tag-chip-text">{tag}</span>
                <button
                  className="ad-log-ctx-tag-remove"
                  onClick={() => setRefineTags(prev => prev.filter((_, idx) => idx !== i))}
                  title="Remove filter"
                >×</button>
              </span>
            ))
          }
        </div>
      </div>

      {/* ── pipeline ── */}
      <div className="ad-log-ctx-pipeline">
        <span>Include LogQL pipeline operations</span>
        <Info size={13} className="ad-log-ctx-info-icon" />
      </div>

      {/* ── log line ── */}
      <div className="ad-log-ctx-section">
        <p className="ad-log-ctx-section-label">Log  Line</p>
        <pre className="ad-log-ctx-codeline">{logLine}</pre>
      </div>

      {/* ── extracted labels ── */}
      <div className="ad-log-ctx-labels">
        {labels.map(row => (
          <div key={row.name}>
            <div className="ad-log-ctx-label-row">
              <button
                className={`ad-log-ctx-bar-btn${expandedRow === row.name ? ' ad-log-ctx-bar-btn--active' : ''}`}
                onClick={() => setExpandedRow(expandedRow === row.name ? null : row.name)}
                title={expandedRow === row.name ? 'Collapse' : 'Expand'}
              >
                <BarChart2 size={13} />
              </button>
              <span className="ad-log-ctx-label-name">{row.name}</span>
              <span className="ad-log-ctx-label-val">{row.value}</span>
            </div>
            {expandedRow === row.name && (
              <div className="ad-log-ctx-label-detail">
                <p className="ad-log-ctx-fn-note">{row.detail.note}</p>
                <div className="ad-log-ctx-fn-link">
                  <span className="ad-log-ctx-link">{row.detail.link}</span>
                  <span className="ad-log-ctx-fn-count">{row.detail.count}</span>
                  <span className="ad-log-ctx-fn-pct">{row.detail.pct}</span>
                </div>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
});

/* ─── logs empty state ───────────────────────────────────── */
const EMPTY_CFG: Record<LogType, { color: string; label: string; sub: string }> = {
  info:    { color: '#60a5fa', label: 'No info logs',    sub: 'All systems are operating normally.'       },
  error:   { color: '#f43f5e', label: 'No error logs',   sub: 'No errors have been recorded.'            },
  warning: { color: '#fbbf24', label: 'No warning logs', sub: 'No warnings have been detected.'          },
};

const LogsEmptyState = ({ type }: { type: LogType }) => {
  const cfg  = EMPTY_CFG[type];
  const Icon = type === 'error' ? AlertCircle : type === 'warning' ? AlertTriangle : Info;
  return (
    <div className="ad-logs-empty">
      <span className="ad-logs-empty-icon" style={{ color: cfg.color }}><Icon size={30} /></span>
      <p className="ad-logs-empty-title">{cfg.label}</p>
      <p className="ad-logs-empty-sub">{cfg.sub}</p>
    </div>
  );
};

/* ─── logs loading skeleton ──────────────────────────────── */
const LogsLoadingSkeleton = () => (
  <>
    {Array.from({ length: 5 }).map((_, i) => (
      <div key={i} className="ad-log-entry ad-log-entry--skeleton" />
    ))}
  </>
);

/* ─── logs panel ─────────────────────────────────────────── */
const TABS: { key: LogType; label: string }[] = [
  { key: 'info',    label: 'Info Logs'    },
  { key: 'error',   label: 'Error Logs'   },
  { key: 'warning', label: 'Warning Logs' },
];

const LogsPanel = memo(({ agentId, menuItems }: { agentId: string; menuItems: PanelMenuItem[] }) => {
  const [activeTab,   setActiveTab]   = useState<LogType>('info');
  const [selectedLog, setSelectedLog] = useState<AgentLog | null>(null);
  const { logs, loading } = useAgentLogs(agentId, activeTab);

  return (
    <div className="ad-logs-panel">
      <div className="ad-logs-tabs">
        {TABS.map(t => (
          <button
            key={t.key}
            className={`ad-logs-tab${activeTab === t.key ? ' ad-logs-tab--active' : ''}`}
            onClick={() => setActiveTab(t.key)}
          >
            {t.label}
          </button>
        ))}
        <PanelMenu items={menuItems} />
      </div>

      <div className="ad-logs-scroll">
        <div className="ad-logs-track" />
        {loading ? (
          <LogsLoadingSkeleton />
        ) : logs.length === 0 ? (
          <LogsEmptyState type={activeTab} />
        ) : (
          logs.map(log => (
            <div
              key={log.id}
              className="ad-log-entry"
              onClick={() => setSelectedLog(log)}
            >
              {`{TIMESTAMP:"${log.timestamp}"; "RECORD: "${log.record}"":…`}
            </div>
          ))
        )}
      </div>

      <Modal isOpen={selectedLog !== null} onClose={() => setSelectedLog(null)}>
        {selectedLog && <LogContextContent log={selectedLog} />}
      </Modal>
    </div>
  );
});

/* ─── skeleton ───────────────────────────────────────────── */
const Skeleton = () => (
  <div className="ad-skeleton-grid">
    {Array.from({ length: 9 }).map((_, i) => (
      <div key={i} className="ad-skeleton-block" />
    ))}
  </div>
);

/* ─── main page ─────────────────────────────────────────── */
export default function AgentDetailsPage() {
  const { id = '1' } = useParams<{ id: string }>();
  const { agent, loading, error } = useAgent(id);

  const [timeRange, setTimeRange] = useState('Last 5 Minutes');
  const [spinning, setSpinning]   = useState(false);

  const handleRefresh = () => {
    setSpinning(true);
    setTimeout(() => setSpinning(false), 700);
  };

  return (
    <div className="ad-page">
      {/* ── header ── */}
      <div className="ad-header">
        <nav className="ad-breadcrumb" aria-label="breadcrumb">
          <Link to="/home" className="ad-breadcrumb-link">Home</Link>
          <span className="ad-breadcrumb-sep">›</span>
          <span className="ad-breadcrumb-link ad-breadcrumb-link--plain">Dashboard</span>
          <span className="ad-breadcrumb-sep">›</span>
          <span className="ad-breadcrumb-current">{agent?.name ?? 'Agent Details'}</span>
        </nav>

        <div className="ad-controls">
          <button className="ad-ctrl-btn" title="Share"><Share2 size={14} /></button>
          <button
            className={`ad-ctrl-btn${spinning ? ' ad-ctrl-btn--spinning' : ''}`}
            onClick={handleRefresh}
            title="Refresh"
          >
            <RefreshCw size={14} />
            <span>Refresh</span>
          </button>
          <TimeRangePicker
            value={timeRange}
            onApply={r => setTimeRange(r.preset ?? 'Custom Range')}
          />
          <button className="ad-ctrl-btn" title="More options"><MoreVertical size={15} /></button>
        </div>
      </div>

      {/* ── filter row ── */}
      <div className="ad-filter-row">
        <div className="ad-search-wrap">
          <select className="ad-search-select">
            <option>{agent?.name ?? 'Search Agents'}</option>
          </select>
          <ChevronDown size={14} className="ad-search-chevron" />
        </div>
        <input className="ad-ticket-input" placeholder="Ticket" />
      </div>

      {/* ── states ── */}
      {loading && <Skeleton />}
      {error   && <div className="ad-error">{error}</div>}

      {/* ── main content ── */}
      {!loading && !error && agent && (
        <>
          {/* ── top 3-col grid ── */}
          <div className="ad-top-grid">

            {/* col 1: charts */}
            <div className="ad-charts-col">
              <SectionCard title="Input Tokens (Avg)" menuItems={DEFAULT_PANEL_MENU}>
                <div className="ad-chart-wrap">
                  <ResponsiveContainer width="100%" height={180}>
                    <BarChart data={agent.inputTokensData} margin={{ top: 8, right: 8, left: -10, bottom: 0 }}>
                      <CartesianGrid vertical={false} stroke="rgba(255,255,255,0.05)" />
                      <XAxis
                        dataKey="platform"
                        tick={{ fill: 'var(--text-label)', fontSize: 11, fontFamily: 'Inter' }}
                        axisLine={false} tickLine={false}
                      />
                      <YAxis
                        tick={{ fill: 'var(--text-label)', fontSize: 10, fontFamily: 'Inter' }}
                        axisLine={false} tickLine={false}
                        tickFormatter={(v: number) => v >= 1000 ? `${v / 1000}K` : String(v)}
                      />
                      <Bar dataKey="value" radius={[3, 3, 0, 0]} maxBarSize={30}>
                        {agent.inputTokensData.map((_, i) => (
                          <Cell key={i} fill={BAR_COLORS[i % BAR_COLORS.length]} />
                        ))}
                      </Bar>
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </SectionCard>

              <SectionCard title="Output Tokens (Avg)" menuItems={DEFAULT_PANEL_MENU}>
                <div className="ad-chart-wrap">
                  <ResponsiveContainer width="100%" height={180}>
                    <LineChart data={agent.outputTokensData} margin={{ top: 8, right: 16, left: -10, bottom: 0 }}>
                      <CartesianGrid stroke="rgba(255,255,255,0.05)" />
                      <XAxis
                        dataKey="month"
                        tick={{ fill: 'var(--text-label)', fontSize: 11, fontFamily: 'Inter' }}
                        axisLine={false} tickLine={false}
                      />
                      <YAxis
                        tick={{ fill: 'var(--text-label)', fontSize: 10, fontFamily: 'Inter' }}
                        axisLine={false} tickLine={false}
                        tickFormatter={(v: number) => v >= 1000 ? `${v / 1000}K` : String(v)}
                      />
                      <Tooltip
                        contentStyle={{
                          background: 'var(--dropdown-bg)',
                          border: '1px solid var(--dropdown-border)',
                          borderRadius: 6,
                          color: 'var(--text-primary)',
                          fontSize: 12,
                        }}
                      />
                      <Line
                        type="monotone"
                        dataKey="value"
                        stroke="#8B5CF6"
                        strokeWidth={2}
                        dot={{ fill: '#8B5CF6', r: 4, strokeWidth: 0 }}
                        activeDot={{ r: 6 }}
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </SectionCard>
            </div>

            {/* col 2: metric gauges */}
            <div className="ad-metrics-col">
              <MetricGaugeCard
                label="Number Of" subLabel="Warnings"
                value={agent.metrics.warnings} color="#3B82F6"
                menuItems={DEFAULT_PANEL_MENU}
              />
              <MetricGaugeCard
                label="Number" subLabel="Of Errors"
                value={agent.metrics.errors} max={10} color="#F59E0B" variant="semi"
                menuItems={DEFAULT_PANEL_MENU}
              />
              <MetricGaugeCard
                label="AI Chat" subLabel="Request"
                value={agent.metrics.aiChatRequests} color="#F43F5E"
                menuItems={DEFAULT_PANEL_MENU}
              />
              <LatencyCard value={agent.metrics.avgLatencyMs} menuItems={DEFAULT_PANEL_MENU} />
            </div>

            {/* col 3: cost + performance badges */}
            <div className="ad-right-col">
              <SectionCard title="Cost CKST (USD)" menuItems={DEFAULT_PANEL_MENU}>
                <div className="ad-cost-gauge">
                  <CircularGauge
                    value={agent.metrics.costUsd}
                    color="#2563EB"
                    size={110}
                    strokeWidth={14}
                    valueSize={28}
                  />
                </div>
              </SectionCard>

              <div className="ad-badges-col">
                {BADGE_METRICS.map(({ key, label, color }) => (
                  <BadgeMetric
                    key={key}
                    value={agent.metrics[key as MetricKey] as number}
                    label={label}
                    color={color}
                    menuItems={DEFAULT_PANEL_MENU}
                  />
                ))}
              </div>
            </div>
          </div>

          {/* ── bottom grid ── */}
          <div className="ad-bottom-grid">
            <SectionCard title="Agent Processing Time (Secs)" menuItems={DEFAULT_PANEL_MENU}>
              <div className="ad-proc-gauges">
                <CircularGauge
                  value={agent.metrics.processingTime1}
                  max={10}
                  color="#F59E0B"
                  size={88}
                  strokeWidth={9}
                  variant="semi"
                  valueSize={20}
                />
                <CircularGauge
                  value={agent.metrics.processingTime2}
                  color="#22C55E"
                  size={88}
                  strokeWidth={9}
                  variant="semi"
                  valueSize={20}
                />
              </div>
            </SectionCard>

            <SectionCard title="Messages Per Task (Avg)" menuItems={DEFAULT_PANEL_MENU}>
              <div className="ad-single-gauge">
                <CircularGauge
                  value={agent.metrics.messagesPerTask}
                  color="#3B82F6"
                  size={96}
                  strokeWidth={10}
                  valueSize={22}
                />
              </div>
            </SectionCard>

            <SectionCard title="Task Completed By Agents" menuItems={DEFAULT_PANEL_MENU}>
              <div className="ad-single-gauge">
                <CircularGauge
                  value={agent.metrics.tasksCompleted}
                  color="#22C55E"
                  size={96}
                  strokeWidth={10}
                  variant="semi"
                  valueSize={22}
                />
              </div>
            </SectionCard>

            <LogsPanel agentId={id} menuItems={DEFAULT_PANEL_MENU} />
          </div>
        </>
      )}
    </div>
  );
}
