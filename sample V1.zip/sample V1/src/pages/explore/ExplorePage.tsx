import { useState } from 'react';
import { Columns2, Plus, MoreVertical, X, AlertCircle } from 'lucide-react';
import { TimeRangePicker } from '../../components/common/TimeRangePicker';
import { DataSourceDropdown } from '../../components/explore/DataSourceDropdown';
import { QueryAccordion } from '../../components/explore/QueryAccordion';
import { QueryInspectorOffcanvas } from '../../components/explore/QueryInspectorOffcanvas';
import type { TimeRangeValue } from '../../components/common/TimeRangePicker';
import './ExplorePage.css';

/* ─── Types ───────────────────────────────────────────────── */
interface QueryItem {
  id: string;
  name: string;
}

const QUERY_ALPHABET = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';

function nextQueryName(existing: QueryItem[]): string {
  const usedNames = new Set(existing.map(q => q.name));
  for (const letter of QUERY_ALPHABET) {
    if (!usedNames.has(letter)) return letter;
  }
  return `Query_${existing.length + 1}`;
}

/* ─── Component ───────────────────────────────────────────── */
export default function ExplorePage() {
  const [datasource,     setDatasource]     = useState('prometheus');
  const [timeRange,      setTimeRange]      = useState<TimeRangeValue | null>(null);
  const [alertVisible,   setAlertVisible]   = useState(true);
  const [addModalOpen,   setAddModalOpen]   = useState(false);
  const [inspectorOpen,  setInspectorOpen]  = useState(false);
  const [queries,        setQueries]        = useState<QueryItem[]>([
    { id: 'q1', name: 'A' },
    { id: 'q2', name: 'B' },
  ]);

  void timeRange; // available for future use

  /* ── Query actions ── */
  const addQuery = () => {
    const name = nextQueryName(queries);
    setQueries(prev => [...prev, { id: `q_${Date.now()}`, name }]);
  };

  const deleteQuery = (id: string) => {
    setQueries(prev => prev.filter(q => q.id !== id));
  };

  const duplicateQuery = (id: string) => {
    setQueries(prev => {
      const idx = prev.findIndex(q => q.id === id);
      if (idx === -1) return prev;

      const source = prev[idx];
      // Strip any existing " Copy" or " (n)" suffix to get the true base name
      const baseName = source.name
        .replace(/ Copy$/, '')
        .replace(/ \(\d+\)$/, '');

      const existingNames = new Set(prev.map(q => q.name));
      let copyName = `${baseName} Copy`;
      if (existingNames.has(copyName)) {
        let n = 1;
        while (existingNames.has(`${baseName} (${n})`)) n++;
        copyName = `${baseName} (${n})`;
      }

      const newItem: QueryItem = { id: `q_${Date.now()}`, name: copyName };
      return [...prev.slice(0, idx + 1), newItem, ...prev.slice(idx + 1)];
    });
  };

  const renameQuery = (id: string, name: string) => {
    setQueries(prev => prev.map(q => q.id === id ? { ...q, name } : q));
  };

  /* ── Datasource label ── */
  const DS_LABELS: Record<string, string> = {
    'prometheus':          'Prometheus',
    'prometheus-default':  'Prometheus Default',
    'loki-1':              'Loki-1',
    'mixed':               '-- Mixed --',
  };
  const datasourceLabel = DS_LABELS[datasource] ?? datasource;

  return (
    <>
    <div className="ep-page">
      {/* Breadcrumb */}
      <nav className="ep-breadcrumb" aria-label="Breadcrumb">
        <span className="ep-breadcrumb-link">Home</span>
        <span className="ep-breadcrumb-sep" aria-hidden="true">&rsaquo;</span>
        <span className="ep-breadcrumb-current" aria-current="page">Explore</span>
      </nav>

      <h1 className="ep-title">Explore</h1>

      {/* ══ Header controls ══ */}
      <div className="ep-controls">
        <div className="ep-controls-left">
          <DataSourceDropdown value={datasource} onChange={setDatasource} />
        </div>

        <div className="ep-controls-right">
          <TimeRangePicker
            value="Last 5 Minutes"
            onApply={range => setTimeRange(range)}
          />

          <button
            className="ep-ctrl-btn"
            aria-label="Split view (coming soon)"
            title="Split view"
          >
            <Columns2 size={16} aria-hidden="true" />
          </button>

          <button
            className="ep-ctrl-btn ep-ctrl-btn--accent"
            aria-label="Add new panel"
            title="Add new panel"
            onClick={() => setAddModalOpen(true)}
          >
            <Plus size={16} aria-hidden="true" />
          </button>

          <button
            className="ep-ctrl-btn"
            aria-label="More options"
            title="More options"
          >
            <MoreVertical size={16} aria-hidden="true" />
          </button>
        </div>
      </div>

      {/* ══ Alert banner ══ */}
      {alertVisible && (
        <div className="ep-alert" role="alert" aria-live="polite">
          <AlertCircle size={16} className="ep-alert-icon" aria-hidden="true" />
          <div className="ep-alert-body">
            <p className="ep-alert-title">
              <strong>Explore Metrics, Logs, Traces and Profiles Have Moved!</strong>
            </p>
            <p className="ep-alert-desc">
              Looking for the Explore apps? They are now called the Drilldown apps and can be
              found under <strong>Menu &rsaquo; Drilldown</strong>.
            </p>
            <button className="ep-alert-cta" onClick={() => {}}>
              Go to Drilldown
            </button>
          </div>
          <button
            className="ep-alert-close"
            aria-label="Dismiss alert"
            onClick={() => setAlertVisible(false)}
          >
            <X size={14} aria-hidden="true" />
          </button>
        </div>
      )}

      {/* ══ Query list ══ */}
      <div className="ep-queries" aria-label="Query list">
        {queries.length === 0 ? (
          <div className="ep-empty">
            <p>No queries yet.</p>
            <button className="ep-action-btn" onClick={addQuery}>
              <Plus size={14} aria-hidden="true" />
              Add your first query
            </button>
          </div>
        ) : (
          queries.map(q => (
            <QueryAccordion
              key={q.id}
              id={q.id}
              name={q.name}
              datasource={datasourceLabel}
              onRename={renameQuery}
              onDuplicate={duplicateQuery}
              onDelete={deleteQuery}
            />
          ))
        )}
      </div>

      {/* ══ Footer actions ══ */}
      {queries.length > 0 && (
        <div className="ep-actions">
          <button
            className="ep-action-btn"
            onClick={addQuery}
            aria-label="Add query"
          >
            <Plus size={14} aria-hidden="true" />
            Add Query
          </button>
          <button
            className="ep-inspector-btn"
            aria-label="Toggle Query Inspector"
            onClick={() => setInspectorOpen(v => !v)}
          >
            Query Inspector
          </button>
        </div>
      )}

      {/* ══ Add modal (placeholder) ══ */}
      {addModalOpen && (
        <div
          className="ep-modal-overlay"
          onClick={() => setAddModalOpen(false)}
          role="dialog"
          aria-modal="true"
          aria-labelledby="add-modal-title"
        >
          <div
            className="ep-modal"
            onClick={e => e.stopPropagation()}
          >
            <div className="ep-modal-header">
              <h3 id="add-modal-title">Add Panel</h3>
              <button
                className="ep-modal-close"
                onClick={() => setAddModalOpen(false)}
                aria-label="Close modal"
              >
                <X size={16} aria-hidden="true" />
              </button>
            </div>
            <div className="ep-modal-body">
              <p>Panel configuration will be available here.</p>
            </div>
          </div>
        </div>
      )}
    </div>

      <QueryInspectorOffcanvas
        isOpen={inspectorOpen}
        onClose={() => setInspectorOpen(false)}
      />
    </>
  );
}
