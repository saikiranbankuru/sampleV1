import { useEffect, useState, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { Share2, MoreVertical } from 'lucide-react';
import { RefreshControls } from '../../components/common/RefreshControls';
import { TimeRangePicker } from '../../components/common/TimeRangePicker';
import { useTimeRange } from '../../contexts/TimeRangeContext';
import { MetricCard } from '../../components/dashboard/MetricCard';
import { SectionCard } from '../../components/dashboard/SectionCard';
import { AgentsLastRun } from '../../components/dashboard/AgentsLastRun';
import { TicketAgentMapping } from '../../components/dashboard/TicketAgentMapping';
import { CasesWorked } from '../../components/dashboard/CasesWorked';
import { AvailableAgents } from '../../components/dashboard/AvailableAgents';
import { IncidentList } from '../../components/dashboard/IncidentList';
import { fetchLokiDashboardData } from '../../services/logService';
import type { LokiDashboardData } from '../../services/logService';
import { DEFAULT_PANEL_MENU } from '../../config/panelMenus';
import availableAgentsData from '../../data/availableAgents.json';
import './HomePage.css';

const EMPTY: LokiDashboardData = { tickets: [], agentRuns: [], casesWorked: [], incidents: [] };

export default function HomePage() {
  const navigate = useNavigate();
  const { displayLabel, lookbackSeconds, setTimeRange, timezone, setTimezone } = useTimeRange();

  const [lokiData, setLokiData] = useState<LokiDashboardData>(EMPTY);
  const [loading, setLoading] = useState(true);
  const [spinning, setSpinning] = useState(false);

  const load = useCallback(async () => {
    setSpinning(true);
    setLoading(prev => prev || lokiData.tickets.length === 0);
    try {
      const result = await fetchLokiDashboardData(lookbackSeconds);
      setLokiData(result);
    } finally {
      setLoading(false);
      setSpinning(false);
    }
  }, [lookbackSeconds, lokiData.tickets.length]);

  useEffect(() => { load(); }, [lookbackSeconds]); // eslint-disable-line react-hooks/exhaustive-deps

  return (
    <div className="hp-page">
      {/* Page header */}
      <div className="hp-header">
        <nav className="hp-breadcrumb" aria-label="breadcrumb">
          <span className="hp-breadcrumb-link">Home</span>
          <span className="hp-breadcrumb-sep">&rsaquo;</span>
          <span className="hp-breadcrumb-current">Dashboard</span>
        </nav>

        <div className="hp-controls">
          <button className="hp-ctrl-btn" title="Share">
            <Share2 size={14} />
          </button>

          <RefreshControls onRefresh={load} spinning={spinning} />

          <TimeRangePicker
            value={displayLabel}
            onApply={setTimeRange}
            timezone={timezone}
            onTimezoneChange={setTimezone}
          />

          <button className="hp-ctrl-btn" title="More options">
            <MoreVertical size={15} />
          </button>
        </div>
      </div>

      {/* Metric cards — data disabled until backend is ready */}
      <div className="hp-metrics">
        <MetricCard label="Total Tickets" value={0} />
        <MetricCard label="Active Agents" value={0} />
        <MetricCard label="Total Cases Processed" value={0} />
        <MetricCard label="Failed Cases" value={0} />
      </div>

      {/* Two-column flat grid */}
      <div className="hp-grid">
        <SectionCard title="Agents &amp; Last Run" onViewMore={() => {}} menuItems={DEFAULT_PANEL_MENU}>
          {loading ? (
            <div className="hp-metric-skeleton" style={{ height: 120 }} />
          ) : (
            <AgentsLastRun agents={lokiData.agentRuns} />
          )}
        </SectionCard>

        <SectionCard
          title="Ticket to Agent Mapping"
          onViewMore={() => navigate('/tickets')}
          menuItems={[
            { id: 'view', label: 'View', onAction: () => navigate('/tickets') },
            { id: 'edit', label: 'Edit', onAction: () => navigate('/home/ticket-mapping/edit') },
            {
              id: 'share', label: 'Share',
              children: [
                { id: 'share-link',     label: 'Share link',     onAction: () => {} },
                { id: 'share-embed',    label: 'Share embed',    onAction: () => {} },
                { id: 'share-snapshot', label: 'Share snapshot', onAction: () => {} },
              ],
            },
            { id: 'explore', label: 'Explore', onAction: () => {} },
            {
              id: 'inspect', label: 'Inspect',
              children: [
                { id: 'inspect-data',  label: 'Data',       onAction: () => {} },
                { id: 'inspect-query', label: 'Query',      onAction: () => {} },
                { id: 'inspect-json',  label: 'Panel JSON', onAction: () => {} },
              ],
            },
            {
              id: 'more', label: 'More',
              children: [
                { id: 'more-copy',  label: 'Copy',           onAction: () => {} },
                { id: 'more-alert', label: 'New alert rule', onAction: () => {} },
                { id: 'more-help',  label: 'Get help',       onAction: () => {} },
              ],
            },
          ]}
        >
          {loading ? (
            <div className="hp-metric-skeleton" style={{ height: 120 }} />
          ) : (
            <TicketAgentMapping
              tickets={lokiData.tickets}
              onTicketClick={ticket => navigate(`/tickets/${encodeURIComponent(ticket.ticketNo)}/${encodeURIComponent(ticket.agentName)}`)}
            />
          )}
        </SectionCard>

        <SectionCard title="Number of Cases Worked" onViewMore={() => {}} menuItems={DEFAULT_PANEL_MENU}>
          {loading ? (
            <div className="hp-metric-skeleton" style={{ height: 120 }} />
          ) : (
            <CasesWorked cases={lokiData.casesWorked} />
          )}
        </SectionCard>

        <SectionCard
          title="Available Agents"
          onViewMore={() => navigate('/available-agents')}
          menuItems={DEFAULT_PANEL_MENU}
        >
          <AvailableAgents agents={availableAgentsData} />
        </SectionCard>

        <SectionCard title="Incident" onViewMore={() => {}} menuItems={DEFAULT_PANEL_MENU}>
          {loading ? (
            <div className="hp-metric-skeleton" style={{ height: 120 }} />
          ) : (
            <IncidentList incidents={lokiData.incidents} />
          )}
        </SectionCard>
      </div>
    </div>
  );
}
