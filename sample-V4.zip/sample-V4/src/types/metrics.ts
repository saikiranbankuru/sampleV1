export interface InputTokenDataPoint {
  platform: string;
  value: number;
}

export interface OutputTokenDataPoint {
  month: string;
  value: number;
}

export interface AgentMetrics {
  warnings: number;
  errors: number;
  aiChatRequests: number;
  avgLatencyMs: number;
  costUsd: number;
  cpuUsage: number;
  memoryUsage: number;
  accuracyScore: number;
  processingTime1: number;
  processingTime2: number;
  processingTime3: number;
  messagesPerTask: number;
  tasksCompleted: number;
  inputTokensData: InputTokenDataPoint[];
  outputTokensData: OutputTokenDataPoint[];
}

export interface PrometheusMetricsResponse {
  success: boolean;
  message: string;
  data: AgentMetrics;
}

// Actual API response shape from /api/metrics/query
export interface PrometheusVectorResult {
  metric: Record<string, string | undefined>;
  value: [number, string]; // [unix_timestamp, numeric_string]
}

export interface PrometheusQueryData {
  query: string;
  result_type: string;
  results: PrometheusVectorResult[];
}

export interface PrometheusQueryResponse {
  success: boolean;
  message: string;
  data: PrometheusQueryData;
}
