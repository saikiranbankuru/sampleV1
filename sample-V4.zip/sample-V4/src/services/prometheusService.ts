import { prometheusApiClient } from './apiClient';
import { lokiApiClient } from './apiClient';
import type { PrometheusQueryResponse, AgentMetrics, InputTokenDataPoint, OutputTokenDataPoint } from '@/types/metrics';
import type { LokiQueryResponse } from '@/types/log';

// ---------------------------------------------------------------------------
// Low-level helpers
// ---------------------------------------------------------------------------

/** Send a PromQL expression, return the sum of all result values. Returns 0 on any failure. */
const queryPrometheus = async (promql: string): Promise<number> => {
  try {
    const response = await prometheusApiClient.get<PrometheusQueryResponse>('/query', {
      params: { promql },
    });
    const results = response.data?.results ?? [];
    if (results.length === 0) return 0;
    return results.reduce((sum, r) => {
      const v = parseFloat(r.value?.[1] ?? '0');
      return sum + (isFinite(v) ? v : 0);
    }, 0);
  } catch {
    return 0;
  }
};

/** Count log lines matching a LogQL filter via the Loki query endpoint. Returns 0 on failure. */
const queryLokiLogCount = async (logql: string): Promise<number> => {
  try {
    const response = await lokiApiClient.get<LokiQueryResponse>('/query', {
      params: { logql, lookback_seconds: 3600, limit: 200, direction: 'backward' },
    });
    const streams = response.data?.streams ?? [];
    return streams.reduce((total, s) => total + s.logs.length, 0);
  } catch {
    return 0;
  }
};

// ---------------------------------------------------------------------------
// Static chart data (per-platform / per-month breakdown — representative)
// ---------------------------------------------------------------------------

const DEFAULT_INPUT_TOKENS: InputTokenDataPoint[] = [
  { platform: 'Linux',   value: 28000 },
  { platform: 'Mac',     value: 20000 },
  { platform: 'iOS',     value: 12000 },
  { platform: 'Windows', value: 30000 },
  { platform: 'Android', value: 15000 },
  { platform: 'Other',   value: 22000 },
];

const DEFAULT_OUTPUT_TOKENS: OutputTokenDataPoint[] = [
  { month: 'Jan', value: 4000  },
  { month: 'Feb', value: 7500  },
  { month: 'Mar', value: 5200  },
  { month: 'Apr', value: 11000 },
  { month: 'May', value: 9000  },
  { month: 'Jun', value: 15500 },
];

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------

/**
 * Fetch all KPI metrics for a given agent + ticket in parallel.
 * Each individual query degrades to 0 if unreachable, so the page always renders.
 */
export const fetchAllTicketMetrics = async (
  agentName: string,
  ticketNumber: string,
): Promise<AgentMetrics> => {
  const ag = agentName;
  const tk = ticketNumber;

  // Loki log-count queries for warning / error KPIs
  const warningsLogQL = `{service_name="${ag}"} | json | label_format level=detected_level | case_number="${tk}" | level="warn"`;
  const errorsLogQL   = `{service_name="${ag}"} | json | label_format level=detected_level | case_number="${tk}" | level="error"`;

  const [
    warnings,
    errors,
    aiChatRequests,
    avgLatencyRaw,
    inputTokens,
    outputTokens,
    cpuRaw,
    memRaw,
    accuracyScore,
    procTime1Raw,
    procTime2Raw,
    procTime3Raw,
    messagesPerTask,
    tasksCompleted,
  ] = await Promise.all([
    // Warnings & errors come from Loki
    queryLokiLogCount(warningsLogQL),
    queryLokiLogCount(errorsLogQL),

    // Prometheus scalars
    queryPrometheus(`sum(chat_requests_total{agent="${ag}", case_number="${tk}"})`),
    queryPrometheus(
      `sum(chat_request_latency_ms_milliseconds_sum{case_number="${tk}"})` +
      ` / sum(chat_request_latency_ms_milliseconds_count{case_number="${tk}"})`,
    ),
    queryPrometheus(`sum(total_tokens_input{agent="${ag}", case_number="${tk}"})`),
    queryPrometheus(`sum(total_tokens_output{agent="${ag}", case_number="${tk}"})`),
    queryPrometheus(
      `sum(cpu_usage_percent_sum{agent="${ag}", case_number="${tk}"})` +
      ` / sum(cpu_usage_percent_count{agent="${ag}", case_number="${tk}"})`,
    ),
    queryPrometheus(
      `sum(memory_usage_percent_sum{agent="${ag}", case_number="${tk}"})` +
      ` / sum(memory_usage_percent_count{agent="${ag}", case_number="${tk}"})`,
    ),
    queryPrometheus(`sum(accuracy_score_latest{case_number="${tk}"})`),

    // Processing time per sub-agent (ms → secs)
    queryPrometheus(
      `sum(agent_processing_time_ms_milliseconds_sum{agent="Gauge AI Agent", case_number="${tk}"})` +
      ` / sum(agent_processing_time_ms_milliseconds_count{agent="Gauge AI Agent", case_number="${tk}"}) / 1000`,
    ),
    queryPrometheus(
      `sum(agent_processing_time_ms_milliseconds_sum{agent="Incident Crew", case_number="${tk}"})` +
      ` / sum(agent_processing_time_ms_milliseconds_count{agent="Incident Crew", case_number="${tk}"}) / 1000`,
    ),
    queryPrometheus(
      `sum(agent_processing_time_ms_milliseconds_sum{agent="Ticket Approval Agent", case_number="${tk}"})` +
      ` / sum(agent_processing_time_ms_milliseconds_count{agent="Ticket Approval Agent", case_number="${tk}"}) / 1000`,
    ),

    queryPrometheus(`sum(agent_interaction_count_messages_count{agent="${ag}", case_number="${tk}"})`),
    queryPrometheus(`sum(task_completion_total{agent="${ag}", case_number="${tk}"})`),
  ]);

  // Cost = (input tokens × $0.00003) + (output tokens × $0.00006)
  const costUsd = (inputTokens * 0.00003) + (outputTokens * 0.00006);

  const safe = (v: number) => (isFinite(v) ? v : 0);

  return {
    warnings,
    errors,
    aiChatRequests:  Math.round(aiChatRequests),
    avgLatencyMs:    safe(avgLatencyRaw),
    costUsd:         safe(costUsd),
    cpuUsage:        Math.round(safe(cpuRaw)),
    memoryUsage:     Math.round(safe(memRaw)),
    accuracyScore:   Math.round(accuracyScore),
    processingTime1: Math.round(safe(procTime1Raw)),
    processingTime2: Math.round(safe(procTime2Raw)),
    processingTime3: Math.round(safe(procTime3Raw)),
    messagesPerTask: Math.round(messagesPerTask),
    tasksCompleted:  Math.round(tasksCompleted),
    inputTokensData:  DEFAULT_INPUT_TOKENS,
    outputTokensData: DEFAULT_OUTPUT_TOKENS,
  };
};

/** Backward-compatible alias — keeps the existing call site in TicketDetailsPage working. */
export const fetchAgentMetrics = fetchAllTicketMetrics;
