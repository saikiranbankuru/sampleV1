import { useState, useEffect } from 'react';
import { lokiApiClient } from '../services/apiClient';
import type { LokiQueryResponse } from '../types/log';
import type { AgentLog, LogType } from '../types/agent';

export interface UseLokiLogsResult {
  logs: AgentLog[];
  loading: boolean;
}

/**
 * Fetches Loki log lines for a specific agent service + ticket number.
 * Re-fetches automatically when any of the three parameters change.
 */
export function useLokiLogs(
  agentName: string,
  ticketNumber: string,
  logType: LogType,
): UseLokiLogsResult {
  const [logs,    setLogs]    = useState<AgentLog[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!agentName || !ticketNumber) {
      setLogs([]);
      setLoading(false);
      return;
    }

    let cancelled = false;
    setLoading(true);
    setLogs([]);

    // Loki uses "warn" not "warning"
    const levelValue = logType === 'warning' ? 'warn' : logType;

    const logql =
      `{service_name="${agentName}"} | json | label_format level=detected_level` +
      ` | case_number="${ticketNumber}" | level="${levelValue}"`;

    lokiApiClient
      .get<LokiQueryResponse>('/query', {
        params: { logql, lookback_seconds: 3600, limit: 50, direction: 'backward' },
      })
      .then(response => {
        if (cancelled) return;
        const streams = response.data?.streams ?? [];
        const parsed: AgentLog[] = [];

        streams.forEach((stream, si) => {
          stream.logs.forEach((entry, li) => {
            let timestamp = entry.timestamp_ns;
            let record    = ticketNumber;

            try {
              const obj = JSON.parse(entry.log) as Record<string, unknown>;
              if (typeof obj.timestamp === 'string') timestamp = obj.timestamp;
              if (typeof obj.case_number === 'string') record = obj.case_number;
              else if (typeof obj.message === 'string') record = obj.message;
            } catch {
              // log line is not JSON — use raw values
            }

            parsed.push({
              id:        `${si}-${li}-${entry.timestamp_ns}`,
              timestamp,
              record,
              type: logType,
            });
          });
        });

        setLogs(parsed);
      })
      .catch(() => { if (!cancelled) setLogs([]); })
      .finally(() => { if (!cancelled) setLoading(false); });

    return () => { cancelled = true; };
  }, [agentName, ticketNumber, logType]);

  return { logs, loading };
}
