import { useEffect, useRef, useState, useCallback } from 'react';
import { useNavigate, useParams, useLocation } from 'react-router-dom';
import { ChevronDown, Check, ArrowLeft } from 'lucide-react';
import { TimeRangePicker } from '../../components/common/TimeRangePicker';
import { LokiQueryAccordion } from '../../components/dashboard/LokiQueryAccordion';
import CircularGauge from '../../components/dashboard/CircularGauge';
import {
  getCostPerQueryLokiQuery,
  getCostPerQueryPrometheusQuery,
  setCostPerQueryLokiQuery,
  setCostPerQueryPrometheusQuery,
  buildCostPerQuery,
} from '../../services/costPerQueryQueryStore';
import {
  executePrometheusQuery,
  executeLokiQuery,
} from '../../services/prometheusService';
import './CostPerQueryEditPage.css';

type Datasource = 'Loki' | 'Prometheus';

interface QueryItem {
  id: string;
  name: string;
  datasource: Datasource;
  query: string;
}

function getDefaultQuery(ds: Datasource): string {
  return ds === 'Loki' ? getCostPerQueryLokiQuery() : getCostPerQueryPrometheusQuery();
}

export default function CostPerQueryEditPage() {
  const navigate = useNavigate();
  const location = useLocation();
  const { agentName: rawAgentName = '' } = useParams<{ agentName: string }>();
  const agentName = decodeURIComponent(rawAgentName);
  const ticketNumber = new URLSearchParams(location.search).get('ticket') ?? '';

  const [timeRange, setTimeRange] = useState('Last 5 Minutes');
  const [activeTab, setActiveTab] = useState<'queries' | 'transformations'>('queries');
  const [datasource, setDatasource] = useState<Datasource>('Prometheus');
  const [dsOpen, setDsOpen] = useState(false);

  const [queries, setQueries] = useState<QueryItem[]>([
    { id: 'q1', name: 'A', datasource: 'Prometheus', query: getCostPerQueryPrometheusQuery() },
  ]);
  const queryIdRef = useRef(1);

  const [metricValue, setMetricValue] = useState<number | null>(null);
  const [widgetLoading, setWidgetLoading] = useState(true);
  const [runLoading, setRunLoading] = useState(false);
  const [runError, setRunError] = useState<string | null>(null);
  const [savedFlash, setSavedFlash] = useState(false);

  useEffect(() => {
    setWidgetLoading(true);
    const resolved = buildCostPerQuery(
      getCostPerQueryPrometheusQuery(),
      agentName,
      ticketNumber || undefined,
    );
    executePrometheusQuery(resolved)
      .then(v => setMetricValue(v))
      .finally(() => setWidgetLoading(false));
  }, [agentName, ticketNumber]);

  const handleDatasourceChange = useCallback((ds: Datasource) => {
    setDatasource(ds);
    setDsOpen(false);
    setQueries(prev => prev.map(q => ({ ...q, datasource: ds, query: getDefaultQuery(ds) })));
    setRunError(null);
  }, []);

  const handleQueryChange = (id: string, query: string) => {
    setQueries(prev => prev.map(q => q.id === id ? { ...q, query } : q));
  };

  const handleRunQuery = async (_id: string, query: string, ds: string) => {
    setRunLoading(true);
    setRunError(null);
    try {
      const resolved = buildCostPerQuery(query, agentName, ticketNumber || undefined);
      const value = ds === 'Prometheus'
        ? await executePrometheusQuery(resolved)
        : await executeLokiQuery(resolved);
      setMetricValue(value);
    } catch (err) {
      setRunError(err instanceof Error ? err.message : 'Query execution failed');
    } finally {
      setRunLoading(false);
    }
  };

  const handleSave = () => {
    queries.forEach(q => {
      if (q.datasource === 'Loki') setCostPerQueryLokiQuery(q.query);
      else setCostPerQueryPrometheusQuery(q.query);
    });
    setSavedFlash(true);
    setTimeout(() => setSavedFlash(false), 2000);
  };

  const renameQuery = (id: string, newName: string) => {
    setQueries(prev => prev.map(q => q.id === id ? { ...q, name: newName } : q));
  };

  const addQuery = () => {
    setQueries(prev => {
      queryIdRef.current += 1;
      const name = String.fromCharCode(65 + prev.length);
      return [...prev, { id: `q${queryIdRef.current}`, name, datasource, query: getDefaultQuery(datasource) }];
    });
  };

  const duplicateQuery = (id: string) => {
    setQueries(prev => {
      const source = prev.find(q => q.id === id);
      if (!source) return prev;
      queryIdRef.current += 1;
      const name = String.fromCharCode(65 + prev.length);
      return [...prev, { id: `q${queryIdRef.current}`, name, datasource: source.datasource, query: source.query }];
    });
  };

  const deleteQuery = (id: string) => {
    setQueries(prev => prev.filter(q => q.id !== id));
  };

  const displayValue = metricValue !== null ? metricValue : 0;

  return (
    <div className="cpq-page">
      {/* ── Header ── */}
      <div className="cpq-header">
        <nav className="cpq-breadcrumb" aria-label="breadcrumb">
          <button className="cpq-breadcrumb-link" onClick={() => navigate('/home')}>Home</button>
          <span className="cpq-breadcrumb-sep">&rsaquo;</span>
          <button className="cpq-breadcrumb-link" onClick={() => navigate('/home')}>Dashboard</button>
          <span className="cpq-breadcrumb-sep">&rsaquo;</span>
          {agentName && (
            <>
              <button
                className="cpq-breadcrumb-link"
                onClick={() => navigate(`/agents/${encodeURIComponent(agentName)}`)}
              >
                {agentName}
              </button>
              <span className="cpq-breadcrumb-sep">&rsaquo;</span>
            </>
          )}
          <span className="cpq-breadcrumb-current">Edit Cost Per Query</span>
        </nav>

        <div className="cpq-controls">
          <TimeRangePicker
            value={timeRange}
            onApply={r => setTimeRange(r.preset ?? 'Custom Range')}
          />
          <button className="cpq-back-btn" onClick={() => navigate(-1)}>
            <ArrowLeft size={14} />
            Back
          </button>
        </div>
      </div>

      {/* ── Widget preview ── */}
      <div className="cpq-widget-row">
        <div className="cpq-gauge-card">
          <div className="cpq-gauge-card-header">
            <p className="cpq-gauge-label">COST PER QUERY ($)</p>
            <div className="cpq-gauge-menu-placeholder" />
          </div>
          <div className="cpq-gauge-center">
            {widgetLoading ? (
              <div className="cpq-gauge-skeleton" />
            ) : (
              <CircularGauge
                value={displayValue}
                color="#2563EB"
                size={110}
                strokeWidth={14}
                valueSize={24}
              />
            )}
          </div>
        </div>
      </div>

      {/* ── Query editor ── */}
      <div className="cpq-section">
        <div className="cpq-tabs-header" role="tablist">
          <button
            role="tab"
            aria-selected={activeTab === 'queries'}
            className={`cpq-tab${activeTab === 'queries' ? ' cpq-tab--active' : ''}`}
            onClick={() => setActiveTab('queries')}
          >
            Queries
            <span className="cpq-tab-badge">{queries.length}</span>
          </button>
          <button
            role="tab"
            aria-selected={activeTab === 'transformations'}
            className={`cpq-tab${activeTab === 'transformations' ? ' cpq-tab--active' : ''}`}
            onClick={() => setActiveTab('transformations')}
          >
            Transformations
            <span className="cpq-tab-badge cpq-tab-badge--neutral">5</span>
          </button>
        </div>

        <div className="cpq-tab-content" role="tabpanel">
          {activeTab === 'queries' ? (
            <div className="cpq-queries-tab">
              {/* Datasource selector */}
              <div className="cpq-ds-row">
                <div className="cpq-ds-dropdown" onBlur={() => setDsOpen(false)}>
                  <button
                    className="cpq-ds-btn"
                    onClick={() => setDsOpen(v => !v)}
                    aria-haspopup="listbox"
                    aria-expanded={dsOpen}
                    aria-label="Select datasource"
                  >
                    {datasource}
                    <ChevronDown
                      size={13}
                      className={`cpq-ds-chevron${dsOpen ? ' cpq-ds-chevron--open' : ''}`}
                    />
                  </button>
                  {dsOpen && (
                    <ul className="cpq-ds-menu" role="listbox">
                      {(['Loki', 'Prometheus'] as Datasource[]).map(ds => (
                        <li
                          key={ds}
                          role="option"
                          aria-selected={datasource === ds}
                          className={`cpq-ds-option${datasource === ds ? ' cpq-ds-option--active' : ''}`}
                          onMouseDown={() => handleDatasourceChange(ds)}
                        >
                          {datasource === ds && <Check size={12} className="cpq-ds-check" />}
                          {ds}
                        </li>
                      ))}
                    </ul>
                  )}
                </div>
              </div>

              {/* Query accordions */}
              <div className="cpq-query-list">
                {queries.map(q => (
                  <LokiQueryAccordion
                    key={q.id}
                    id={q.id}
                    name={q.name}
                    datasource={q.datasource}
                    initialQuery={q.query}
                    onRename={renameQuery}
                    onDuplicate={duplicateQuery}
                    onDelete={deleteQuery}
                    onQueryChange={handleQueryChange}
                    onRun={handleRunQuery}
                    runLoading={runLoading}
                    runError={runError}
                  />
                ))}
              </div>

              {/* Action row */}
              <div className="cpq-query-actions">
                <button className="cpq-action-btn" onClick={addQuery}>Add Query</button>
                <button className="cpq-action-btn">Expression</button>
                <div className="cpq-query-actions-right">
                  <button
                    className={`cpq-save-btn${savedFlash ? ' cpq-save-btn--saved' : ''}`}
                    onClick={handleSave}
                  >
                    {savedFlash ? 'Saved!' : 'Apply & Save'}
                  </button>
                </div>
              </div>
            </div>
          ) : (
            <div className="cpq-transformations-tab" aria-label="Transformations — coming soon" />
          )}
        </div>
      </div>
    </div>
  );
}
