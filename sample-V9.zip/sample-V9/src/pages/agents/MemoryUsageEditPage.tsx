import { useEffect, useRef, useState, useCallback } from 'react';
import { useNavigate, useParams, useLocation } from 'react-router-dom';
import { ChevronDown, Check, ArrowLeft } from 'lucide-react';
import { TimeRangePicker } from '../../components/common/TimeRangePicker';
import { LokiQueryAccordion } from '../../components/dashboard/LokiQueryAccordion';
import {
  getMemoryUsageLokiQuery,
  getMemoryUsagePrometheusQuery,
  setMemoryUsageLokiQuery,
  setMemoryUsagePrometheusQuery,
  buildMemoryUsageQuery,
} from '../../services/memoryUsageQueryStore';
import {
  executePrometheusQuery,
  executeLokiQuery,
} from '../../services/prometheusService';
import './MemoryUsageEditPage.css';

type Datasource = 'Loki' | 'Prometheus';

interface QueryItem {
  id: string;
  name: string;
  datasource: Datasource;
  query: string;
}

function getDefaultQuery(ds: Datasource): string {
  return ds === 'Loki' ? getMemoryUsageLokiQuery() : getMemoryUsagePrometheusQuery();
}

export default function MemoryUsageEditPage() {
  const navigate = useNavigate();
  const location = useLocation();
  const { agentName: rawAgentName = '' } = useParams<{ agentName: string }>();
  const agentName = decodeURIComponent(rawAgentName);
  const ticketNumber = new URLSearchParams(location.search).get('ticket') ?? '';

  const [timeRange, setTimeRange] = useState('Last 5 Minutes');
  const [activeTab, setActiveTab] = useState<'queries' | 'transformations'>('queries');
  const [datasource, setDatasource] = useState<Datasource>('Prometheus');
  const [dsOpen, setDsOpen] = useState(false);

  const [queries, setQueries] = useState<QueryItem[]>([
    { id: 'q1', name: 'A', datasource: 'Prometheus', query: getMemoryUsagePrometheusQuery() },
  ]);
  const queryIdRef = useRef(1);

  const [metricValue, setMetricValue] = useState<number | null>(null);
  const [widgetLoading, setWidgetLoading] = useState(true);
  const [runLoading, setRunLoading] = useState(false);
  const [runError, setRunError] = useState<string | null>(null);
  const [savedFlash, setSavedFlash] = useState(false);

  useEffect(() => {
    setWidgetLoading(true);
    const resolved = buildMemoryUsageQuery(
      getMemoryUsagePrometheusQuery(),
      agentName,
      ticketNumber || undefined,
    );
    executePrometheusQuery(resolved)
      .then(v => setMetricValue(Math.round(v)))
      .finally(() => setWidgetLoading(false));
  }, [agentName, ticketNumber]);

  const handleDatasourceChange = useCallback((ds: Datasource) => {
    setDatasource(ds);
    setDsOpen(false);
    setQueries(prev => prev.map(q => ({ ...q, datasource: ds, query: getDefaultQuery(ds) })));
    setRunError(null);
  }, []);

  const handleQueryChange = (id: string, query: string) => {
    setQueries(prev => prev.map(q => q.id === id ? { ...q, query } : q));
  };

  const handleRunQuery = async (_id: string, query: string, ds: string) => {
    setRunLoading(true);
    setRunError(null);
    try {
      const resolved = buildMemoryUsageQuery(query, agentName, ticketNumber || undefined);
      const value = ds === 'Prometheus'
        ? await executePrometheusQuery(resolved)
        : await executeLokiQuery(resolved);
      setMetricValue(Math.round(value));
    } catch (err) {
      setRunError(err instanceof Error ? err.message : 'Query execution failed');
    } finally {
      setRunLoading(false);
    }
  };

  const handleSave = () => {
    queries.forEach(q => {
      if (q.datasource === 'Loki') setMemoryUsageLokiQuery(q.query);
      else setMemoryUsagePrometheusQuery(q.query);
    });
    setSavedFlash(true);
    setTimeout(() => setSavedFlash(false), 2000);
  };

  const renameQuery = (id: string, newName: string) => {
    setQueries(prev => prev.map(q => q.id === id ? { ...q, name: newName } : q));
  };

  const addQuery = () => {
    setQueries(prev => {
      queryIdRef.current += 1;
      const name = String.fromCharCode(65 + prev.length);
      return [...prev, { id: `q${queryIdRef.current}`, name, datasource, query: getDefaultQuery(datasource) }];
    });
  };

  const duplicateQuery = (id: string) => {
    setQueries(prev => {
      const source = prev.find(q => q.id === id);
      if (!source) return prev;
      queryIdRef.current += 1;
      const name = String.fromCharCode(65 + prev.length);
      return [...prev, { id: `q${queryIdRef.current}`, name, datasource: source.datasource, query: source.query }];
    });
  };

  const deleteQuery = (id: string) => {
    setQueries(prev => prev.filter(q => q.id !== id));
  };

  const displayValue = metricValue ?? 0;

  return (
    <div className="mue-page">
      {/* ── Header ── */}
      <div className="mue-header">
        <nav className="mue-breadcrumb" aria-label="breadcrumb">
          <button className="mue-breadcrumb-link" onClick={() => navigate('/home')}>Home</button>
          <span className="mue-breadcrumb-sep">&rsaquo;</span>
          <button className="mue-breadcrumb-link" onClick={() => navigate('/home')}>Dashboard</button>
          <span className="mue-breadcrumb-sep">&rsaquo;</span>
          {agentName && (
            <>
              <button
                className="mue-breadcrumb-link"
                onClick={() => navigate(`/agents/${encodeURIComponent(agentName)}`)}
              >
                {agentName}
              </button>
              <span className="mue-breadcrumb-sep">&rsaquo;</span>
            </>
          )}
          <span className="mue-breadcrumb-current">Edit Memory Usage</span>
        </nav>

        <div className="mue-controls">
          <TimeRangePicker
            value={timeRange}
            onApply={r => setTimeRange(r.preset ?? 'Custom Range')}
          />
          <button className="mue-back-btn" onClick={() => navigate(-1)}>
            <ArrowLeft size={14} />
            Back
          </button>
        </div>
      </div>

      {/* ── Widget preview ── */}
      <div className="mue-widget-row">
        <div className="mue-badge-card">
          {widgetLoading ? (
            <div className="mue-badge-skeleton" />
          ) : (
            <div className="mue-badge-row">
              <span className="mue-badge-num">
                {String(displayValue).padStart(2, '0')}
              </span>
              <span className="mue-badge-label">Memory Usage(%)</span>
              <div className="mue-badge-menu-placeholder" />
            </div>
          )}
        </div>
      </div>

      {/* ── Query editor ── */}
      <div className="mue-section">
        <div className="mue-tabs-header" role="tablist">
          <button
            role="tab"
            aria-selected={activeTab === 'queries'}
            className={`mue-tab${activeTab === 'queries' ? ' mue-tab--active' : ''}`}
            onClick={() => setActiveTab('queries')}
          >
            Queries
            <span className="mue-tab-badge">{queries.length}</span>
          </button>
          <button
            role="tab"
            aria-selected={activeTab === 'transformations'}
            className={`mue-tab${activeTab === 'transformations' ? ' mue-tab--active' : ''}`}
            onClick={() => setActiveTab('transformations')}
          >
            Transformations
            <span className="mue-tab-badge mue-tab-badge--neutral">5</span>
          </button>
        </div>

        <div className="mue-tab-content" role="tabpanel">
          {activeTab === 'queries' ? (
            <div className="mue-queries-tab">
              {/* Datasource selector */}
              <div className="mue-ds-row">
                <div className="mue-ds-dropdown" onBlur={() => setDsOpen(false)}>
                  <button
                    className="mue-ds-btn"
                    onClick={() => setDsOpen(v => !v)}
                    aria-haspopup="listbox"
                    aria-expanded={dsOpen}
                    aria-label="Select datasource"
                  >
                    {datasource}
                    <ChevronDown
                      size={13}
                      className={`mue-ds-chevron${dsOpen ? ' mue-ds-chevron--open' : ''}`}
                    />
                  </button>
                  {dsOpen && (
                    <ul className="mue-ds-menu" role="listbox">
                      {(['Loki', 'Prometheus'] as Datasource[]).map(ds => (
                        <li
                          key={ds}
                          role="option"
                          aria-selected={datasource === ds}
                          className={`mue-ds-option${datasource === ds ? ' mue-ds-option--active' : ''}`}
                          onMouseDown={() => handleDatasourceChange(ds)}
                        >
                          {datasource === ds && <Check size={12} className="mue-ds-check" />}
                          {ds}
                        </li>
                      ))}
                    </ul>
                  )}
                </div>
              </div>

              {/* Query accordions */}
              <div className="mue-query-list">
                {queries.map(q => (
                  <LokiQueryAccordion
                    key={q.id}
                    id={q.id}
                    name={q.name}
                    datasource={q.datasource}
                    initialQuery={q.query}
                    onRename={renameQuery}
                    onDuplicate={duplicateQuery}
                    onDelete={deleteQuery}
                    onQueryChange={handleQueryChange}
                    onRun={handleRunQuery}
                    runLoading={runLoading}
                    runError={runError}
                  />
                ))}
              </div>

              {/* Action row */}
              <div className="mue-query-actions">
                <button className="mue-action-btn" onClick={addQuery}>Add Query</button>
                <button className="mue-action-btn">Expression</button>
                <div className="mue-query-actions-right">
                  <button
                    className={`mue-save-btn${savedFlash ? ' mue-save-btn--saved' : ''}`}
                    onClick={handleSave}
                  >
                    {savedFlash ? 'Saved!' : 'Apply & Save'}
                  </button>
                </div>
              </div>
            </div>
          ) : (
            <div className="mue-transformations-tab" aria-label="Transformations — coming soon" />
          )}
        </div>
      </div>
    </div>
  );
}
