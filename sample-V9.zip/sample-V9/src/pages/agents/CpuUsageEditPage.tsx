import { useEffect, useRef, useState, useCallback } from 'react';
import { useNavigate, useParams, useLocation } from 'react-router-dom';
import { ChevronDown, Check, ArrowLeft } from 'lucide-react';
import { TimeRangePicker } from '../../components/common/TimeRangePicker';
import { LokiQueryAccordion } from '../../components/dashboard/LokiQueryAccordion';
import {
  getCpuUsageLokiQuery,
  getCpuUsagePrometheusQuery,
  setCpuUsageLokiQuery,
  setCpuUsagePrometheusQuery,
  buildCpuUsageQuery,
} from '../../services/cpuUsageQueryStore';
import {
  executePrometheusQuery,
  executeLokiQuery,
} from '../../services/prometheusService';
import './CpuUsageEditPage.css';

type Datasource = 'Loki' | 'Prometheus';

interface QueryItem {
  id: string;
  name: string;
  datasource: Datasource;
  query: string;
}

function getDefaultQuery(ds: Datasource): string {
  return ds === 'Loki' ? getCpuUsageLokiQuery() : getCpuUsagePrometheusQuery();
}

export default function CpuUsageEditPage() {
  const navigate = useNavigate();
  const location = useLocation();
  const { agentName: rawAgentName = '' } = useParams<{ agentName: string }>();
  const agentName = decodeURIComponent(rawAgentName);
  const ticketNumber = new URLSearchParams(location.search).get('ticket') ?? '';

  const [timeRange, setTimeRange] = useState('Last 5 Minutes');
  const [activeTab, setActiveTab] = useState<'queries' | 'transformations'>('queries');
  const [datasource, setDatasource] = useState<Datasource>('Prometheus');
  const [dsOpen, setDsOpen] = useState(false);

  const [queries, setQueries] = useState<QueryItem[]>([
    { id: 'q1', name: 'A', datasource: 'Prometheus', query: getCpuUsagePrometheusQuery() },
  ]);
  const queryIdRef = useRef(1);

  const [metricValue, setMetricValue] = useState<number | null>(null);
  const [widgetLoading, setWidgetLoading] = useState(true);
  const [runLoading, setRunLoading] = useState(false);
  const [runError, setRunError] = useState<string | null>(null);
  const [savedFlash, setSavedFlash] = useState(false);

  useEffect(() => {
    setWidgetLoading(true);
    const resolved = buildCpuUsageQuery(
      getCpuUsagePrometheusQuery(),
      agentName,
      ticketNumber || undefined,
    );
    executePrometheusQuery(resolved)
      .then(v => setMetricValue(Math.round(v)))
      .finally(() => setWidgetLoading(false));
  }, [agentName, ticketNumber]);

  const handleDatasourceChange = useCallback((ds: Datasource) => {
    setDatasource(ds);
    setDsOpen(false);
    setQueries(prev => prev.map(q => ({ ...q, datasource: ds, query: getDefaultQuery(ds) })));
    setRunError(null);
  }, []);

  const handleQueryChange = (id: string, query: string) => {
    setQueries(prev => prev.map(q => q.id === id ? { ...q, query } : q));
  };

  const handleRunQuery = async (_id: string, query: string, ds: string) => {
    setRunLoading(true);
    setRunError(null);
    try {
      const resolved = buildCpuUsageQuery(query, agentName, ticketNumber || undefined);
      const value = ds === 'Prometheus'
        ? await executePrometheusQuery(resolved)
        : await executeLokiQuery(resolved);
      setMetricValue(Math.round(value));
    } catch (err) {
      setRunError(err instanceof Error ? err.message : 'Query execution failed');
    } finally {
      setRunLoading(false);
    }
  };

  const handleSave = () => {
    queries.forEach(q => {
      if (q.datasource === 'Loki') setCpuUsageLokiQuery(q.query);
      else setCpuUsagePrometheusQuery(q.query);
    });
    setSavedFlash(true);
    setTimeout(() => setSavedFlash(false), 2000);
  };

  const renameQuery = (id: string, newName: string) => {
    setQueries(prev => prev.map(q => q.id === id ? { ...q, name: newName } : q));
  };

  const addQuery = () => {
    setQueries(prev => {
      queryIdRef.current += 1;
      const name = String.fromCharCode(65 + prev.length);
      return [...prev, { id: `q${queryIdRef.current}`, name, datasource, query: getDefaultQuery(datasource) }];
    });
  };

  const duplicateQuery = (id: string) => {
    setQueries(prev => {
      const source = prev.find(q => q.id === id);
      if (!source) return prev;
      queryIdRef.current += 1;
      const name = String.fromCharCode(65 + prev.length);
      return [...prev, { id: `q${queryIdRef.current}`, name, datasource: source.datasource, query: source.query }];
    });
  };

  const deleteQuery = (id: string) => {
    setQueries(prev => prev.filter(q => q.id !== id));
  };

  const displayValue = metricValue ?? 0;

  return (
    <div className="cpue-page">
      {/* ── Header ── */}
      <div className="cpue-header">
        <nav className="cpue-breadcrumb" aria-label="breadcrumb">
          <button className="cpue-breadcrumb-link" onClick={() => navigate('/home')}>Home</button>
          <span className="cpue-breadcrumb-sep">&rsaquo;</span>
          <button className="cpue-breadcrumb-link" onClick={() => navigate('/home')}>Dashboard</button>
          <span className="cpue-breadcrumb-sep">&rsaquo;</span>
          {agentName && (
            <>
              <button
                className="cpue-breadcrumb-link"
                onClick={() => navigate(`/agents/${encodeURIComponent(agentName)}`)}
              >
                {agentName}
              </button>
              <span className="cpue-breadcrumb-sep">&rsaquo;</span>
            </>
          )}
          <span className="cpue-breadcrumb-current">Edit CPU Usage</span>
        </nav>

        <div className="cpue-controls">
          <TimeRangePicker
            value={timeRange}
            onApply={r => setTimeRange(r.preset ?? 'Custom Range')}
          />
          <button className="cpue-back-btn" onClick={() => navigate(-1)}>
            <ArrowLeft size={14} />
            Back
          </button>
        </div>
      </div>

      {/* ── Widget preview ── */}
      <div className="cpue-widget-row">
        <div className="cpue-badge-card">
          {widgetLoading ? (
            <div className="cpue-badge-skeleton" />
          ) : (
            <div className="cpue-badge-row">
              <span className="cpue-badge-num">
                {String(displayValue).padStart(2, '0')}
              </span>
              <span className="cpue-badge-label">CPU Usage(%)</span>
              <div className="cpue-badge-menu-placeholder" />
            </div>
          )}
        </div>
      </div>

      {/* ── Query editor ── */}
      <div className="cpue-section">
        <div className="cpue-tabs-header" role="tablist">
          <button
            role="tab"
            aria-selected={activeTab === 'queries'}
            className={`cpue-tab${activeTab === 'queries' ? ' cpue-tab--active' : ''}`}
            onClick={() => setActiveTab('queries')}
          >
            Queries
            <span className="cpue-tab-badge">{queries.length}</span>
          </button>
          <button
            role="tab"
            aria-selected={activeTab === 'transformations'}
            className={`cpue-tab${activeTab === 'transformations' ? ' cpue-tab--active' : ''}`}
            onClick={() => setActiveTab('transformations')}
          >
            Transformations
            <span className="cpue-tab-badge cpue-tab-badge--neutral">5</span>
          </button>
        </div>

        <div className="cpue-tab-content" role="tabpanel">
          {activeTab === 'queries' ? (
            <div className="cpue-queries-tab">
              {/* Datasource selector */}
              <div className="cpue-ds-row">
                <div className="cpue-ds-dropdown" onBlur={() => setDsOpen(false)}>
                  <button
                    className="cpue-ds-btn"
                    onClick={() => setDsOpen(v => !v)}
                    aria-haspopup="listbox"
                    aria-expanded={dsOpen}
                    aria-label="Select datasource"
                  >
                    {datasource}
                    <ChevronDown
                      size={13}
                      className={`cpue-ds-chevron${dsOpen ? ' cpue-ds-chevron--open' : ''}`}
                    />
                  </button>
                  {dsOpen && (
                    <ul className="cpue-ds-menu" role="listbox">
                      {(['Loki', 'Prometheus'] as Datasource[]).map(ds => (
                        <li
                          key={ds}
                          role="option"
                          aria-selected={datasource === ds}
                          className={`cpue-ds-option${datasource === ds ? ' cpue-ds-option--active' : ''}`}
                          onMouseDown={() => handleDatasourceChange(ds)}
                        >
                          {datasource === ds && <Check size={12} className="cpue-ds-check" />}
                          {ds}
                        </li>
                      ))}
                    </ul>
                  )}
                </div>
              </div>

              {/* Query accordions */}
              <div className="cpue-query-list">
                {queries.map(q => (
                  <LokiQueryAccordion
                    key={q.id}
                    id={q.id}
                    name={q.name}
                    datasource={q.datasource}
                    initialQuery={q.query}
                    onRename={renameQuery}
                    onDuplicate={duplicateQuery}
                    onDelete={deleteQuery}
                    onQueryChange={handleQueryChange}
                    onRun={handleRunQuery}
                    runLoading={runLoading}
                    runError={runError}
                  />
                ))}
              </div>

              {/* Action row */}
              <div className="cpue-query-actions">
                <button className="cpue-action-btn" onClick={addQuery}>Add Query</button>
                <button className="cpue-action-btn">Expression</button>
                <div className="cpue-query-actions-right">
                  <button
                    className={`cpue-save-btn${savedFlash ? ' cpue-save-btn--saved' : ''}`}
                    onClick={handleSave}
                  >
                    {savedFlash ? 'Saved!' : 'Apply & Save'}
                  </button>
                </div>
              </div>
            </div>
          ) : (
            <div className="cpue-transformations-tab" aria-label="Transformations — coming soon" />
          )}
        </div>
      </div>
    </div>
  );
}
