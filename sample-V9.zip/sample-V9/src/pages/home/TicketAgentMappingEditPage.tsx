import { useEffect, useRef, useState, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { ChevronDown, Check, ArrowLeft } from 'lucide-react';
import { TimeRangePicker } from '../../components/common/TimeRangePicker';
import { DataTable, type TableColumn } from '../../components/common/DataTable';
import { LokiQueryAccordion } from '../../components/dashboard/LokiQueryAccordion';
import { fetchLokiDashboardData } from '../../services/logService';
import {
  getTicketLokiQuery,
  getTicketPrometheusQuery,
  setTicketLokiQuery,
  setTicketPrometheusQuery,
} from '../../services/ticketQueryStore';
import type { TicketMapping, TicketStatus } from '../../types/dashboard';
import './TicketAgentMappingEditPage.css';

const STATUS_LABELS: Record<TicketStatus, string> = {
  resolved:   'RESOLVED',
  processing: 'PROCESSING',
  failed:     'FAILED',
};

const COLUMNS: TableColumn<TicketMapping>[] = [
  { key: 'ticketNo',  label: 'Ticket No',   render: row => row.ticketNo  },
  { key: 'agentName', label: 'Agent Name',   render: row => row.agentName },
  {
    key: 'status',
    label: 'Status',
    render: row => (
      <span className={`dt-badge dt-badge--${row.status}`}>
        {STATUS_LABELS[row.status]}
      </span>
    ),
  },
];

type Datasource = 'Loki' | 'Prometheus';

interface QueryItem {
  id: string;
  name: string;
  datasource: Datasource;
  query: string;
}

function getDefaultQuery(ds: Datasource): string {
  return ds === 'Loki' ? getTicketLokiQuery() : getTicketPrometheusQuery();
}

export default function TicketAgentMappingEditPage() {
  const navigate = useNavigate();
  const [timeRange, setTimeRange] = useState('Last 5 Minutes');
  const [activeTab, setActiveTab] = useState<'queries' | 'transformations'>('queries');

  /* ── Datasource selector ── */
  const [datasource, setDatasource] = useState<Datasource>('Loki');
  const [dsOpen, setDsOpen] = useState(false);

  /* ── Query list ── */
  const [queries, setQueries] = useState<QueryItem[]>([
    { id: 'q1', name: 'A', datasource: 'Loki', query: getTicketLokiQuery() },
  ]);
  const queryIdRef = useRef(1);

  /* ── Ticket data (top table) ── */
  const [tickets, setTickets] = useState<TicketMapping[]>([]);
  const [tableLoading, setTableLoading] = useState(true);

  /* ── Query execution state ── */
  const [runLoading, setRunLoading] = useState(false);
  const [runError, setRunError] = useState<string | null>(null);
  const [savedFlash, setSavedFlash] = useState(false);

  useEffect(() => {
    setTableLoading(true);
    fetchLokiDashboardData(undefined, { logql: getTicketLokiQuery() })
      .then(d => setTickets(d.tickets))
      .finally(() => setTableLoading(false));
  }, []);

  /* ── Switch datasource: reload query text in all accordions ── */
  const handleDatasourceChange = useCallback((ds: Datasource) => {
    setDatasource(ds);
    setDsOpen(false);
    setQueries(prev =>
      prev.map(q => ({ ...q, datasource: ds, query: getDefaultQuery(ds) }))
    );
    setRunError(null);
  }, []);

  /* ── Track query text edits ── */
  const handleQueryChange = (id: string, query: string) => {
    setQueries(prev => prev.map(q => q.id === id ? { ...q, query } : q));
  };

  /* ── Run a query: execute against Loki, update ticket table ── */
  const handleRunQuery = async (_id: string, query: string) => {
    setRunLoading(true);
    setRunError(null);
    try {
      const result = await fetchLokiDashboardData(undefined, { logql: query });
      setTickets(result.tickets);
    } catch (err) {
      setRunError(err instanceof Error ? err.message : 'Query execution failed');
    } finally {
      setRunLoading(false);
    }
  };

  /* ── Save: persist query to the module store so HomePage picks it up ── */
  const handleSave = () => {
    queries.forEach(q => {
      if (q.datasource === 'Loki') setTicketLokiQuery(q.query);
      else setTicketPrometheusQuery(q.query);
    });
    setSavedFlash(true);
    setTimeout(() => setSavedFlash(false), 2000);
  };

  /* ── Query CRUD ── */
  const renameQuery = (id: string, newName: string) => {
    setQueries(prev => prev.map(q => q.id === id ? { ...q, name: newName } : q));
  };

  const addQuery = () => {
    setQueries(prev => {
      queryIdRef.current += 1;
      const name = String.fromCharCode(65 + prev.length);
      return [
        ...prev,
        { id: `q${queryIdRef.current}`, name, datasource, query: getDefaultQuery(datasource) },
      ];
    });
  };

  const duplicateQuery = (id: string) => {
    setQueries(prev => {
      const source = prev.find(q => q.id === id);
      if (!source) return prev;
      queryIdRef.current += 1;
      const name = String.fromCharCode(65 + prev.length);
      return [...prev, { id: `q${queryIdRef.current}`, name, datasource: source.datasource, query: source.query }];
    });
  };

  const deleteQuery = (id: string) => {
    setQueries(prev => prev.filter(q => q.id !== id));
  };

  return (
    <div className="tame-page">
      {/* ── Page header ── */}
      <div className="tame-header">
        <nav className="tame-breadcrumb" aria-label="breadcrumb">
          <button className="tame-breadcrumb-link" onClick={() => navigate('/home')}>
            Home
          </button>
          <span className="tame-breadcrumb-sep">&rsaquo;</span>
          <button className="tame-breadcrumb-link" onClick={() => navigate('/home')}>
            Dashboard
          </button>
          <span className="tame-breadcrumb-sep">&rsaquo;</span>
          <span className="tame-breadcrumb-current">Edit Ticket to Agent Mapping</span>
        </nav>

        <div className="tame-controls">
          <TimeRangePicker
            value={timeRange}
            onApply={r => setTimeRange(r.preset ?? 'Custom Range')}
          />
          <button className="tame-back-btn" onClick={() => navigate('/home')}>
            <ArrowLeft size={14} />
            Back
          </button>
        </div>
      </div>

      {/* ── Section 1: Ticket List ── */}
      <div className="tame-section">
        <h2 className="tame-section-title">Ticket to Agent Mapping</h2>
        {tableLoading ? (
          <div className="tame-table-skeleton" />
        ) : (
          <DataTable columns={COLUMNS} data={tickets} pageSize={8} />
        )}
      </div>

      {/* ── Section 2: Tab Panel ── */}
      <div className="tame-section">
        {/* Tab headers */}
        <div className="tame-tabs-header" role="tablist">
          <button
            role="tab"
            aria-selected={activeTab === 'queries'}
            className={`tame-tab${activeTab === 'queries' ? ' tame-tab--active' : ''}`}
            onClick={() => setActiveTab('queries')}
          >
            Queries
            <span className="tame-tab-badge">{queries.length}</span>
          </button>
          <button
            role="tab"
            aria-selected={activeTab === 'transformations'}
            className={`tame-tab${activeTab === 'transformations' ? ' tame-tab--active' : ''}`}
            onClick={() => setActiveTab('transformations')}
          >
            Transformations
            <span className="tame-tab-badge tame-tab-badge--neutral">5</span>
          </button>
        </div>

        {/* Tab content */}
        <div className="tame-tab-content" role="tabpanel">
          {activeTab === 'queries' ? (
            <div className="tame-queries-tab">
              {/* Datasource selector */}
              <div className="tame-ds-row">
                <div className="tame-ds-dropdown" onBlur={() => setDsOpen(false)}>
                  <button
                    className="tame-ds-btn"
                    onClick={() => setDsOpen(v => !v)}
                    aria-haspopup="listbox"
                    aria-expanded={dsOpen}
                    aria-label="Select datasource"
                  >
                    {datasource}
                    <ChevronDown size={13} className={`tame-ds-chevron${dsOpen ? ' tame-ds-chevron--open' : ''}`} />
                  </button>
                  {dsOpen && (
                    <ul className="tame-ds-menu" role="listbox">
                      {(['Loki', 'Prometheus'] as Datasource[]).map(ds => (
                        <li
                          key={ds}
                          role="option"
                          aria-selected={datasource === ds}
                          className={`tame-ds-option${datasource === ds ? ' tame-ds-option--active' : ''}`}
                          onMouseDown={() => handleDatasourceChange(ds)}
                        >
                          {datasource === ds && <Check size={12} className="tame-ds-check" />}
                          {ds}
                        </li>
                      ))}
                    </ul>
                  )}
                </div>
              </div>

              {/* Query accordions */}
              <div className="tame-query-list">
                {queries.map(q => (
                  <LokiQueryAccordion
                    key={q.id}
                    id={q.id}
                    name={q.name}
                    datasource={q.datasource}
                    initialQuery={q.query}
                    onRename={renameQuery}
                    onDuplicate={duplicateQuery}
                    onDelete={deleteQuery}
                    onQueryChange={handleQueryChange}
                    onRun={handleRunQuery}
                    runLoading={runLoading}
                    runError={runError}
                  />
                ))}
              </div>

              {/* Actions row */}
              <div className="tame-query-actions">
                <button className="tame-action-btn" onClick={addQuery}>
                  Add Query
                </button>
                <button className="tame-action-btn">Expression</button>

                <div className="tame-query-actions-right">
                  <button
                    className={`tame-save-btn${savedFlash ? ' tame-save-btn--saved' : ''}`}
                    onClick={handleSave}
                  >
                    {savedFlash ? 'Saved!' : 'Apply & Save'}
                  </button>
                </div>
              </div>
            </div>
          ) : (
            <div className="tame-transformations-tab" aria-label="Transformations — coming soon" />
          )}
        </div>
      </div>
    </div>
  );
}
