import { useEffect, useState, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { ChevronLeft } from 'lucide-react';
import { RefreshControls } from '../../components/common/RefreshControls';
import { DataTable, type TableColumn } from '../../components/common/DataTable';
import { fetchLokiDashboardData } from '../../services/logService';
import type { TicketMapping, TicketStatus } from '../../types/dashboard';
import './TicketListPage.css';

const STATUS_LABELS: Record<TicketStatus, string> = {
  resolved: 'RESOLVED',
  processing: 'PROCESSING',
  failed: 'FAILED',
};

const COLUMNS: TableColumn<TicketMapping>[] = [
  {
    key: 'ticketNo',
    label: 'Ticket No',
    clickable: true,
    render: row => row.ticketNo,
  },
  {
    key: 'agentName',
    label: 'Agent Name',
    clickable: true,
    render: row => row.agentName,
  },
  {
    key: 'status',
    label: 'Status',
    render: row => (
      <span className={`dt-badge dt-badge--${row.status}`}>
        {STATUS_LABELS[row.status]}
      </span>
    ),
  },
];

const PAGE_SIZE = 10;

export default function TicketListPage() {
  const navigate = useNavigate();
  const [tickets, setTickets] = useState<TicketMapping[]>([]);
  const [loading, setLoading] = useState(true);
  const [spinning, setSpinning] = useState(false);

  const load = useCallback(async () => {
    setSpinning(true);
    try {
      const { tickets: data } = await fetchLokiDashboardData();
      setTickets(data);
    } finally {
      setLoading(false);
      setSpinning(false);
    }
  }, []);

  useEffect(() => { load(); }, [load]);

  return (
    <div className="tl-page">
      <div className="tl-header">
        <div className="tl-breadcrumb">
          <span className="tl-breadcrumb-link" onClick={() => navigate('/home')}>Home</span>
          <span className="tl-breadcrumb-sep">&rsaquo;</span>
          <span className="tl-breadcrumb-current">Ticket List</span>
        </div>

        <div className="tl-actions">
          <button className="tl-back-btn" onClick={() => navigate('/home')}>
            <ChevronLeft size={14} />
            Back
          </button>
          <RefreshControls onRefresh={load} spinning={spinning} />
        </div>
      </div>
      
      <div className="tl-title-row">
        <h1 className="tl-title">Ticket to Agent Mapping</h1>
        <span className="tl-count">{loading ? '—' : `${tickets.length} tickets`}</span>
      </div>

      <div className="tl-card">
        <div className="tl-filter-row">
          <div className="tl-search-wrap">
            <svg className="tl-search-icon" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <circle cx="11" cy="11" r="8" /><line x1="21" y1="21" x2="16.65" y2="16.65" />
            </svg>
            <span className="tl-search-placeholder">Search tickets…</span>
          </div>
        </div>

        {loading ? (
          <div className="tl-skeleton-wrap">
            {[...Array(PAGE_SIZE)].map((_, i) => (
              <div key={i} className="tl-skeleton-row" />
            ))}
          </div>
        ) : (
          <DataTable
            columns={COLUMNS}
            data={tickets}
            pageSize={PAGE_SIZE}
            emptyText="No tickets found."
            onRowClick={ticket => navigate(`/tickets/${ticket.id}`, { state: { ticket } })}
          />
        )}
      </div>
    </div>
  );
}
