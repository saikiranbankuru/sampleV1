export interface InputTokenDataPoint {
  platform: string;
  value: number;
}

export interface OutputTokenDataPoint {
  month: string;
  value: number;
}

export interface AgentMetrics {
  warnings: number;
  errors: number;
  aiChatRequests: number;
  avgLatencyMs: number;
  costUsd: number;
  cpuUsage: number;
  memoryUsage: number;
  accuracyScore: number;
  processingTime1: number;
  processingTime2: number;
  processingTime3: number;
  messagesPerTask: number;
  tasksCompleted: number;
  inputTokensData: InputTokenDataPoint[];
  outputTokensData: OutputTokenDataPoint[];
}

export interface PrometheusMetricsResponse {
  success: boolean;
  message: string;
  data: AgentMetrics;
}
