export interface LokiLogEntry {
  case_number: string;
  record: string;
  service_name: string;
  timestamp: string;
  status?: 'resolved' | 'processing' | 'failed';
}

export interface LokiQueryData {
  query: string;
  total_streams: number;
  total_logs: number;
  streams: LokiLogEntry[];
}

export interface LokiQueryResponse {
  success: boolean;
  message: string;
  data: LokiQueryData;
}
