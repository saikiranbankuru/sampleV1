import { http, HttpResponse } from 'msw';
import type { LokiQueryResponse } from '@/types/log';
import type { PrometheusMetricsResponse } from '@/types/metrics';

const LOKI_BASE_URL       = import.meta.env.VITE_API_LOKI_BASE_URL       as string;
const PROMETHEUS_BASE_URL = import.meta.env.VITE_API_PROMETHEUS_BASE_URL  as string;
const DB_BASE_URL         = import.meta.env.VITE_API_DB_BASE_URL          as string;

void DB_BASE_URL; // handler not yet needed

// ---------------------------------------------------------------------------
// Mock data
// ---------------------------------------------------------------------------

const MOCK_STREAMS = [
  { case_number: 'CS0007894', record: 'INC002012', service_name: 'Digital-Agent',  timestamp: '2026-05-21T12:00:00Z', status: 'resolved'   },
  { case_number: 'CS0007895', record: 'INC002013', service_name: 'digital-agent',  timestamp: '2026-05-25T12:05:00Z', status: 'processing' },
  { case_number: 'CS0007896', record: 'INC002014', service_name: 'Digital-Agent',  timestamp: '2026-05-25T12:10:00Z', status: 'failed'     },
  { case_number: 'CS0007897', record: 'INC002015', service_name: 'digital-agent',  timestamp: '2026-05-25T12:15:00Z', status: 'resolved'   },
  { case_number: 'CS0007898', record: 'INC002016', service_name: 'Digital-Agent',  timestamp: '2026-05-25T12:20:00Z', status: 'processing' },
  { case_number: 'CS0007899', record: 'INC002017', service_name: 'digital-agent',  timestamp: '2026-05-25T12:25:00Z', status: 'resolved'   },
  { case_number: 'CS0007900', record: 'INC002018', service_name: 'Digital-Agent',  timestamp: '2026-05-25T12:30:00Z', status: 'failed'     },
  { case_number: 'CS0007901', record: 'INC002019', service_name: 'digital-agent',  timestamp: '2026-05-25T12:35:00Z', status: 'processing' },
] as const;

const MOCK_METRICS: PrometheusMetricsResponse = {
  success: true,
  message: 'Metrics fetched successfully',
  data: {
    warnings: 75,
    errors: 4,
    aiChatRequests: 52,
    avgLatencyMs: 0.77,
    costUsd: 85,
    cpuUsage: 73,
    memoryUsage: 9,
    accuracyScore: 24,
    processingTime1: 4,
    processingTime2: 56,
    processingTime3: 65,
    messagesPerTask: 56,
    tasksCompleted: 65,
    inputTokensData: [
      { platform: 'Linux',   value: 28000 },
      { platform: 'Mac',     value: 20000 },
      { platform: 'iOS',     value: 12000 },
      { platform: 'Windows', value: 30000 },
      { platform: 'Android', value: 15000 },
      { platform: 'Other',   value: 22000 },
    ],
    outputTokensData: [
      { month: 'Jan', value: 4000  },
      { month: 'Feb', value: 7500  },
      { month: 'Mar', value: 5200  },
      { month: 'Apr', value: 11000 },
      { month: 'May', value: 9000  },
      { month: 'Jun', value: 15500 },
    ],
  },
};

// ---------------------------------------------------------------------------
// Handlers
// ---------------------------------------------------------------------------

export const handlers = [
  // Loki — log streams
  http.get(`${LOKI_BASE_URL}/query`, ({ request }) => {
    const url = new URL(request.url);
    const limit = Number(url.searchParams.get('limit') ?? 50);
    const streams = MOCK_STREAMS.slice(0, limit);

    const body: LokiQueryResponse = {
      success: true,
      message: 'Logs fetched successfully',
      data: {
        query: url.searchParams.get('logql') ?? '',
        total_streams: streams.length,
        total_logs: streams.length,
        streams,
      },
    };
    return HttpResponse.json(body);
  }),

  // Prometheus — agent metrics
  http.get(`${PROMETHEUS_BASE_URL}/query`, () => {
    return HttpResponse.json(MOCK_METRICS);
  }),
];
