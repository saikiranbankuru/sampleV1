import { lokiApiClient } from './apiClient';
import type { LokiQueryResponse, LokiLogEntry } from '@/types/log';
import type { TicketMapping, AgentRun, CaseWorked, Incident } from '@/types/dashboard';

const LOGQL =
  `{service_name=~"Digital-Agent|digital-agent"}  !=~` +
  '`""` | json | label_format agent=service_name | line_format `{{.case_number}}/{{.record}}`';

interface LogQueryParams {
  logql: string;
  lookback_seconds: number;
  limit: number;
  direction: 'backward' | 'forward';
}

const DEFAULT_PARAMS: LogQueryParams = {
  logql: LOGQL,
  lookback_seconds: 3600,
  limit: 50,
  direction: 'backward',
};

export interface LokiDashboardData {
  tickets: TicketMapping[];
  agentRuns: AgentRun[];
  casesWorked: CaseWorked[];
  incidents: Incident[];
}

// ---------------------------------------------------------------------------
// Mappers
// ---------------------------------------------------------------------------

const toTicketMapping = (entry: LokiLogEntry, index: number): TicketMapping => ({
  id: String(index + 1),
  ticketNo: entry.case_number,
  agentName: entry.service_name,
  agentId: String(index + 1),
  status: entry.status ?? 'processing',
});

const toDateString = (timestamp: string): string => {
  const d = new Date(timestamp);
  const dd = String(d.getDate()).padStart(2, '0');
  const mm = String(d.getMonth() + 1).padStart(2, '0');
  const yy = String(d.getFullYear()).slice(-2);
  return `${dd}-${mm}-${yy}`;
};

const toTimeAgo = (timestamp: string): string => {
  const diffMs = Date.now() - new Date(timestamp).getTime();
  const mins = Math.floor(diffMs / 60_000);
  if (mins < 1) return 'just now';
  if (mins < 60) return `${mins} min${mins === 1 ? '' : 's'} ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs} hr${hrs === 1 ? '' : 's'} ago`;
  const days = Math.floor(hrs / 24);
  return `${days} day${days === 1 ? '' : 's'} ago`;
};

const toAgentRun = (entry: LokiLogEntry, index: number): AgentRun => ({
  id: String(index + 1),
  name: entry.service_name,
  date: toDateString(entry.timestamp),
  lastRunAgo: toTimeAgo(entry.timestamp),
  status: entry.status === 'failed' ? 'inactive' : 'active',
});

const toCasesWorked = (streams: LokiLogEntry[]): CaseWorked[] => {
  const counts = new Map<string, number>();
  streams.forEach(e => counts.set(e.service_name, (counts.get(e.service_name) ?? 0) + 1));
  return Array.from(counts.entries()).map(([agentName, count], index) => ({
    id: String(index + 1),
    agentName,
    count,
  }));
};

const toIncident = (entry: LokiLogEntry, index: number): Incident => ({
  id: String(index + 1),
  agentName: entry.service_name,
  caseNumber: entry.case_number,
});

// ---------------------------------------------------------------------------
// Public API — single fetch, two derived views
// ---------------------------------------------------------------------------

export const fetchLokiDashboardData = async (
  params: Partial<LogQueryParams> = {},
): Promise<LokiDashboardData> => {
  const response = await lokiApiClient.get<LokiQueryResponse>('/query', {
    params: { ...DEFAULT_PARAMS, ...params },
  });

  const streams = response.data.streams;

  return {
    tickets: streams.map(toTicketMapping),
    agentRuns: streams.map(toAgentRun),
    casesWorked: toCasesWorked(streams),
    incidents: streams.map(toIncident),
  };
};
