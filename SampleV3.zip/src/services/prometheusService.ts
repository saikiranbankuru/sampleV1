import { prometheusApiClient } from './apiClient';
import type { PrometheusMetricsResponse, AgentMetrics } from '@/types/metrics';

// Dummy PromQL — replace with real query when backend is ready.
const DUMMY_PROMQL = `agent_metrics{service=~"Digital-Agent|digital-agent"}`;

interface MetricsQueryParams {
  promql: string;
  agent: string;
  case_number: string;
}

export const fetchAgentMetrics = async (
  agentName: string,
  caseNumber: string,
): Promise<AgentMetrics> => {
  const params: MetricsQueryParams = {
    promql: DUMMY_PROMQL,
    agent: agentName,
    case_number: caseNumber,
  };
  const response = await prometheusApiClient.get<PrometheusMetricsResponse>(
    '/query',
    { params },
  );
  return response.data;
};
