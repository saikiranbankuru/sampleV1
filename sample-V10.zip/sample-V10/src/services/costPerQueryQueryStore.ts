export const DEFAULT_COST_PER_QUERY_PROMETHEUS_QUERY =
  '(sum(tokens_input_total{exported_job="$agents",case_number="$ticket"}) * 0.00003)' +
  '+(sum(tokens_output_total{exported_job="$agents",case_number="$ticket"}) * 0.00006)';

export const DEFAULT_COST_PER_QUERY_LOKI_QUERY =
  '{service_name="$agents"} | json | __error__="" | case_number="$ticket"';

let _prometheusQuery = DEFAULT_COST_PER_QUERY_PROMETHEUS_QUERY;
let _lokiQuery = DEFAULT_COST_PER_QUERY_LOKI_QUERY;

export const getCostPerQueryPrometheusQuery = () => _prometheusQuery;
export const getCostPerQueryLokiQuery = () => _lokiQuery;
export const setCostPerQueryPrometheusQuery = (q: string) => { _prometheusQuery = q; };
export const setCostPerQueryLokiQuery = (q: string) => { _lokiQuery = q; };

export function buildCostPerQuery(
  template: string,
  agentName: string,
  ticketNumber?: string,
): string {
  return template
    .replace(/\$agents/g, agentName)
    .replace(/\$ticket/g, ticketNumber ?? '');
}
