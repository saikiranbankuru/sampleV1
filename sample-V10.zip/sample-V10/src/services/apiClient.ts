import { type AxiosInstance, type AxiosRequestConfig } from 'axios';
import { lokiInstance, prometheusInstance, dbInstance } from '@/lib/http';

const createApiClient = (instance: AxiosInstance) => ({
  get: async <T>(url: string, config?: AxiosRequestConfig): Promise<T> => {
    const response = await instance.get<T>(url, config);
    return response.data;
  },
  post: async <T>(url: string, body?: unknown, config?: AxiosRequestConfig): Promise<T> => {
    const response = await instance.post<T>(url, body, config);
    return response.data;
  },
  put: async <T>(url: string, body?: unknown, config?: AxiosRequestConfig): Promise<T> => {
    const response = await instance.put<T>(url, body, config);
    return response.data;
  },
  patch: async <T>(url: string, body?: unknown, config?: AxiosRequestConfig): Promise<T> => {
    const response = await instance.patch<T>(url, body, config);
    return response.data;
  },
  del: async <T>(url: string, config?: AxiosRequestConfig): Promise<T> => {
    const response = await instance.delete<T>(url, config);
    return response.data;
  },
});

export const lokiApiClient       = createApiClient(lokiInstance);
export const prometheusApiClient = createApiClient(prometheusInstance);
export const dbApiClient         = createApiClient(dbInstance);
