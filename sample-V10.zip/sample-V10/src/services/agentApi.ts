import { dbApiClient as apiClient } from './apiClient';
import type { AgentDetails, AgentLog } from '../types/agent';

const USE_MOCK = import.meta.env.VITE_USE_MOCK !== 'false';

const delay = (ms: number) => new Promise<void>((res) => setTimeout(res, ms));

// ---------------------------------------------------------------------------
// Mock data
// ---------------------------------------------------------------------------

const LOG_RECORDS: Record<AgentLog['type'], Array<{ timestamp: string; record: string }>> = {
  info: [
    { timestamp: '2026-04-22 12:41:43', record: 'INC002012' },
    { timestamp: '2026-04-22 12:45:11', record: 'INC002013' },
    { timestamp: '2026-04-22 13:02:55', record: 'INC002014' },
    { timestamp: '2026-04-22 13:18:30', record: 'INC002015' },
    { timestamp: '2026-04-22 13:45:22', record: 'INC002016' },
    { timestamp: '2026-04-22 14:10:08', record: 'INC002017' },
    { timestamp: '2026-04-22 14:32:45', record: 'INC002018' },
  ],
  error: [
    { timestamp: '2026-04-22 09:15:22', record: 'ERR003001' },
    { timestamp: '2026-04-22 10:30:44', record: 'ERR003002' },
    { timestamp: '2026-04-22 11:48:19', record: 'ERR003003' },
    { timestamp: '2026-04-22 15:22:07', record: 'ERR003004' },
  ],
  warning: [
    { timestamp: '2026-04-22 08:05:33', record: 'WRN004001' },
    { timestamp: '2026-04-22 09:52:17', record: 'WRN004002' },
    { timestamp: '2026-04-22 12:08:55', record: 'WRN004003' },
    { timestamp: '2026-04-22 14:55:41', record: 'WRN004004' },
    { timestamp: '2026-04-22 16:18:29', record: 'WRN004005' },
  ],
};

const makeLogs = (type: AgentLog['type']): AgentLog[] =>
  LOG_RECORDS[type].map((d, i) => ({ id: String(i + 1), ...d, type }));

const BASE_DATA: Omit<AgentDetails, 'id' | 'name'> = {
  status: 'active',
  metrics: {
    warnings: 75,
    errors: 4,
    aiChatRequests: 52,
    avgLatencyMs: 0.77,
    costUsd: 85,
    cpuUsage: 73,
    memoryUsage: 9,
    accuracyScore: 24,
    processingTime1: 4,
    processingTime2: 56,
    processingTime3: 65,
    messagesPerTask: 56,
    tasksCompleted: 65,
  },
  logs: makeLogs('info'),
  inputTokensData: [
    { platform: 'Linux',   value: 28000 },
    { platform: 'Mac',     value: 20000 },
    { platform: 'iOS',     value: 12000 },
    { platform: 'Windows', value: 30000 },
    { platform: 'Android', value: 15000 },
    { platform: 'Other',   value: 22000 },
  ],
  outputTokensData: [
    { month: 'Jan', value: 4000  },
    { month: 'Feb', value: 7500  },
    { month: 'Mar', value: 5200  },
    { month: 'Apr', value: 11000 },
    { month: 'May', value: 9000  },
    { month: 'Jun', value: 15500 },
  ],
};

const AGENT_NAMES: Record<string, string> = {
  '1': 'CCSY_GENAI-API-Gateway',
  '2': 'CCSY_GENAI-API-Gateway',
  '3': 'Agentic-AI-IT-Operations',
  '4': 'CCSY-GENAI-DENTIX',
  '5': 'Agentic-AI-IT-Operations',
};

// ---------------------------------------------------------------------------
// API functions
// ---------------------------------------------------------------------------

export const registerDynamicAgent = (id: string, name: string): void => {
  AGENT_NAMES[id] = name;
};

export const fetchAgentById = async (id: string): Promise<AgentDetails> => {
  if (!USE_MOCK) return apiClient.get<AgentDetails>(`/agents/${id}`);
  await delay(350);
  return { ...BASE_DATA, id, name: AGENT_NAMES[id] ?? 'Unknown Agent' };
};

export const fetchAgentLogs = async (
  id: string,
  type: AgentLog['type'],
): Promise<AgentLog[]> => {
  if (!USE_MOCK) return apiClient.get<AgentLog[]>(`/agents/${id}/logs?type=${type}`);
  await delay(200);
  return makeLogs(type);
};
