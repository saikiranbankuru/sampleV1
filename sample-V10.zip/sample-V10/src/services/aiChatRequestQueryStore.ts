export const DEFAULT_AI_CHAT_REQUEST_PROMETHEUS_QUERY =
  'sum(chat_requests_total{exported_job="$agents",case_number="$ticket"})';

export const DEFAULT_AI_CHAT_REQUEST_LOKI_QUERY =
  '{service_name="$agents"} | json | __error__="" | case_number="$ticket"';

let _prometheusQuery = DEFAULT_AI_CHAT_REQUEST_PROMETHEUS_QUERY;
let _lokiQuery = DEFAULT_AI_CHAT_REQUEST_LOKI_QUERY;

export const getAiChatRequestPrometheusQuery = () => _prometheusQuery;
export const getAiChatRequestLokiQuery = () => _lokiQuery;
export const setAiChatRequestPrometheusQuery = (q: string) => { _prometheusQuery = q; };
export const setAiChatRequestLokiQuery = (q: string) => { _lokiQuery = q; };

export function buildAiChatRequestQuery(
  template: string,
  agentName: string,
  ticketNumber?: string,
): string {
  return template
    .replace(/\$agents/g, agentName)
    .replace(/\$ticket/g, ticketNumber ?? '');
}
