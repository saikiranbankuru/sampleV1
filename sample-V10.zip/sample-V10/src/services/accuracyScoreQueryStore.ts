export const DEFAULT_ACCURACY_SCORE_PROMETHEUS_QUERY =
  'sum(accuracy_score_latest{exported_job="$agents",case_number="$ticket"})';

export const DEFAULT_ACCURACY_SCORE_LOKI_QUERY =
  '{service_name="$agents"} | json | __error__="" | case_number="$ticket"';

let _prometheusQuery = DEFAULT_ACCURACY_SCORE_PROMETHEUS_QUERY;
let _lokiQuery = DEFAULT_ACCURACY_SCORE_LOKI_QUERY;

export const getAccuracyScorePrometheusQuery = () => _prometheusQuery;
export const getAccuracyScoreLokiQuery = () => _lokiQuery;
export const setAccuracyScorePrometheusQuery = (q: string) => { _prometheusQuery = q; };
export const setAccuracyScoreLokiQuery = (q: string) => { _lokiQuery = q; };

export function buildAccuracyScoreQuery(
  template: string,
  agentName: string,
  ticketNumber?: string,
): string {
  return template
    .replace(/\$agents/g, agentName)
    .replace(/\$ticket/g, ticketNumber ?? '');
}
