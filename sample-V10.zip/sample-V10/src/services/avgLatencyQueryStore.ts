export const DEFAULT_AVG_LATENCY_PROMETHEUS_QUERY =
  'sum(chat_request_latency_ms_milliseconds_sum{exported_job="$agents",case_number="$ticket"})' +
  '/sum(chat_request_latency_ms_milliseconds_count{exported_job="$agents",case_number="$ticket"})';

export const DEFAULT_AVG_LATENCY_LOKI_QUERY =
  '{service_name="$agents"} | json | __error__="" | case_number="$ticket"';

let _prometheusQuery = DEFAULT_AVG_LATENCY_PROMETHEUS_QUERY;
let _lokiQuery = DEFAULT_AVG_LATENCY_LOKI_QUERY;

export const getAvgLatencyPrometheusQuery = () => _prometheusQuery;
export const getAvgLatencyLokiQuery = () => _lokiQuery;
export const setAvgLatencyPrometheusQuery = (q: string) => { _prometheusQuery = q; };
export const setAvgLatencyLokiQuery = (q: string) => { _lokiQuery = q; };

export function buildAvgLatencyQuery(
  template: string,
  agentName: string,
  ticketNumber?: string,
): string {
  return template
    .replace(/\$agents/g, agentName)
    .replace(/\$ticket/g, ticketNumber ?? '');
}
