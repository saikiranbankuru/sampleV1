export const DEFAULT_INPUT_TOKEN_PROMETHEUS_QUERY =
  'sum(tokens_input_total{exported_job="$agentName",case_number="$ticketNumber"})';

export const DEFAULT_INPUT_TOKEN_LOKI_QUERY =
  '{service_name="$agentName"} | json | __error__="" | case_number="$ticketNumber"';

let _prometheusQuery = DEFAULT_INPUT_TOKEN_PROMETHEUS_QUERY;
let _lokiQuery = DEFAULT_INPUT_TOKEN_LOKI_QUERY;

export const getInputTokenPrometheusQuery = () => _prometheusQuery;
export const getInputTokenLokiQuery = () => _lokiQuery;
export const setInputTokenPrometheusQuery = (q: string) => { _prometheusQuery = q; };
export const setInputTokenLokiQuery = (q: string) => { _lokiQuery = q; };

/** Replace $agentName and $ticketNumber placeholders in a query template. */
export function buildInputTokenQuery(
  template: string,
  agentName: string,
  ticketNumber?: string,
): string {
  return template
    .replace(/\$agentName/g, agentName)
    .replace(/\$ticketNumber/g, ticketNumber ?? '');
}
