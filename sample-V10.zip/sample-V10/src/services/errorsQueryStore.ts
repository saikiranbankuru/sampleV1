export const DEFAULT_ERRORS_LOKI_QUERY =
  '{service_name="$agents"} | json | (__error__="" or __error__="JSONParserErr") | label_format level=detected_level | (case_number="$ticket" or record="$ticket") | level = `error`';

export const DEFAULT_ERRORS_PROMETHEUS_QUERY = '{service_name="$agents"}';

let _lokiQuery = DEFAULT_ERRORS_LOKI_QUERY;
let _prometheusQuery = DEFAULT_ERRORS_PROMETHEUS_QUERY;

export const getErrorsLokiQuery = () => _lokiQuery;
export const getErrorsPrometheusQuery = () => _prometheusQuery;
export const setErrorsLokiQuery = (q: string) => { _lokiQuery = q; };
export const setErrorsPrometheusQuery = (q: string) => { _prometheusQuery = q; };

export function buildErrorsQuery(
  template: string,
  agentName: string,
  ticketNumber?: string,
): string {
  return template
    .replace(/\$agents/g, agentName)
    .replace(/\$ticket/g, ticketNumber ?? '');
}
