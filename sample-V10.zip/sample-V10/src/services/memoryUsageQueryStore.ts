export const DEFAULT_MEMORY_USAGE_PROMETHEUS_QUERY =
  'sum(memory_usage_percent_sum{exported_job="$agents",case_number="$ticket"})/sum(memory_usage_percent_count{exported_job="$agents",case_number="$ticket"})';

export const DEFAULT_MEMORY_USAGE_LOKI_QUERY =
  '{service_name="$agents"} | json | __error__="" | case_number="$ticket"';

let _prometheusQuery = DEFAULT_MEMORY_USAGE_PROMETHEUS_QUERY;
let _lokiQuery = DEFAULT_MEMORY_USAGE_LOKI_QUERY;

export const getMemoryUsagePrometheusQuery = () => _prometheusQuery;
export const getMemoryUsageLokiQuery = () => _lokiQuery;
export const setMemoryUsagePrometheusQuery = (q: string) => { _prometheusQuery = q; };
export const setMemoryUsageLokiQuery = (q: string) => { _lokiQuery = q; };

export function buildMemoryUsageQuery(
  template: string,
  agentName: string,
  ticketNumber?: string,
): string {
  return template
    .replace(/\$agents/g, agentName)
    .replace(/\$ticket/g, ticketNumber ?? '');
}
