export const DEFAULT_CPU_USAGE_PROMETHEUS_QUERY =
  'sum(cpu_usage_percent_sum{exported_job="$agents",case_number="$ticket"})/sum(cpu_usage_percent_count{exported_job="$agents",case_number="$ticket"})';

export const DEFAULT_CPU_USAGE_LOKI_QUERY =
  '{service_name="$agents"} | json | __error__="" | case_number="$ticket"';

let _prometheusQuery = DEFAULT_CPU_USAGE_PROMETHEUS_QUERY;
let _lokiQuery = DEFAULT_CPU_USAGE_LOKI_QUERY;

export const getCpuUsagePrometheusQuery = () => _prometheusQuery;
export const getCpuUsageLokiQuery = () => _lokiQuery;
export const setCpuUsagePrometheusQuery = (q: string) => { _prometheusQuery = q; };
export const setCpuUsageLokiQuery = (q: string) => { _lokiQuery = q; };

export function buildCpuUsageQuery(
  template: string,
  agentName: string,
  ticketNumber?: string,
): string {
  return template
    .replace(/\$agents/g, agentName)
    .replace(/\$ticket/g, ticketNumber ?? '');
}
