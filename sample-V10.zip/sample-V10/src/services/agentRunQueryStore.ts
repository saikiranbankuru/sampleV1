export const DEFAULT_AGENT_LOKI_QUERY =
  '{service_name=~"Agentic-AI-IT-Operations|CCGY-GENAI-API-GATEWAY|CCGY-GENAI-IDENTIX|CCGY-GENAI-XCEL-INSIGHT|linux-agent|itsm-agent-crew|Digital-Agent|digital-agent|Wintel|azure-wintel|dba-agent|Azure-Wintel|Linux-agent|db-agent|network-agent|aws-linux|wintel-agent|aws-wintel"} != `""`' +
  '\n| json | label_format agent=service_name\n| line_format `{{.case_number}}{{.record}}`';

export const DEFAULT_AGENT_PROMETHEUS_QUERY =
  '{service_name=~"Agentic-AI-IT-Operations|CCGY-GENAI-API-GATEWAY|CCGY-GENAI-IDENTIX|CCGY-GENAI-XCEL-INSIGHT|linux-agent|itsm-agent-crew|Digital-Agent|digital-agent|Wintel|azure-wintel|dba-agent|Azure-Wintel|Linux-agent|db-agent|network-agent|aws-linux|wintel-agent|aws-wintel"}';

let _lokiQuery = DEFAULT_AGENT_LOKI_QUERY;
let _prometheusQuery = DEFAULT_AGENT_PROMETHEUS_QUERY;

export const getAgentLokiQuery = () => _lokiQuery;
export const getAgentPrometheusQuery = () => _prometheusQuery;

export const setAgentLokiQuery = (q: string) => { _lokiQuery = q; };
export const setAgentPrometheusQuery = (q: string) => { _prometheusQuery = q; };
