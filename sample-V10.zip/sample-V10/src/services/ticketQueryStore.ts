export const DEFAULT_LOKI_QUERY =
  '{service_name=~"linux-agent|dba-agent|Azure-Wintel|aws-linux|Wintel|Agentic-AI-IT-Operations|network-agent|wintel-agent|aws-wintel|db-agent|azure-wintel|Linux-agent"}  != `""`' +
  '\n| json | label_format agent=service_name \n| line_format `{{.case_number}}{{.record}}`';

export const DEFAULT_PROMETHEUS_QUERY =
  '{service_name=~"linux-agent|dba-agent|Azure-Wintel|aws-linux|Wintel|Agentic-AI-IT-Operations|network-agent|wintel-agent|aws-wintel|db-agent|azure-wintel|Linux-agent"}';

let _lokiQuery = DEFAULT_LOKI_QUERY;
let _prometheusQuery = DEFAULT_PROMETHEUS_QUERY;

export const getTicketLokiQuery = () => _lokiQuery;
export const getTicketPrometheusQuery = () => _prometheusQuery;

export const setTicketLokiQuery = (q: string) => { _lokiQuery = q; };
export const setTicketPrometheusQuery = (q: string) => { _prometheusQuery = q; };
