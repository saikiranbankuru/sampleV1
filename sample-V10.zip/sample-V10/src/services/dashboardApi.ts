import { dbApiClient as apiClient } from './apiClient';
import type {
  DashboardData,
  MetricStats,
  AgentRun,
  TicketMapping,
  CaseWorked,
  AvailableAgent,
  Incident,
} from '../types/dashboard';
import availableAgentsJson from '../data/availableAgents.json';

const USE_MOCK = import.meta.env.VITE_USE_MOCK !== 'false';

const delay = (ms: number) => new Promise<void>((res) => setTimeout(res, ms));

// ---------------------------------------------------------------------------
// Mock data
// ---------------------------------------------------------------------------

const MOCK_METRICS: MetricStats = {
  totalTickets: 23,
  activeAgents: 12,
  totalCasesProcessed: 87,
  failedCases: 4,
};

const MOCK_AGENT_RUNS: AgentRun[] = [
  { id: '1', name: 'Agentic-AI-IT-Operations', date: '21-04-26', lastRunAgo: '2 mins ago', status: 'active' },
  { id: '2', name: 'Agentic-AI-IT-Operations', date: '21-04-26', lastRunAgo: '2 mins ago', status: 'active' },
  { id: '3', name: 'Agentic-AI-IT-Operations', date: '21-04-26', lastRunAgo: '2 mins ago', status: 'active' },
  { id: '4', name: 'Agentic-AI-IT-Operations', date: '21-04-26', lastRunAgo: '2 mins ago', status: 'active' },
  { id: '5', name: 'Agentic-AI-IT-Operations', date: '21-04-26', lastRunAgo: '2 mins ago', status: 'active' },
];

const ALL_TICKETS: TicketMapping[] = [
  { id: '1',  ticketNo: 'CS0007894', agentName: 'AGENTIC-AI-IT-OPERATION',  agentId: '3', status: 'resolved'   },
  { id: '2',  ticketNo: 'CS0007895', agentName: 'AGENTIC-AI-IT-OPERATION',  agentId: '3', status: 'processing' },
  { id: '3',  ticketNo: 'CS0007896', agentName: 'AGENTIC-AI-IT-OPERATION',  agentId: '3', status: 'failed'     },
  { id: '4',  ticketNo: 'CS0007897', agentName: 'AGENTIC-AI-IT-OPERATION',  agentId: '3', status: 'resolved'   },
  { id: '5',  ticketNo: 'CS0007898', agentName: 'AGENTIC-AI-IT-OPERATION',  agentId: '3', status: 'processing' },
  { id: '6',  ticketNo: 'CS0007899', agentName: 'CCSY-GENAI-API-GATEWAY',   agentId: '1', status: 'resolved'   },
  { id: '7',  ticketNo: 'CS0007900', agentName: 'CCSY-GENAI-API-GATEWAY',   agentId: '1', status: 'failed'     },
  { id: '8',  ticketNo: 'CS0007901', agentName: 'CCSY-GENAI-DENTIX',        agentId: '4', status: 'processing' },
  { id: '9',  ticketNo: 'CS0007902', agentName: 'CCSY-GENAI-DENTIX',        agentId: '4', status: 'resolved'   },
  { id: '10', ticketNo: 'CS0007903', agentName: 'AGENTIC-AI-IT-OPERATION',  agentId: '3', status: 'failed'     },
  { id: '11', ticketNo: 'CS0007904', agentName: 'CCSY-GENAI-API-GATEWAY',   agentId: '1', status: 'resolved'   },
  { id: '12', ticketNo: 'CS0007905', agentName: 'AGENTIC-AI-IT-OPERATION',  agentId: '3', status: 'processing' },
  { id: '13', ticketNo: 'CS0007906', agentName: 'CCSY-GENAI-DENTIX',        agentId: '4', status: 'resolved'   },
  { id: '14', ticketNo: 'CS0007907', agentName: 'CCSY-GENAI-API-GATEWAY',   agentId: '1', status: 'failed'     },
  { id: '15', ticketNo: 'CS0007908', agentName: 'AGENTIC-AI-IT-OPERATION',  agentId: '3', status: 'processing' },
  { id: '16', ticketNo: 'CS0007909', agentName: 'CCSY-GENAI-DENTIX',        agentId: '4', status: 'resolved'   },
  { id: '17', ticketNo: 'CS0007910', agentName: 'AGENTIC-AI-IT-OPERATION',  agentId: '3', status: 'failed'     },
  { id: '18', ticketNo: 'CS0007911', agentName: 'CCSY-GENAI-API-GATEWAY',   agentId: '1', status: 'resolved'   },
  { id: '19', ticketNo: 'CS0007912', agentName: 'CCSY-GENAI-DENTIX',        agentId: '4', status: 'processing' },
  { id: '20', ticketNo: 'CS0007913', agentName: 'AGENTIC-AI-IT-OPERATION',  agentId: '3', status: 'resolved'   },
  { id: '21', ticketNo: 'CS0007914', agentName: 'CCSY-GENAI-API-GATEWAY',   agentId: '1', status: 'failed'     },
  { id: '22', ticketNo: 'CS0007915', agentName: 'CCSY-GENAI-DENTIX',        agentId: '4', status: 'processing' },
  { id: '23', ticketNo: 'CS0007916', agentName: 'AGENTIC-AI-IT-OPERATION',  agentId: '3', status: 'resolved'   },
  { id: '24', ticketNo: 'CS0007917', agentName: 'CCSY-GENAI-API-GATEWAY',   agentId: '1', status: 'processing' },
  { id: '25', ticketNo: 'CS0007918', agentName: 'CCSY-GENAI-DENTIX',        agentId: '4', status: 'failed'     },
];

const MOCK_CASES_WORKED: CaseWorked[] = [
  { id: '1', count: 4, agentName: 'Agentic-AI-IT-Operation' },
  { id: '2', count: 4, agentName: 'Agentic-AI-IT-Operation' },
  { id: '3', count: 4, agentName: 'Agentic-AI-IT-Operation' },
  { id: '4', count: 4, agentName: 'Agentic-AI-IT-Operation' },
];

const AVAILABLE_AGENTS: AvailableAgent[] = [
  { id: '1', name: 'CCSY_GENAI-API-Gateway' },
  { id: '2', name: 'CCSY_GENAI-API-Gateway' },
  { id: '3', name: 'Agentic-AI-IT-Operations' },
  { id: '4', name: 'CCSY-GENAI-DENTIX' },
  { id: '5', name: 'Agentic-AI-IT-Operations' },
];

const MOCK_INCIDENTS: Incident[] = [
  { id: '1', agentName: 'Agentic-AI-IT-Operations', caseNumber: 'c1234565432s' },
  { id: '2', agentName: 'Agentic-AI-IT-Operations', caseNumber: 'c1234565432s' },
  { id: '3', agentName: 'Agentic-AI-IT-Operations', caseNumber: 'c1234565432s' },
  { id: '4', agentName: 'Agentic-AI-IT-Operations', caseNumber: 'c1234565432s' },
  { id: '5', agentName: 'Agentic-AI-IT-Operations', caseNumber: 'c1234565432s' },
];

let _nextAgentId = 6;

// ---------------------------------------------------------------------------
// API functions
// ---------------------------------------------------------------------------

export const fetchMetrics = async (): Promise<MetricStats> => {
  if (!USE_MOCK) return apiClient.get<MetricStats>('/dashboard/metrics');
  await delay(300);
  return MOCK_METRICS;
};

export const fetchAgentRuns = async (): Promise<AgentRun[]> => {
  if (!USE_MOCK) return apiClient.get<AgentRun[]>('/dashboard/agent-runs');
  await delay(400);
  return MOCK_AGENT_RUNS;
};

export const fetchTicketMappings = async (): Promise<TicketMapping[]> => {
  if (!USE_MOCK) return apiClient.get<TicketMapping[]>('/dashboard/tickets?limit=8');
  await delay(350);
  return ALL_TICKETS.slice(0, 8);
};

export const fetchTicketById = async (id: string): Promise<TicketMapping | null> => {
  if (!USE_MOCK) return apiClient.get<TicketMapping>(`/dashboard/tickets/${id}`);
  await delay(200);
  return ALL_TICKETS.find((t) => t.id === id) ?? null;
};

export const fetchAllTickets = async (): Promise<TicketMapping[]> => {
  if (!USE_MOCK) return apiClient.get<TicketMapping[]>('/dashboard/tickets');
  await delay(350);
  return ALL_TICKETS;
};

export const fetchCasesWorked = async (): Promise<CaseWorked[]> => {
  if (!USE_MOCK) return apiClient.get<CaseWorked[]>('/dashboard/cases-worked');
  await delay(300);
  return MOCK_CASES_WORKED;
};

export const fetchAvailableAgents = async (): Promise<AvailableAgent[]> => {
  if (!USE_MOCK) {
    try {
      const result = await apiClient.get<AvailableAgent[]>('/agents/available?limit=5');
      if (result && result.length > 0) return result;
    } catch { /* fall through to static data */ }
    return (availableAgentsJson as AvailableAgent[]).slice(0, 5);
  }
  await delay(400);
  return AVAILABLE_AGENTS.slice(0, 5);
};

export const fetchAllAvailableAgents = async (): Promise<AvailableAgent[]> => {
  if (!USE_MOCK) {
    try {
      const result = await apiClient.get<AvailableAgent[]>('/agents/available');
      if (result && result.length > 0) return result;
    } catch { /* fall through to static data */ }
    return availableAgentsJson as AvailableAgent[];
  }
  await delay(350);
  return [...AVAILABLE_AGENTS];
};

export const addAvailableAgent = async (name: string): Promise<AvailableAgent> => {
  if (!USE_MOCK) return apiClient.post<AvailableAgent>('/agents/available', { name });
  await delay(600);
  const agent: AvailableAgent = { id: String(_nextAgentId++), name };
  AVAILABLE_AGENTS.push(agent);
  return agent;
};

export const fetchIncidents = async (): Promise<Incident[]> => {
  if (!USE_MOCK) return apiClient.get<Incident[]>('/dashboard/incidents');
  await delay(350);
  return MOCK_INCIDENTS;
};

export const fetchAllDashboardData = async (): Promise<DashboardData> => {
  const [metrics, agentRuns, ticketMappings, casesWorked, availableAgents, incidents] =
    await Promise.all([
      fetchMetrics(),
      fetchAgentRuns(),
      fetchTicketMappings(),
      fetchCasesWorked(),
      fetchAvailableAgents(),
      fetchIncidents(),
    ]);
  return { metrics, agentRuns, ticketMappings, casesWorked, availableAgents, incidents };
};
