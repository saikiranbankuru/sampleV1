export const DEFAULT_WARNINGS_LOKI_QUERY =
  '{service_name="$agents"} | json | label_format level=detected_level | (case_number="$ticket" or record="$ticket") | level = `warn`';

export const DEFAULT_WARNINGS_PROMETHEUS_QUERY = '{service_name="$agents"}';

let _lokiQuery = DEFAULT_WARNINGS_LOKI_QUERY;
let _prometheusQuery = DEFAULT_WARNINGS_PROMETHEUS_QUERY;

export const getWarningsLokiQuery = () => _lokiQuery;
export const getWarningsPrometheusQuery = () => _prometheusQuery;
export const setWarningsLokiQuery = (q: string) => { _lokiQuery = q; };
export const setWarningsPrometheusQuery = (q: string) => { _prometheusQuery = q; };

export function buildWarningsQuery(
  template: string,
  agentName: string,
  ticketNumber?: string,
): string {
  return template
    .replace(/\$agents/g, agentName)
    .replace(/\$ticket/g, ticketNumber ?? '');
}
