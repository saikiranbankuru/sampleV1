import { ThemeProvider } from '@/contexts/ThemeContext';
import { TimeRangeProvider } from '@/contexts/TimeRangeContext';
import AppRouter from '@/routes';

export default function App() {
  return (
    <ThemeProvider>
      <TimeRangeProvider>
        <AppRouter />
      </TimeRangeProvider>
    </ThemeProvider>
  );
}
