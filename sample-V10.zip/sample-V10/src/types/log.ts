// Labels indexed by Loki — usable in LogQL selectors
export interface LokiStreamLabels {
  agent?: string;
  case_number?: string;
  detected_level?: string;
  level?: string;
  service_name?: string;
}

// A single raw log line inside a stream
export interface LokiRawLog {
  timestamp_ns: string;
  log: string; // JSON-encoded string
}

// One Loki stream = unique label combination + its log lines
export interface LokiStream {
  stream_labels: LokiStreamLabels;
  logs: LokiRawLog[];
}

// The data envelope returned by /api/logs/query
export interface LokiQueryData {
  query: string;
  total_streams: number;
  total_logs: number;
  streams: LokiStream[];
}

// Top-level response from the backend API
export interface LokiQueryResponse {
  success: boolean;
  message: string;
  data: LokiQueryData;
}
