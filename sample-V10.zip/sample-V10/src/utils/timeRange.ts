const PRESET_SECONDS: Record<string, number> = {
  'Last 5 Minutes':  300,
  'Last 15 Minutes': 900,
  'Last 30 Minutes': 1800,
  'Last 1 Hour':     3600,
  'Last 3 Hours':    10800,
  'Last 6 Hours':    21600,
  'Last 12 Hours':   43200,
  'Last 24 Hours':   86400,
  'Last 7 Days':     604800,
  'Last 30 Days':    2592000,
};

/** Convert a TimeRangePicker preset string to a lookback window in seconds. */
export function presetToSeconds(preset: string): number {
  return PRESET_SECONDS[preset] ?? 3600;
}
