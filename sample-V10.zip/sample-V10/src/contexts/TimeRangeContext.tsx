import { createContext, useContext, useState, useMemo } from 'react';
import type { ReactNode } from 'react';
import type { TimeRangeValue } from '@/components/common/TimeRangePicker';

/* ─── types ───────────────────────────────────────────────── */
export interface TimeRangeContextValue {
  timeRange: TimeRangeValue;
  timezone: string;
  lookbackSeconds: number;
  displayLabel: string;
  setTimeRange: (range: TimeRangeValue) => void;
  setTimezone: (tz: string) => void;
}

/* ─── helpers ─────────────────────────────────────────────── */
function computeLookback(range: TimeRangeValue): number {
  if (range.preset) {
    const m = range.preset.match(/Last\s+(\d+)\s+(Minute|Hour|Day|Month|Year)/i);
    if (m) {
      const n    = parseInt(m[1], 10);
      const unit = m[2].toLowerCase();
      if (unit === 'minute') return n * 60;
      if (unit === 'hour')   return n * 3600;
      if (unit === 'day')    return n * 86400;
      if (unit === 'month')  return n * 30 * 86400;
      if (unit === 'year')   return n * 365 * 86400;
    }
  }
  const from = new Date(range.from).getTime();
  const to   = new Date(range.to).getTime();
  if (!isNaN(from) && !isNaN(to) && to > from) {
    return Math.floor((to - from) / 1000);
  }
  return 300;
}

function makeDefaultRange(): TimeRangeValue {
  const now  = new Date();
  const from = new Date(now);
  from.setMinutes(from.getMinutes() - 5);
  const p   = (n: number) => String(n).padStart(2, '0');
  const fmt = (d: Date) =>
    `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}T${p(d.getHours())}:${p(d.getMinutes())}`;
  return { preset: 'Last 5 Minutes', from: fmt(from), to: fmt(now) };
}

/* ─── context ─────────────────────────────────────────────── */
const TimeRangeContext = createContext<TimeRangeContextValue | null>(null);

export function TimeRangeProvider({ children }: { children: ReactNode }) {
  const [timeRange, setTimeRange] = useState<TimeRangeValue>(makeDefaultRange);
  const [timezone,  setTimezone]  = useState('Asia/Kolkata');

  const lookbackSeconds = useMemo(() => computeLookback(timeRange), [timeRange]);
  const displayLabel    = timeRange.preset ?? 'Custom Range';

  return (
    <TimeRangeContext.Provider value={{ timeRange, timezone, lookbackSeconds, displayLabel, setTimeRange, setTimezone }}>
      {children}
    </TimeRangeContext.Provider>
  );
}

export function useTimeRange(): TimeRangeContextValue {
  const ctx = useContext(TimeRangeContext);
  if (!ctx) throw new Error('useTimeRange must be used within TimeRangeProvider');
  return ctx;
}
