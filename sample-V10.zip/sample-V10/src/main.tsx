import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import 'bootstrap/dist/css/bootstrap.min.css';
import '@/styles/global.css';
import App from './App';

async function enableMocking(): Promise<void> {
  if (import.meta.env.VITE_USE_MOCK !== 'true') {
    if ('serviceWorker' in navigator) {
      const regs = await navigator.serviceWorker.getRegistrations();
      if (regs.length > 0) {
        // Unregister takes effect only on the next load, so reload once after clearing.
        // sessionStorage guards against an infinite reload loop.
        await Promise.all(regs.map(r => r.unregister()));
        if (!sessionStorage.getItem('msw-cleared')) {
          sessionStorage.setItem('msw-cleared', '1');
          console.log('[mock] old service worker removed — reloading to apply changes');
          window.location.reload();
          return; // page is reloading — stop here
        }
      }
      sessionStorage.removeItem('msw-cleared');
    }
    console.log('[mock] VITE_USE_MOCK=false — calling real API');
    return;
  }
  sessionStorage.removeItem('msw-cleared');
  console.log('[mock] VITE_USE_MOCK=true — MSW intercepting all requests');
  const { worker } = await import('./mocks/browser');
  await worker.start({ onUnhandledRequest: 'bypass' });
}

enableMocking().then(() => {
  createRoot(document.getElementById('root')!).render(
    <StrictMode>
      <App />
    </StrictMode>,
  );
});
