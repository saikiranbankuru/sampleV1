import { useEffect, useRef, useState, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { ChevronDown, Check, ArrowLeft } from 'lucide-react';
import { TimeRangePicker } from '../../components/common/TimeRangePicker';
import { DataTable, type TableColumn } from '../../components/common/DataTable';
import { LokiQueryAccordion } from '../../components/dashboard/LokiQueryAccordion';
import { fetchLokiDashboardData } from '../../services/logService';
import { presetToSeconds } from '../../utils/timeRange';
import {
  getCasesLokiQuery,
  getCasesPrometheusQuery,
  setCasesLokiQuery,
  setCasesPrometheusQuery,
} from '../../services/casesWorkedQueryStore';
import type { CaseWorked } from '../../types/dashboard';
import '../home/TicketAgentMappingEditPage.css';

const COLUMNS: TableColumn<CaseWorked>[] = [
  { key: 'agentName', label: 'Agent Name', render: row => row.agentName },
  { key: 'count',     label: 'Cases',      render: row => String(row.count).padStart(2, '0') },
];

type Datasource = 'Loki' | 'Prometheus';

interface QueryItem {
  id: string;
  name: string;
  datasource: Datasource;
  query: string;
}

function getDefaultQuery(ds: Datasource): string {
  return ds === 'Loki' ? getCasesLokiQuery() : getCasesPrometheusQuery();
}

export default function CasesWorkedEditPage() {
  const navigate = useNavigate();
  const [timeRange, setTimeRange] = useState('Last 5 Minutes');
  const [activeTab, setActiveTab] = useState<'queries' | 'transformations'>('queries');

  const [datasource, setDatasource] = useState<Datasource>('Loki');
  const [dsOpen, setDsOpen] = useState(false);

  const [queries, setQueries] = useState<QueryItem[]>([
    { id: 'q1', name: 'A', datasource: 'Loki', query: getCasesLokiQuery() },
  ]);
  const queryIdRef = useRef(1);

  const [cases, setCases] = useState<CaseWorked[]>([]);
  const [tableLoading, setTableLoading] = useState(true);

  const [runLoading, setRunLoading] = useState(false);
  const [runError, setRunError] = useState<string | null>(null);
  const [savedFlash, setSavedFlash] = useState(false);

  useEffect(() => {
    setTableLoading(true);
    fetchLokiDashboardData(presetToSeconds(timeRange), { logql: getCasesLokiQuery() })
      .then(d => setCases(d.casesWorked))
      .finally(() => setTableLoading(false));
  }, [timeRange]);

  const handleDatasourceChange = useCallback((ds: Datasource) => {
    setDatasource(ds);
    setDsOpen(false);
    setQueries(prev =>
      prev.map(q => ({ ...q, datasource: ds, query: getDefaultQuery(ds) }))
    );
    setRunError(null);
  }, []);

  const handleQueryChange = (id: string, query: string) => {
    setQueries(prev => prev.map(q => q.id === id ? { ...q, query } : q));
  };

  const handleRunQuery = async (_id: string, query: string) => {
    setRunLoading(true);
    setRunError(null);
    try {
      const result = await fetchLokiDashboardData(presetToSeconds(timeRange), { logql: query });
      setCases(result.casesWorked);
    } catch (err) {
      setRunError(err instanceof Error ? err.message : 'Query execution failed');
    } finally {
      setRunLoading(false);
    }
  };

  const handleSave = () => {
    queries.forEach(q => {
      if (q.datasource === 'Loki') setCasesLokiQuery(q.query);
      else setCasesPrometheusQuery(q.query);
    });
    setSavedFlash(true);
    setTimeout(() => setSavedFlash(false), 2000);
  };

  const renameQuery = (id: string, newName: string) => {
    setQueries(prev => prev.map(q => q.id === id ? { ...q, name: newName } : q));
  };

  const addQuery = () => {
    setQueries(prev => {
      queryIdRef.current += 1;
      const name = String.fromCharCode(65 + prev.length);
      return [
        ...prev,
        { id: `q${queryIdRef.current}`, name, datasource, query: getDefaultQuery(datasource) },
      ];
    });
  };

  const duplicateQuery = (id: string) => {
    setQueries(prev => {
      const source = prev.find(q => q.id === id);
      if (!source) return prev;
      queryIdRef.current += 1;
      const name = String.fromCharCode(65 + prev.length);
      return [...prev, { id: `q${queryIdRef.current}`, name, datasource: source.datasource, query: source.query }];
    });
  };

  const deleteQuery = (id: string) => {
    setQueries(prev => prev.filter(q => q.id !== id));
  };

  return (
    <div className="tame-page">
      {/* Header */}
      <div className="tame-header">
        <nav className="tame-breadcrumb" aria-label="breadcrumb">
          <button className="tame-breadcrumb-link" onClick={() => navigate('/home')}>
            Home
          </button>
          <span className="tame-breadcrumb-sep">&rsaquo;</span>
          <button className="tame-breadcrumb-link" onClick={() => navigate('/home')}>
            Dashboard
          </button>
          <span className="tame-breadcrumb-sep">&rsaquo;</span>
          <span className="tame-breadcrumb-current">Edit Number of Cases Worked</span>
        </nav>

        <div className="tame-controls">
          <TimeRangePicker
            value={timeRange}
            onApply={r => setTimeRange(r.preset ?? 'Custom Range')}
          />
          <button className="tame-back-btn" onClick={() => navigate('/home')}>
            <ArrowLeft size={14} />
            Back
          </button>
        </div>
      </div>

      {/* Section 1: Cases Worked table */}
      <div className="tame-section">
        <h2 className="tame-section-title">Number of Cases Worked</h2>
        {tableLoading ? (
          <div className="tame-table-skeleton" />
        ) : (
          <DataTable columns={COLUMNS} data={cases} pageSize={8} emptyText="No cases found." />
        )}
      </div>

      {/* Section 2: Query editor panel */}
      <div className="tame-section">
        <div className="tame-tabs-header" role="tablist">
          <button
            role="tab"
            aria-selected={activeTab === 'queries'}
            className={`tame-tab${activeTab === 'queries' ? ' tame-tab--active' : ''}`}
            onClick={() => setActiveTab('queries')}
          >
            Queries
            <span className="tame-tab-badge">{queries.length}</span>
          </button>
          <button
            role="tab"
            aria-selected={activeTab === 'transformations'}
            className={`tame-tab${activeTab === 'transformations' ? ' tame-tab--active' : ''}`}
            onClick={() => setActiveTab('transformations')}
          >
            Transformations
            <span className="tame-tab-badge tame-tab-badge--neutral">5</span>
          </button>
        </div>

        <div className="tame-tab-content" role="tabpanel">
          {activeTab === 'queries' ? (
            <div className="tame-queries-tab">
              {/* Datasource selector */}
              <div className="tame-ds-row">
                <div className="tame-ds-dropdown" onBlur={() => setDsOpen(false)}>
                  <button
                    className="tame-ds-btn"
                    onClick={() => setDsOpen(v => !v)}
                    aria-haspopup="listbox"
                    aria-expanded={dsOpen}
                    aria-label="Select datasource"
                  >
                    {datasource}
                    <ChevronDown size={13} className={`tame-ds-chevron${dsOpen ? ' tame-ds-chevron--open' : ''}`} />
                  </button>
                  {dsOpen && (
                    <ul className="tame-ds-menu" role="listbox">
                      {(['Loki', 'Prometheus'] as Datasource[]).map(ds => (
                        <li
                          key={ds}
                          role="option"
                          aria-selected={datasource === ds}
                          className={`tame-ds-option${datasource === ds ? ' tame-ds-option--active' : ''}`}
                          onMouseDown={() => handleDatasourceChange(ds)}
                        >
                          {datasource === ds && <Check size={12} className="tame-ds-check" />}
                          {ds}
                        </li>
                      ))}
                    </ul>
                  )}
                </div>
              </div>

              {/* Query accordions */}
              <div className="tame-query-list">
                {queries.map(q => (
                  <LokiQueryAccordion
                    key={q.id}
                    id={q.id}
                    name={q.name}
                    datasource={q.datasource}
                    initialQuery={q.query}
                    onRename={renameQuery}
                    onDuplicate={duplicateQuery}
                    onDelete={deleteQuery}
                    onQueryChange={handleQueryChange}
                    onRun={handleRunQuery}
                    runLoading={runLoading}
                    runError={runError}
                  />
                ))}
              </div>

              {/* Actions row */}
              <div className="tame-query-actions">
                <button className="tame-action-btn" onClick={addQuery}>
                  Add Query
                </button>
                <button className="tame-action-btn">Expression</button>

                <div className="tame-query-actions-right">
                  <button
                    className={`tame-save-btn${savedFlash ? ' tame-save-btn--saved' : ''}`}
                    onClick={handleSave}
                  >
                    {savedFlash ? 'Saved!' : 'Apply & Save'}
                  </button>
                </div>
              </div>
            </div>
          ) : (
            <div className="tame-transformations-tab" aria-label="Transformations — coming soon" />
          )}
        </div>
      </div>
    </div>
  );
}
