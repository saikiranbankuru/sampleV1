import { useEffect, useState, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { ChevronLeft } from 'lucide-react';
import { RefreshControls } from '../../components/common/RefreshControls';
import { TimeRangePicker } from '../../components/common/TimeRangePicker';
import { DataTable, type TableColumn } from '../../components/common/DataTable';
import { PanelMenu, type PanelMenuItem } from '../../components/common/PanelMenu';
import { useTimeRange } from '../../contexts/TimeRangeContext';
import { fetchLokiDashboardData } from '../../services/logService';
import { getCasesLokiQuery } from '../../services/casesWorkedQueryStore';
import type { CaseWorked } from '../../types/dashboard';
import '../tickets/TicketListPage.css';

const COLUMNS: TableColumn<CaseWorked>[] = [
  {
    key: 'count',
    label: 'Count',
    render: row => (
      <span className="cw-count-badge">{String(row.count).padStart(2, '0')}</span>
    ),
  },
  {
    key: 'agentName',
    label: 'Agent Name',
    clickable: true,
    render: row => row.agentName,
  },
];

const PAGE_SIZE = 10;

export default function CasesWorkedPage() {
  const navigate = useNavigate();
  const { displayLabel, lookbackSeconds, setTimeRange, timezone, setTimezone } = useTimeRange();
  const [cases, setCases] = useState<CaseWorked[]>([]);
  const [loading, setLoading] = useState(true);
  const [spinning, setSpinning] = useState(false);

  const CASES_MENU: PanelMenuItem[] = [
    { id: 'view',    label: 'View',    onAction: () => navigate('/cases-worked') },
    { id: 'edit',    label: 'Edit',    onAction: () => navigate('/number-of-cases-worked/edit') },
    {
      id: 'share', label: 'Share',
      children: [
        { id: 'share-link',     label: 'Share link',     onAction: () => {} },
        { id: 'share-embed',    label: 'Share embed',    onAction: () => {} },
        { id: 'share-snapshot', label: 'Share snapshot', onAction: () => {} },
      ],
    },
    { id: 'explore', label: 'Explore', onAction: () => {} },
    {
      id: 'inspect', label: 'Inspect',
      children: [
        { id: 'inspect-data',  label: 'Data',      onAction: () => {} },
        { id: 'inspect-query', label: 'Query',      onAction: () => {} },
        { id: 'inspect-json',  label: 'Panel JSON', onAction: () => {} },
      ],
    },
    {
      id: 'more', label: 'More',
      children: [
        { id: 'more-copy',  label: 'Copy',           onAction: () => {} },
        { id: 'more-alert', label: 'New alert rule', onAction: () => {} },
        { id: 'more-help',  label: 'Get help',       onAction: () => {} },
      ],
    },
  ];

  const load = useCallback(async () => {
    setSpinning(true);
    try {
      const { casesWorked } = await fetchLokiDashboardData(lookbackSeconds, { logql: getCasesLokiQuery() });
      setCases(casesWorked);
    } finally {
      setLoading(false);
      setSpinning(false);
    }
  }, [lookbackSeconds]);

  useEffect(() => { load(); }, [load]);

  return (
    <div className="tl-page">
      <div className="tl-header">
        <div className="tl-breadcrumb">
          <span className="tl-breadcrumb-link" onClick={() => navigate('/home')}>Home</span>
          <span className="tl-breadcrumb-sep">&rsaquo;</span>
          <span className="tl-breadcrumb-current">Number of Cases Worked</span>
        </div>

        <div className="tl-actions">
          <button className="tl-back-btn" onClick={() => navigate('/home')}>
            <ChevronLeft size={14} />
            Back
          </button>
          <RefreshControls onRefresh={load} spinning={spinning} />
          <TimeRangePicker
            value={displayLabel}
            onApply={setTimeRange}
            timezone={timezone}
            onTimezoneChange={setTimezone}
          />
        </div>
      </div>

      <div className="tl-title-row">
        <h1 className="tl-title">Number of Cases Worked</h1>
        <span className="tl-count">
          {loading ? '—' : `${cases.length} case${cases.length === 1 ? '' : 's'}`}
        </span>
      </div>

      <div className="tl-card">
        <div className="tl-filter-row">
          <div className="tl-search-wrap">
            <svg className="tl-search-icon" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <circle cx="11" cy="11" r="8" /><line x1="21" y1="21" x2="16.65" y2="16.65" />
            </svg>
            <span className="tl-search-placeholder">Search cases…</span>
          </div>
          <div style={{ marginLeft: 'auto' }}>
            <PanelMenu items={CASES_MENU} />
          </div>
        </div>

        {loading ? (
          <div className="tl-skeleton-wrap">
            {[...Array(PAGE_SIZE)].map((_, i) => (
              <div key={i} className="tl-skeleton-row" />
            ))}
          </div>
        ) : (
          <DataTable
            columns={COLUMNS}
            data={cases}
            pageSize={PAGE_SIZE}
            emptyText="No cases found."
          />
        )}
      </div>
    </div>
  );
}
