import { useEffect, useRef, useState, useCallback, useMemo } from 'react';
import { useNavigate, useParams, useLocation } from 'react-router-dom';
import { ChevronDown, Check, ArrowLeft } from 'lucide-react';
import { TimeRangePicker } from '../../components/common/TimeRangePicker';
import { LokiQueryAccordion } from '../../components/dashboard/LokiQueryAccordion';
import CircularGauge from '../../components/dashboard/CircularGauge';
import type { PanelMenuItem } from '../../components/common/PanelMenu';
import { DEFAULT_PANEL_MENU } from '../../config/panelMenus';
import {
  getErrorsLokiQuery,
  getErrorsPrometheusQuery,
  setErrorsLokiQuery,
  setErrorsPrometheusQuery,
  buildErrorsQuery,
} from '../../services/errorsQueryStore';
import {
  executePrometheusQuery,
  executeLokiQuery,
} from '../../services/prometheusService';
import { presetToSeconds } from '../../utils/timeRange';
import './NumberOfErrorsEditPage.css';

type Datasource = 'Loki' | 'Prometheus';

interface QueryItem {
  id: string;
  name: string;
  datasource: Datasource;
  query: string;
}

function getDefaultQuery(ds: Datasource): string {
  return ds === 'Loki' ? getErrorsLokiQuery() : getErrorsPrometheusQuery();
}

export default function NumberOfErrorsEditPage() {
  const navigate   = useNavigate();
  const location   = useLocation();
  const { agentName: rawAgentName = '' } = useParams<{ agentName: string }>();
  const agentName    = decodeURIComponent(rawAgentName);
  const ticketNumber = new URLSearchParams(location.search).get('ticket') ?? '';

  const [timeRange, setTimeRange] = useState('Last 5 Minutes');
  const [activeTab, setActiveTab] = useState<'queries' | 'transformations'>('queries');

  const [datasource, setDatasource] = useState<Datasource>('Loki');
  const [dsOpen, setDsOpen]         = useState(false);

  const [queries, setQueries] = useState<QueryItem[]>([
    { id: 'q1', name: 'A', datasource: 'Loki', query: getErrorsLokiQuery() },
  ]);
  const queryIdRef = useRef(1);

  const [errorsCount, setErrorsCount]   = useState<number | null>(null);
  const [widgetLoading, setWidgetLoading] = useState(true);
  const [runLoading, setRunLoading]       = useState(false);
  const [runError, setRunError]           = useState<string | null>(null);
  const [savedFlash, setSavedFlash]       = useState(false);

  useEffect(() => {
    setWidgetLoading(true);
    const resolved = buildErrorsQuery(getErrorsLokiQuery(), agentName, ticketNumber || undefined);
    executeLokiQuery(resolved, presetToSeconds(timeRange))
      .then(v => setErrorsCount(v))
      .finally(() => setWidgetLoading(false));
  }, [agentName, ticketNumber, timeRange]);

  const handleDatasourceChange = useCallback((ds: Datasource) => {
    setDatasource(ds);
    setDsOpen(false);
    setQueries(prev => prev.map(q => ({ ...q, datasource: ds, query: getDefaultQuery(ds) })));
    setRunError(null);
  }, []);

  const handleQueryChange = (id: string, query: string) => {
    setQueries(prev => prev.map(q => q.id === id ? { ...q, query } : q));
  };

  const handleRunQuery = async (_id: string, query: string, ds: string) => {
    setRunLoading(true);
    setRunError(null);
    try {
      const resolved = buildErrorsQuery(query, agentName, ticketNumber || undefined);
      const value = ds === 'Prometheus'
        ? await executePrometheusQuery(resolved, true)
        : await executeLokiQuery(resolved, presetToSeconds(timeRange), true);
      setErrorsCount(Math.round(value));
    } catch (err) {
      setRunError(err instanceof Error ? err.message : 'Query execution failed');
    } finally {
      setRunLoading(false);
    }
  };

  const handleSave = () => {
    queries.forEach(q => {
      if (q.datasource === 'Loki') setErrorsLokiQuery(q.query);
      else setErrorsPrometheusQuery(q.query);
    });
    setSavedFlash(true);
    setTimeout(() => setSavedFlash(false), 2000);
  };

  const renameQuery = (id: string, newName: string) => {
    setQueries(prev => prev.map(q => q.id === id ? { ...q, name: newName } : q));
  };

  const addQuery = () => {
    setQueries(prev => {
      queryIdRef.current += 1;
      const name = String.fromCharCode(65 + prev.length);
      return [...prev, { id: `q${queryIdRef.current}`, name, datasource, query: getDefaultQuery(datasource) }];
    });
  };

  const duplicateQuery = (id: string) => {
    setQueries(prev => {
      const source = prev.find(q => q.id === id);
      if (!source) return prev;
      queryIdRef.current += 1;
      const name = String.fromCharCode(65 + prev.length);
      return [...prev, { id: `q${queryIdRef.current}`, name, datasource: source.datasource, query: source.query }];
    });
  };

  const deleteQuery = (id: string) => {
    setQueries(prev => prev.filter(q => q.id !== id));
  };

  const widgetMenuItems = useMemo<PanelMenuItem[]>(() =>
    DEFAULT_PANEL_MENU.map(item =>
      item.id === 'edit' ? { ...item, onAction: () => {} } : item,
    ),
  []);

  return (
    <div className="noe-page">
      {/* ── Header ── */}
      <div className="noe-header">
        <nav className="noe-breadcrumb" aria-label="breadcrumb">
          <button className="noe-breadcrumb-link" onClick={() => navigate('/home')}>Home</button>
          <span className="noe-breadcrumb-sep">&rsaquo;</span>
          <button className="noe-breadcrumb-link" onClick={() => navigate('/home')}>Dashboard</button>
          <span className="noe-breadcrumb-sep">&rsaquo;</span>
          {agentName && (
            <>
              <button
                className="noe-breadcrumb-link"
                onClick={() => navigate(`/agents/${encodeURIComponent(agentName)}`)}
              >
                {agentName}
              </button>
              <span className="noe-breadcrumb-sep">&rsaquo;</span>
            </>
          )}
          <span className="noe-breadcrumb-current">Edit Number Of Errors</span>
        </nav>

        <div className="noe-controls">
          <TimeRangePicker
            value={timeRange}
            onApply={r => setTimeRange(r.preset ?? 'Custom Range')}
          />
          <button className="noe-back-btn" onClick={() => navigate(-1)}>
            <ArrowLeft size={14} />
            Back
          </button>
        </div>
      </div>

      {/* ── Widget preview ── */}
      <div className="noe-widget-row">
        <div className="noe-gauge-card">
          <div className="noe-gauge-card-header">
            <div>
              <p className="noe-gauge-label">Number</p>
              <p className="noe-gauge-sublabel">Of Errors</p>
            </div>
            <div className="noe-gauge-menu-placeholder" />
          </div>
          <div className="noe-gauge-center">
            {widgetLoading ? (
              <div className="noe-gauge-skeleton" />
            ) : (
              <CircularGauge
                value={errorsCount ?? 0}
                max={10}
                color="#F59E0B"
                size={88}
                strokeWidth={9}
                variant="semi"
                valueSize={20}
              />
            )}
          </div>
        </div>
      </div>

      {/* ── Query editor ── */}
      <div className="noe-section">
        <div className="noe-tabs-header" role="tablist">
          <button
            role="tab"
            aria-selected={activeTab === 'queries'}
            className={`noe-tab${activeTab === 'queries' ? ' noe-tab--active' : ''}`}
            onClick={() => setActiveTab('queries')}
          >
            Queries
            <span className="noe-tab-badge">{queries.length}</span>
          </button>
          <button
            role="tab"
            aria-selected={activeTab === 'transformations'}
            className={`noe-tab${activeTab === 'transformations' ? ' noe-tab--active' : ''}`}
            onClick={() => setActiveTab('transformations')}
          >
            Transformations
            <span className="noe-tab-badge noe-tab-badge--neutral">5</span>
          </button>
        </div>

        <div className="noe-tab-content" role="tabpanel">
          {activeTab === 'queries' ? (
            <div className="noe-queries-tab">
              {/* Datasource selector */}
              <div className="noe-ds-row">
                <div className="noe-ds-dropdown" onBlur={() => setDsOpen(false)}>
                  <button
                    className="noe-ds-btn"
                    onClick={() => setDsOpen(v => !v)}
                    aria-haspopup="listbox"
                    aria-expanded={dsOpen}
                    aria-label="Select datasource"
                  >
                    {datasource}
                    <ChevronDown
                      size={13}
                      className={`noe-ds-chevron${dsOpen ? ' noe-ds-chevron--open' : ''}`}
                    />
                  </button>
                  {dsOpen && (
                    <ul className="noe-ds-menu" role="listbox">
                      {(['Loki', 'Prometheus'] as Datasource[]).map(ds => (
                        <li
                          key={ds}
                          role="option"
                          aria-selected={datasource === ds}
                          className={`noe-ds-option${datasource === ds ? ' noe-ds-option--active' : ''}`}
                          onMouseDown={() => handleDatasourceChange(ds)}
                        >
                          {datasource === ds && <Check size={12} className="noe-ds-check" />}
                          {ds}
                        </li>
                      ))}
                    </ul>
                  )}
                </div>
              </div>

              {/* Query accordions */}
              <div className="noe-query-list">
                {queries.map(q => (
                  <LokiQueryAccordion
                    key={q.id}
                    id={q.id}
                    name={q.name}
                    datasource={q.datasource}
                    initialQuery={q.query}
                    onRename={renameQuery}
                    onDuplicate={duplicateQuery}
                    onDelete={deleteQuery}
                    onQueryChange={handleQueryChange}
                    onRun={handleRunQuery}
                    runLoading={runLoading}
                    runError={runError}
                  />
                ))}
              </div>

              {/* Action row */}
              <div className="noe-query-actions">
                <button className="noe-action-btn" onClick={addQuery}>Add Query</button>
                <button className="noe-action-btn">Expression</button>
                <div className="noe-query-actions-right">
                  <button
                    className={`noe-save-btn${savedFlash ? ' noe-save-btn--saved' : ''}`}
                    onClick={handleSave}
                  >
                    {savedFlash ? 'Saved!' : 'Apply & Save'}
                  </button>
                </div>
              </div>
            </div>
          ) : (
            <div className="noe-transformations-tab" aria-label="Transformations — coming soon" />
          )}
        </div>
      </div>
    </div>
  );
}
