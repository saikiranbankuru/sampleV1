import { useEffect, useRef, useState, useCallback } from 'react';
import { useNavigate, useParams, useLocation } from 'react-router-dom';
import { ChevronDown, Check, ArrowLeft } from 'lucide-react';
import { TimeRangePicker } from '../../components/common/TimeRangePicker';
import { LokiQueryAccordion } from '../../components/dashboard/LokiQueryAccordion';
import {
  getAccuracyScoreLokiQuery,
  getAccuracyScorePrometheusQuery,
  setAccuracyScoreLokiQuery,
  setAccuracyScorePrometheusQuery,
  buildAccuracyScoreQuery,
} from '../../services/accuracyScoreQueryStore';
import {
  executePrometheusQuery,
  executeLokiQuery,
} from '../../services/prometheusService';
import { presetToSeconds } from '../../utils/timeRange';
import './AccuracyScoreEditPage.css';

type Datasource = 'Loki' | 'Prometheus';

interface QueryItem {
  id: string;
  name: string;
  datasource: Datasource;
  query: string;
}

function getDefaultQuery(ds: Datasource): string {
  return ds === 'Loki' ? getAccuracyScoreLokiQuery() : getAccuracyScorePrometheusQuery();
}

export default function AccuracyScoreEditPage() {
  const navigate = useNavigate();
  const location = useLocation();
  const { agentName: rawAgentName = '' } = useParams<{ agentName: string }>();
  const agentName = decodeURIComponent(rawAgentName);
  const ticketNumber = new URLSearchParams(location.search).get('ticket') ?? '';

  const [timeRange, setTimeRange] = useState('Last 5 Minutes');
  const [activeTab, setActiveTab] = useState<'queries' | 'transformations'>('queries');
  const [datasource, setDatasource] = useState<Datasource>('Prometheus');
  const [dsOpen, setDsOpen] = useState(false);

  const [queries, setQueries] = useState<QueryItem[]>([
    { id: 'q1', name: 'A', datasource: 'Prometheus', query: getAccuracyScorePrometheusQuery() },
  ]);
  const queryIdRef = useRef(1);

  const [metricValue, setMetricValue] = useState<number | null>(null);
  const [widgetLoading, setWidgetLoading] = useState(true);
  const [runLoading, setRunLoading] = useState(false);
  const [runError, setRunError] = useState<string | null>(null);
  const [savedFlash, setSavedFlash] = useState(false);

  useEffect(() => {
    setWidgetLoading(true);
    const resolved = buildAccuracyScoreQuery(
      getAccuracyScorePrometheusQuery(),
      agentName,
      ticketNumber || undefined,
    );
    executePrometheusQuery(resolved)
      .then(v => setMetricValue(Math.round(v)))
      .finally(() => setWidgetLoading(false));
  }, [agentName, ticketNumber]);

  const handleDatasourceChange = useCallback((ds: Datasource) => {
    setDatasource(ds);
    setDsOpen(false);
    setQueries(prev => prev.map(q => ({ ...q, datasource: ds, query: getDefaultQuery(ds) })));
    setRunError(null);
  }, []);

  const handleQueryChange = (id: string, query: string) => {
    setQueries(prev => prev.map(q => q.id === id ? { ...q, query } : q));
  };

  const handleRunQuery = async (_id: string, query: string, ds: string) => {
    setRunLoading(true);
    setRunError(null);
    try {
      const resolved = buildAccuracyScoreQuery(query, agentName, ticketNumber || undefined);
      const value = ds === 'Prometheus'
        ? await executePrometheusQuery(resolved, true)
        : await executeLokiQuery(resolved, presetToSeconds(timeRange), true);
      setMetricValue(Math.round(value));
    } catch (err) {
      setRunError(err instanceof Error ? err.message : 'Query execution failed');
    } finally {
      setRunLoading(false);
    }
  };

  const handleSave = () => {
    queries.forEach(q => {
      if (q.datasource === 'Loki') setAccuracyScoreLokiQuery(q.query);
      else setAccuracyScorePrometheusQuery(q.query);
    });
    setSavedFlash(true);
    setTimeout(() => setSavedFlash(false), 2000);
  };

  const renameQuery = (id: string, newName: string) => {
    setQueries(prev => prev.map(q => q.id === id ? { ...q, name: newName } : q));
  };

  const addQuery = () => {
    setQueries(prev => {
      queryIdRef.current += 1;
      const name = String.fromCharCode(65 + prev.length);
      return [...prev, { id: `q${queryIdRef.current}`, name, datasource, query: getDefaultQuery(datasource) }];
    });
  };

  const duplicateQuery = (id: string) => {
    setQueries(prev => {
      const source = prev.find(q => q.id === id);
      if (!source) return prev;
      queryIdRef.current += 1;
      const name = String.fromCharCode(65 + prev.length);
      return [...prev, { id: `q${queryIdRef.current}`, name, datasource: source.datasource, query: source.query }];
    });
  };

  const deleteQuery = (id: string) => {
    setQueries(prev => prev.filter(q => q.id !== id));
  };

  const displayValue = metricValue ?? 0;

  return (
    <div className="ase-page">
      {/* ── Header ── */}
      <div className="ase-header">
        <nav className="ase-breadcrumb" aria-label="breadcrumb">
          <button className="ase-breadcrumb-link" onClick={() => navigate('/home')}>Home</button>
          <span className="ase-breadcrumb-sep">&rsaquo;</span>
          <button className="ase-breadcrumb-link" onClick={() => navigate('/home')}>Dashboard</button>
          <span className="ase-breadcrumb-sep">&rsaquo;</span>
          {agentName && (
            <>
              <button
                className="ase-breadcrumb-link"
                onClick={() => navigate(`/agents/${encodeURIComponent(agentName)}`)}
              >
                {agentName}
              </button>
              <span className="ase-breadcrumb-sep">&rsaquo;</span>
            </>
          )}
          <span className="ase-breadcrumb-current">Edit Accuracy Score</span>
        </nav>

        <div className="ase-controls">
          <TimeRangePicker
            value={timeRange}
            onApply={r => setTimeRange(r.preset ?? 'Custom Range')}
          />
          <button className="ase-back-btn" onClick={() => navigate(-1)}>
            <ArrowLeft size={14} />
            Back
          </button>
        </div>
      </div>

      {/* ── Widget preview ── */}
      <div className="ase-widget-row">
        <div className="ase-badge-card">
          {widgetLoading ? (
            <div className="ase-badge-skeleton" />
          ) : (
            <div className="ase-badge-row">
              <span className="ase-badge-num">
                {String(displayValue).padStart(2, '0')}
              </span>
              <span className="ase-badge-label">Accuracy Score(%)</span>
              <div className="ase-badge-menu-placeholder" />
            </div>
          )}
        </div>
      </div>

      {/* ── Query editor ── */}
      <div className="ase-section">
        <div className="ase-tabs-header" role="tablist">
          <button
            role="tab"
            aria-selected={activeTab === 'queries'}
            className={`ase-tab${activeTab === 'queries' ? ' ase-tab--active' : ''}`}
            onClick={() => setActiveTab('queries')}
          >
            Queries
            <span className="ase-tab-badge">{queries.length}</span>
          </button>
          <button
            role="tab"
            aria-selected={activeTab === 'transformations'}
            className={`ase-tab${activeTab === 'transformations' ? ' ase-tab--active' : ''}`}
            onClick={() => setActiveTab('transformations')}
          >
            Transformations
            <span className="ase-tab-badge ase-tab-badge--neutral">5</span>
          </button>
        </div>

        <div className="ase-tab-content" role="tabpanel">
          {activeTab === 'queries' ? (
            <div className="ase-queries-tab">
              {/* Datasource selector */}
              <div className="ase-ds-row">
                <div className="ase-ds-dropdown" onBlur={() => setDsOpen(false)}>
                  <button
                    className="ase-ds-btn"
                    onClick={() => setDsOpen(v => !v)}
                    aria-haspopup="listbox"
                    aria-expanded={dsOpen}
                    aria-label="Select datasource"
                  >
                    {datasource}
                    <ChevronDown
                      size={13}
                      className={`ase-ds-chevron${dsOpen ? ' ase-ds-chevron--open' : ''}`}
                    />
                  </button>
                  {dsOpen && (
                    <ul className="ase-ds-menu" role="listbox">
                      {(['Loki', 'Prometheus'] as Datasource[]).map(ds => (
                        <li
                          key={ds}
                          role="option"
                          aria-selected={datasource === ds}
                          className={`ase-ds-option${datasource === ds ? ' ase-ds-option--active' : ''}`}
                          onMouseDown={() => handleDatasourceChange(ds)}
                        >
                          {datasource === ds && <Check size={12} className="ase-ds-check" />}
                          {ds}
                        </li>
                      ))}
                    </ul>
                  )}
                </div>
              </div>

              {/* Query accordions */}
              <div className="ase-query-list">
                {queries.map(q => (
                  <LokiQueryAccordion
                    key={q.id}
                    id={q.id}
                    name={q.name}
                    datasource={q.datasource}
                    initialQuery={q.query}
                    onRename={renameQuery}
                    onDuplicate={duplicateQuery}
                    onDelete={deleteQuery}
                    onQueryChange={handleQueryChange}
                    onRun={handleRunQuery}
                    runLoading={runLoading}
                    runError={runError}
                  />
                ))}
              </div>

              {/* Action row */}
              <div className="ase-query-actions">
                <button className="ase-action-btn" onClick={addQuery}>Add Query</button>
                <button className="ase-action-btn">Expression</button>
                <div className="ase-query-actions-right">
                  <button
                    className={`ase-save-btn${savedFlash ? ' ase-save-btn--saved' : ''}`}
                    onClick={handleSave}
                  >
                    {savedFlash ? 'Saved!' : 'Apply & Save'}
                  </button>
                </div>
              </div>
            </div>
          ) : (
            <div className="ase-transformations-tab" aria-label="Transformations — coming soon" />
          )}
        </div>
      </div>
    </div>
  );
}
