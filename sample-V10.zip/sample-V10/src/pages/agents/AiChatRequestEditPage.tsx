import { useEffect, useRef, useState, useCallback, useMemo } from 'react';
import { useNavigate, useParams, useLocation } from 'react-router-dom';
import { ChevronDown, Check, ArrowLeft } from 'lucide-react';
import { TimeRangePicker } from '../../components/common/TimeRangePicker';
import { LokiQueryAccordion } from '../../components/dashboard/LokiQueryAccordion';
import { SectionCard } from '../../components/dashboard/SectionCard';
import CircularGauge from '../../components/dashboard/CircularGauge';
import type { PanelMenuItem } from '../../components/common/PanelMenu';
import { DEFAULT_PANEL_MENU } from '../../config/panelMenus';
import {
  getAiChatRequestPrometheusQuery,
  getAiChatRequestLokiQuery,
  setAiChatRequestPrometheusQuery,
  setAiChatRequestLokiQuery,
  buildAiChatRequestQuery,
} from '../../services/aiChatRequestQueryStore';
import {
  executePrometheusQuery,
  executeLokiQuery,
} from '../../services/prometheusService';
import { presetToSeconds } from '../../utils/timeRange';
import './InputTokenEditPage.css';
import './AvgLatencyEditPage.css';

type Datasource = 'Loki' | 'Prometheus';

interface QueryItem {
  id: string;
  name: string;
  datasource: Datasource;
  query: string;
}

function getDefaultQuery(ds: Datasource): string {
  return ds === 'Loki' ? getAiChatRequestLokiQuery() : getAiChatRequestPrometheusQuery();
}

export default function AiChatRequestEditPage() {
  const navigate      = useNavigate();
  const location      = useLocation();
  const { agentName: rawAgentName = '' } = useParams<{ agentName: string }>();
  const agentName    = decodeURIComponent(rawAgentName);
  const ticketNumber = new URLSearchParams(location.search).get('ticket') ?? '';

  const [timeRange, setTimeRange] = useState('Last 5 Minutes');
  const [activeTab, setActiveTab] = useState<'queries' | 'transformations'>('queries');

  /* ── Datasource selector ── */
  const [datasource, setDatasource] = useState<Datasource>('Prometheus');
  const [dsOpen, setDsOpen]         = useState(false);

  /* ── Query list ── */
  const [queries, setQueries] = useState<QueryItem[]>([
    { id: 'q1', name: 'A', datasource: 'Prometheus', query: getAiChatRequestPrometheusQuery() },
  ]);
  const queryIdRef = useRef(1);

  /* ── Widget value ── */
  const [aiChatRequests, setAiChatRequests] = useState<number | null>(null);
  const [widgetLoading, setWidgetLoading]   = useState(true);

  /* ── Query execution state ── */
  const [runLoading, setRunLoading] = useState(false);
  const [runError,   setRunError]   = useState<string | null>(null);
  const [savedFlash, setSavedFlash] = useState(false);

  /* ── Load initial widget value ── */
  useEffect(() => {
    setWidgetLoading(true);
    const resolved = buildAiChatRequestQuery(
      getAiChatRequestPrometheusQuery(),
      agentName,
      ticketNumber || undefined,
    );
    executePrometheusQuery(resolved)
      .then(v => setAiChatRequests(Math.round(v)))
      .finally(() => setWidgetLoading(false));
  }, [agentName, ticketNumber]);

  /* ── Switch datasource ── */
  const handleDatasourceChange = useCallback((ds: Datasource) => {
    setDatasource(ds);
    setDsOpen(false);
    setQueries(prev => prev.map(q => ({ ...q, datasource: ds, query: getDefaultQuery(ds) })));
    setRunError(null);
  }, []);

  /* ── Track query text edits ── */
  const handleQueryChange = (id: string, query: string) => {
    setQueries(prev => prev.map(q => q.id === id ? { ...q, query } : q));
  };

  /* ── Run query → update widget value ── */
  const handleRunQuery = async (_id: string, query: string, ds: string) => {
    setRunLoading(true);
    setRunError(null);
    try {
      const resolved = buildAiChatRequestQuery(query, agentName, ticketNumber || undefined);
      const value = ds === 'Prometheus'
        ? await executePrometheusQuery(resolved, true)
        : await executeLokiQuery(resolved, presetToSeconds(timeRange), true);
      setAiChatRequests(Math.round(value));
    } catch (err) {
      setRunError(err instanceof Error ? err.message : 'Query execution failed');
    } finally {
      setRunLoading(false);
    }
  };

  /* ── Save: persist to store so dashboard picks it up ── */
  const handleSave = () => {
    queries.forEach(q => {
      if (q.datasource === 'Loki') setAiChatRequestLokiQuery(q.query);
      else setAiChatRequestPrometheusQuery(q.query);
    });
    setSavedFlash(true);
    setTimeout(() => setSavedFlash(false), 2000);
  };

  /* ── Query CRUD ── */
  const renameQuery = (id: string, newName: string) => {
    setQueries(prev => prev.map(q => q.id === id ? { ...q, name: newName } : q));
  };

  const addQuery = () => {
    setQueries(prev => {
      queryIdRef.current += 1;
      const name = String.fromCharCode(65 + prev.length);
      return [...prev, { id: `q${queryIdRef.current}`, name, datasource, query: getDefaultQuery(datasource) }];
    });
  };

  const duplicateQuery = (id: string) => {
    setQueries(prev => {
      const source = prev.find(q => q.id === id);
      if (!source) return prev;
      queryIdRef.current += 1;
      const name = String.fromCharCode(65 + prev.length);
      return [...prev, { id: `q${queryIdRef.current}`, name, datasource: source.datasource, query: source.query }];
    });
  };

  const deleteQuery = (id: string) => {
    setQueries(prev => prev.filter(q => q.id !== id));
  };

  const widgetMenuItems = useMemo<PanelMenuItem[]>(() =>
    DEFAULT_PANEL_MENU.map(item =>
      item.id === 'edit' ? { ...item, onAction: () => {} } : item,
    ),
  []);

  return (
    <div className="ite-page">
      {/* ── Page header ── */}
      <div className="ite-header">
        <nav className="ite-breadcrumb" aria-label="breadcrumb">
          <button className="ite-breadcrumb-link" onClick={() => navigate('/home')}>
            Home
          </button>
          <span className="ite-breadcrumb-sep">&rsaquo;</span>
          <button className="ite-breadcrumb-link" onClick={() => navigate('/home')}>
            Dashboard
          </button>
          <span className="ite-breadcrumb-sep">&rsaquo;</span>
          {agentName && (
            <>
              <button
                className="ite-breadcrumb-link"
                onClick={() => navigate(`/agents/${encodeURIComponent(agentName)}`)}
              >
                {agentName}
              </button>
              <span className="ite-breadcrumb-sep">&rsaquo;</span>
            </>
          )}
          <span className="ite-breadcrumb-current">Edit AI Chat Request</span>
        </nav>

        <div className="ite-controls">
          <TimeRangePicker
            value={timeRange}
            onApply={r => setTimeRange(r.preset ?? 'Custom Range')}
          />
          <button className="ite-back-btn" onClick={() => navigate(-1)}>
            <ArrowLeft size={14} />
            Back
          </button>
        </div>
      </div>

      {/* ── Section 1: AI Chat Request widget preview ── */}
      <div className="ite-widget-row">
        <SectionCard title="AI Chat Request" menuItems={widgetMenuItems}>
          <div className="acr-gauge-center">
            {widgetLoading ? (
              <div className="ite-token-skeleton" />
            ) : (
              <CircularGauge
                value={aiChatRequests ?? 0}
                color="#F43F5E"
                size={88}
                strokeWidth={9}
                valueSize={20}
              />
            )}
          </div>
        </SectionCard>
      </div>

      {/* ── Section 2: Query editor ── */}
      <div className="ite-section">
        {/* Tab headers */}
        <div className="ite-tabs-header" role="tablist">
          <button
            role="tab"
            aria-selected={activeTab === 'queries'}
            className={`ite-tab${activeTab === 'queries' ? ' ite-tab--active' : ''}`}
            onClick={() => setActiveTab('queries')}
          >
            Queries
            <span className="ite-tab-badge">{queries.length}</span>
          </button>
          <button
            role="tab"
            aria-selected={activeTab === 'transformations'}
            className={`ite-tab${activeTab === 'transformations' ? ' ite-tab--active' : ''}`}
            onClick={() => setActiveTab('transformations')}
          >
            Transformations
            <span className="ite-tab-badge ite-tab-badge--neutral">5</span>
          </button>
        </div>

        {/* Tab content */}
        <div className="ite-tab-content" role="tabpanel">
          {activeTab === 'queries' ? (
            <div className="ite-queries-tab">
              {/* Datasource selector */}
              <div className="ite-ds-row">
                <div className="ite-ds-dropdown" onBlur={() => setDsOpen(false)}>
                  <button
                    className="ite-ds-btn"
                    onClick={() => setDsOpen(v => !v)}
                    aria-haspopup="listbox"
                    aria-expanded={dsOpen}
                    aria-label="Select datasource"
                  >
                    {datasource}
                    <ChevronDown
                      size={13}
                      className={`ite-ds-chevron${dsOpen ? ' ite-ds-chevron--open' : ''}`}
                    />
                  </button>
                  {dsOpen && (
                    <ul className="ite-ds-menu" role="listbox">
                      {(['Loki', 'Prometheus'] as Datasource[]).map(ds => (
                        <li
                          key={ds}
                          role="option"
                          aria-selected={datasource === ds}
                          className={`ite-ds-option${datasource === ds ? ' ite-ds-option--active' : ''}`}
                          onMouseDown={() => handleDatasourceChange(ds)}
                        >
                          {datasource === ds && <Check size={12} className="ite-ds-check" />}
                          {ds}
                        </li>
                      ))}
                    </ul>
                  )}
                </div>
              </div>

              {/* Query accordions */}
              <div className="ite-query-list">
                {queries.map(q => (
                  <LokiQueryAccordion
                    key={q.id}
                    id={q.id}
                    name={q.name}
                    datasource={q.datasource}
                    initialQuery={q.query}
                    onRename={renameQuery}
                    onDuplicate={duplicateQuery}
                    onDelete={deleteQuery}
                    onQueryChange={handleQueryChange}
                    onRun={handleRunQuery}
                    runLoading={runLoading}
                    runError={runError}
                  />
                ))}
              </div>

              {/* Actions row */}
              <div className="ite-query-actions">
                <button className="ite-action-btn" onClick={addQuery}>
                  Add Query
                </button>
                <button className="ite-action-btn">Expression</button>

                <div className="ite-query-actions-right">
                  <button
                    className={`ite-save-btn${savedFlash ? ' ite-save-btn--saved' : ''}`}
                    onClick={handleSave}
                  >
                    {savedFlash ? 'Saved!' : 'Apply & Save'}
                  </button>
                </div>
              </div>
            </div>
          ) : (
            <div className="ite-transformations-tab" aria-label="Transformations — coming soon" />
          )}
        </div>
      </div>
    </div>
  );
}
