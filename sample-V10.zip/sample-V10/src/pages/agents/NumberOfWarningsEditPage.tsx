import { useEffect, useRef, useState, useCallback, useMemo } from 'react';
import { useNavigate, useParams, useLocation } from 'react-router-dom';
import { ChevronDown, Check, ArrowLeft } from 'lucide-react';
import { TimeRangePicker } from '../../components/common/TimeRangePicker';
import { LokiQueryAccordion } from '../../components/dashboard/LokiQueryAccordion';
import CircularGauge from '../../components/dashboard/CircularGauge';
import type { PanelMenuItem } from '../../components/common/PanelMenu';
import { DEFAULT_PANEL_MENU } from '../../config/panelMenus';
import {
  getWarningsLokiQuery,
  getWarningsPrometheusQuery,
  setWarningsLokiQuery,
  setWarningsPrometheusQuery,
  buildWarningsQuery,
} from '../../services/warningsQueryStore';
import {
  executePrometheusQuery,
  executeLokiQuery,
} from '../../services/prometheusService';
import { presetToSeconds } from '../../utils/timeRange';
import './NumberOfWarningsEditPage.css';

type Datasource = 'Loki' | 'Prometheus';

interface QueryItem {
  id: string;
  name: string;
  datasource: Datasource;
  query: string;
}

function getDefaultQuery(ds: Datasource): string {
  return ds === 'Loki' ? getWarningsLokiQuery() : getWarningsPrometheusQuery();
}

export default function NumberOfWarningsEditPage() {
  const navigate   = useNavigate();
  const location   = useLocation();
  const { agentName: rawAgentName = '' } = useParams<{ agentName: string }>();
  const agentName    = decodeURIComponent(rawAgentName);
  const ticketNumber = new URLSearchParams(location.search).get('ticket') ?? '';

  const [timeRange, setTimeRange] = useState('Last 5 Minutes');
  const [activeTab, setActiveTab] = useState<'queries' | 'transformations'>('queries');

  const [datasource, setDatasource] = useState<Datasource>('Loki');
  const [dsOpen, setDsOpen]         = useState(false);

  const [queries, setQueries] = useState<QueryItem[]>([
    { id: 'q1', name: 'A', datasource: 'Loki', query: getWarningsLokiQuery() },
  ]);
  const queryIdRef = useRef(1);

  const [warningsCount, setWarningsCount] = useState<number | null>(null);
  const [widgetLoading, setWidgetLoading] = useState(true);
  const [runLoading, setRunLoading]       = useState(false);
  const [runError, setRunError]           = useState<string | null>(null);
  const [savedFlash, setSavedFlash]       = useState(false);

  useEffect(() => {
    setWidgetLoading(true);
    const resolved = buildWarningsQuery(getWarningsLokiQuery(), agentName, ticketNumber || undefined);
    executeLokiQuery(resolved, presetToSeconds(timeRange))
      .then(v => setWarningsCount(v))
      .finally(() => setWidgetLoading(false));
  }, [agentName, ticketNumber, timeRange]);

  const handleDatasourceChange = useCallback((ds: Datasource) => {
    setDatasource(ds);
    setDsOpen(false);
    setQueries(prev => prev.map(q => ({ ...q, datasource: ds, query: getDefaultQuery(ds) })));
    setRunError(null);
  }, []);

  const handleQueryChange = (id: string, query: string) => {
    setQueries(prev => prev.map(q => q.id === id ? { ...q, query } : q));
  };

  const handleRunQuery = async (_id: string, query: string, ds: string) => {
    setRunLoading(true);
    setRunError(null);
    try {
      const resolved = buildWarningsQuery(query, agentName, ticketNumber || undefined);
      const value = ds === 'Prometheus'
        ? await executePrometheusQuery(resolved, true)
        : await executeLokiQuery(resolved, presetToSeconds(timeRange), true);
      setWarningsCount(Math.round(value));
    } catch (err) {
      setRunError(err instanceof Error ? err.message : 'Query execution failed');
    } finally {
      setRunLoading(false);
    }
  };

  const handleSave = () => {
    queries.forEach(q => {
      if (q.datasource === 'Loki') setWarningsLokiQuery(q.query);
      else setWarningsPrometheusQuery(q.query);
    });
    setSavedFlash(true);
    setTimeout(() => setSavedFlash(false), 2000);
  };

  const renameQuery = (id: string, newName: string) => {
    setQueries(prev => prev.map(q => q.id === id ? { ...q, name: newName } : q));
  };

  const addQuery = () => {
    setQueries(prev => {
      queryIdRef.current += 1;
      const name = String.fromCharCode(65 + prev.length);
      return [...prev, { id: `q${queryIdRef.current}`, name, datasource, query: getDefaultQuery(datasource) }];
    });
  };

  const duplicateQuery = (id: string) => {
    setQueries(prev => {
      const source = prev.find(q => q.id === id);
      if (!source) return prev;
      queryIdRef.current += 1;
      const name = String.fromCharCode(65 + prev.length);
      return [...prev, { id: `q${queryIdRef.current}`, name, datasource: source.datasource, query: source.query }];
    });
  };

  const deleteQuery = (id: string) => {
    setQueries(prev => prev.filter(q => q.id !== id));
  };

  const widgetMenuItems = useMemo<PanelMenuItem[]>(() =>
    DEFAULT_PANEL_MENU.map(item =>
      item.id === 'edit' ? { ...item, onAction: () => {} } : item,
    ),
  []);

  return (
    <div className="now-page">
      {/* ── Header ── */}
      <div className="now-header">
        <nav className="now-breadcrumb" aria-label="breadcrumb">
          <button className="now-breadcrumb-link" onClick={() => navigate('/home')}>Home</button>
          <span className="now-breadcrumb-sep">&rsaquo;</span>
          <button className="now-breadcrumb-link" onClick={() => navigate('/home')}>Dashboard</button>
          <span className="now-breadcrumb-sep">&rsaquo;</span>
          {agentName && (
            <>
              <button
                className="now-breadcrumb-link"
                onClick={() => navigate(`/agents/${encodeURIComponent(agentName)}`)}
              >
                {agentName}
              </button>
              <span className="now-breadcrumb-sep">&rsaquo;</span>
            </>
          )}
          <span className="now-breadcrumb-current">Edit Number Of Warnings</span>
        </nav>

        <div className="now-controls">
          <TimeRangePicker
            value={timeRange}
            onApply={r => setTimeRange(r.preset ?? 'Custom Range')}
          />
          <button className="now-back-btn" onClick={() => navigate(-1)}>
            <ArrowLeft size={14} />
            Back
          </button>
        </div>
      </div>

      {/* ── Widget preview ── */}
      <div className="now-widget-row">
        <div className="now-gauge-card">
          <div className="now-gauge-card-header">
            <div>
              <p className="now-gauge-label">Number Of</p>
              <p className="now-gauge-sublabel">Warnings</p>
            </div>
            <div className="now-gauge-menu-placeholder" />
          </div>
          <div className="now-gauge-center">
            {widgetLoading ? (
              <div className="now-gauge-skeleton" />
            ) : (
              <CircularGauge
                value={warningsCount ?? 0}
                color="#3B82F6"
                size={88}
                strokeWidth={9}
                valueSize={20}
              />
            )}
          </div>
        </div>
      </div>

      {/* ── Query editor ── */}
      <div className="now-section">
        <div className="now-tabs-header" role="tablist">
          <button
            role="tab"
            aria-selected={activeTab === 'queries'}
            className={`now-tab${activeTab === 'queries' ? ' now-tab--active' : ''}`}
            onClick={() => setActiveTab('queries')}
          >
            Queries
            <span className="now-tab-badge">{queries.length}</span>
          </button>
          <button
            role="tab"
            aria-selected={activeTab === 'transformations'}
            className={`now-tab${activeTab === 'transformations' ? ' now-tab--active' : ''}`}
            onClick={() => setActiveTab('transformations')}
          >
            Transformations
            <span className="now-tab-badge now-tab-badge--neutral">5</span>
          </button>
        </div>

        <div className="now-tab-content" role="tabpanel">
          {activeTab === 'queries' ? (
            <div className="now-queries-tab">
              {/* Datasource selector */}
              <div className="now-ds-row">
                <div className="now-ds-dropdown" onBlur={() => setDsOpen(false)}>
                  <button
                    className="now-ds-btn"
                    onClick={() => setDsOpen(v => !v)}
                    aria-haspopup="listbox"
                    aria-expanded={dsOpen}
                    aria-label="Select datasource"
                  >
                    {datasource}
                    <ChevronDown
                      size={13}
                      className={`now-ds-chevron${dsOpen ? ' now-ds-chevron--open' : ''}`}
                    />
                  </button>
                  {dsOpen && (
                    <ul className="now-ds-menu" role="listbox">
                      {(['Loki', 'Prometheus'] as Datasource[]).map(ds => (
                        <li
                          key={ds}
                          role="option"
                          aria-selected={datasource === ds}
                          className={`now-ds-option${datasource === ds ? ' now-ds-option--active' : ''}`}
                          onMouseDown={() => handleDatasourceChange(ds)}
                        >
                          {datasource === ds && <Check size={12} className="now-ds-check" />}
                          {ds}
                        </li>
                      ))}
                    </ul>
                  )}
                </div>
              </div>

              {/* Query accordions */}
              <div className="now-query-list">
                {queries.map(q => (
                  <LokiQueryAccordion
                    key={q.id}
                    id={q.id}
                    name={q.name}
                    datasource={q.datasource}
                    initialQuery={q.query}
                    onRename={renameQuery}
                    onDuplicate={duplicateQuery}
                    onDelete={deleteQuery}
                    onQueryChange={handleQueryChange}
                    onRun={handleRunQuery}
                    runLoading={runLoading}
                    runError={runError}
                  />
                ))}
              </div>

              {/* Action row */}
              <div className="now-query-actions">
                <button className="now-action-btn" onClick={addQuery}>Add Query</button>
                <button className="now-action-btn">Expression</button>
                <div className="now-query-actions-right">
                  <button
                    className={`now-save-btn${savedFlash ? ' now-save-btn--saved' : ''}`}
                    onClick={handleSave}
                  >
                    {savedFlash ? 'Saved!' : 'Apply & Save'}
                  </button>
                </div>
              </div>
            </div>
          ) : (
            <div className="now-transformations-tab" aria-label="Transformations — coming soon" />
          )}
        </div>
      </div>
    </div>
  );
}
