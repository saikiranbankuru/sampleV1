import { useState, useEffect, useCallback, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { ChevronLeft, RefreshCw, Sparkle, Bot, Search } from 'lucide-react';
import { Button } from '../../components/common/Button';
import { TimeRangePicker } from '../../components/common/TimeRangePicker';
import { OnboardingModal } from '../../components/common/OnboardingModal';
import { useToast } from '../../components/common/Toast';
import { fetchAllAvailableAgents, addAvailableAgent } from '../../services/dashboardApi';
import { registerDynamicAgent } from '../../services/agentApi';
import type { AvailableAgent } from '../../types/dashboard';
import './AvailableAgentsPage.css';

/* ── skeleton row ── */
const SkeletonRow = () => <div className="aap-skeleton-row" />;

/* ── empty state ── */
const EmptyState = ({ filtered, onAdd }: { filtered: boolean; onAdd: () => void }) => (
  <div className="aap-empty">
    <Bot size={48} className="aap-empty-icon" />
    <p className="aap-empty-title">
      {filtered ? 'No agents match your search' : 'No agents available'}
    </p>
    <p className="aap-empty-sub">
      {filtered
        ? 'Try a different search term.'
        : 'Get started by onboarding your first agent.'}
    </p>
    {!filtered && (
      <Button variant="primary" onClick={onAdd}>Onboarding New Agent</Button>
    )}
  </div>
);

/* ── agent card ── */
const AgentCard = ({ agent, onView }: { agent: AvailableAgent; onView: () => void }) => (
  <div className="aap-list-item">
    <Sparkle size={14} className="aap-item-star" />
    <span className="aap-item-name">{agent.name}</span>
    <button className="aap-item-link" onClick={onView}>View Dashboard</button>
  </div>
);

/* ── main page ── */
export default function AvailableAgentsPage() {
  const navigate = useNavigate();
  const { show: showToast, ToastContainer } = useToast();

  const [agents,    setAgents]    = useState<AvailableAgent[]>([]);
  const [loading,   setLoading]   = useState(true);
  const [spinning,  setSpinning]  = useState(false);
  const [modalOpen, setModalOpen] = useState(false);
  const [query,     setQuery]     = useState('');
  const [timeRange, setTimeRange] = useState('Last 5 Minutes');

  const load = useCallback(async () => {
    setSpinning(true);
    try {
      const data = await fetchAllAvailableAgents();
      setAgents(data);
    } finally {
      setLoading(false);
      setSpinning(false);
    }
  }, []);

  useEffect(() => { load(); }, [load]);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return agents;
    return agents.filter(a =>
      a.name.toLowerCase().includes(q) || a.id.toLowerCase().includes(q)
    );
  }, [agents, query]);

  const handleCreate = async (name: string) => {
    const newAgent = await addAvailableAgent(name);
    registerDynamicAgent(newAgent.id, newAgent.name);
    setAgents(prev => [...prev, newAgent]);
    showToast(`Agent "${newAgent.name}" onboarded successfully!`, 'success');
  };

  return (
    <div className="aap-page">

      {/* ── breadcrumb row ── */}
      <nav className="aap-breadcrumb">
        <span className="aap-breadcrumb-link" onClick={() => navigate('/home')}>Home</span>
        <span className="aap-breadcrumb-sep">&gt;</span>
        <span className="aap-breadcrumb-current">Available Agents</span>
      </nav>

      {/* ── page title + back/refresh ── */}
      <div className="aap-title-row">
        <h1 className="aap-title">Available Agents</h1>
        <div className="aap-title-actions">
          <button className="aap-icon-btn" onClick={() => navigate('/home')} title="Back">
            <ChevronLeft size={15} />
          </button>
          <button
            className={`aap-icon-btn${spinning ? ' aap-icon-btn--spinning' : ''}`}
            onClick={load}
            title="Refresh"
          >
            <RefreshCw size={15} />
          </button>
        </div>
      </div>

      {/* ── content card (matches dashboards-content-card) ── */}
      <div className="aap-content-card">

        {/* filter row — mirrors dashboards-filter-row */}
        <div className="aap-filter-row">
          <div className="aap-search-wrap">
            <Search size={15} className="aap-search-icon" />
            <input
              className="aap-search-input"
              type="text"
              placeholder="Search agents..."
              value={query}
              onChange={e => setQuery(e.target.value)}
              spellCheck={false}
              autoComplete="off"
            />
          </div>

          <div className="aap-filter-actions">
            <TimeRangePicker
              value={timeRange}
              onApply={r => setTimeRange(r.preset ?? 'Custom Range')}
            />
            <Button
              variant="primary"
              icon={<Sparkle size={14} />}
              onClick={() => setModalOpen(true)}
            >
              Onboarding New Agent
            </Button>
          </div>
        </div>

        {/* section label */}
        <div className="aap-section-label">
          <span>AVAILABLE AGENTS</span>
          {!loading && (
            <span className="aap-section-count">
              {query
                ? `${filtered.length} of ${agents.length}`
                : agents.length}
            </span>
          )}
        </div>

        {/* list / skeleton / empty */}
        {loading ? (
          <div className="aap-skeleton-list">
            {[...Array(5)].map((_, i) => <SkeletonRow key={i} />)}
          </div>
        ) : filtered.length === 0 ? (
          <EmptyState filtered={query.length > 0} onAdd={() => setModalOpen(true)} />
        ) : (
          <div className="aap-list">
            {filtered.map(agent => (
              <AgentCard
                key={agent.id}
                agent={agent}
                onView={() => navigate(`/agents/${encodeURIComponent(agent.name)}`)}
              />
            ))}
          </div>
        )}
      </div>

      {/* ── onboarding modal ── */}
      <OnboardingModal
        isOpen={modalOpen}
        onClose={() => setModalOpen(false)}
        onCreate={handleCreate}
      />

      <ToastContainer />
    </div>
  );
}
