import { useState, useCallback } from 'react';
import { Search, Star, Plus, MoreVertical, ChevronDown } from 'lucide-react';
import { RefreshControls } from '../../components/common/RefreshControls';
import './DashboardsPage.css';

const DASHBOARDS = [
  { id: 1, name: 'Agentic AI Details', tag: 'APP' },
  { id: 2, name: 'Agentic AI Landing Pages', tag: 'APP' },
  { id: 3, name: 'Agentic AI Landing Pages Copy', tag: 'APP' },
  { id: 4, name: 'Applications Dashboard', tag: 'APP' },
  { id: 5, name: 'CloudPractics-Team', tag: 'APP' },
  { id: 6, name: 'AI Logs Onboarding', tag: 'APP' },
  { id: 7, name: 'Genpact CCGY Internal', tag: 'APP' },
];

export default function DashboardsPage() {
  const [search, setSearch] = useState('');
  const [refreshKey, setRefreshKey] = useState(0);
  const [spinning, setSpinning] = useState(false);

  const handleRefresh = useCallback(() => {
    setSpinning(true);
    setTimeout(() => {
      setRefreshKey(k => k + 1);
      setSpinning(false);
    }, 400);
  }, []);

  const filtered = DASHBOARDS.filter(d =>
    d.name.toLowerCase().includes(search.toLowerCase()),
  );

  void refreshKey;

  return (
    <div className="dashboards-page">
      {/* Breadcrumb */}
      <nav className="dashboards-breadcrumb">
        <span className="dashboards-breadcrumb-link">Home</span>
        <span className="dashboards-breadcrumb-sep">&gt;</span>
        <span className="dashboards-breadcrumb-current">Dashboard</span>
      </nav>

      {/* Page title row with refresh controls */}
      <div className="dashboards-title-row">
        <h1 className="dashboards-title">Dashboards</h1>
        <RefreshControls onRefresh={handleRefresh} spinning={spinning} />
      </div>

      {/* Outer white/dark card */}
      <div className="dashboards-content-card">
        {/* Filter row */}
        <div className="dashboards-filter-row">
          <div className="dashboards-search-wrap">
            <Search size={15} className="dashboards-search-icon" />
            <input
              type="text"
              className="dashboards-search-input"
              placeholder="Search"
              value={search}
              onChange={e => setSearch(e.target.value)}
            />
          </div>

          <div className="dashboards-tag-filter">
            <Search size={14} className="dashboards-tag-icon" />
            <span className="dashboards-tag-label">Filter by tag</span>
            <ChevronDown size={14} className="dashboards-tag-chevron" />
          </div>

          <div className="dashboards-actions">
            <button className="dashboards-action-btn" title="Starred">
              <Star size={16} />
            </button>
            <button className="dashboards-action-btn" title="New dashboard">
              <Plus size={16} />
            </button>
            <button className="dashboards-action-btn" title="More options">
              <MoreVertical size={16} />
            </button>
          </div>
        </div>

        {/* Dashboard list — each item is its own card */}
        <div className="dashboards-list">
          {filtered.length === 0 ? (
            <div className="dashboards-empty">No dashboards match your search.</div>
          ) : (
            filtered.map(d => (
              <div key={d.id} className="dashboards-list-item">
                <span className="dashboards-item-name">
                  <span className="dashboards-item-label">Name: </span>
                  {d.name}
                </span>
                <span className="dashboards-item-tag">
                  <span className="dashboards-item-label">Tag: </span>
                  <span className="dashboards-item-tag-value">{d.tag}</span>
                </span>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
