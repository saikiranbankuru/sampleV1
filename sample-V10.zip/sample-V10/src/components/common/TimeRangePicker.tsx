import { useState, useEffect, useRef } from 'react';
import { Search, Copy, Clock, Info, ChevronDown, X, Check } from 'lucide-react';
import { DateTimePicker } from './DateTimePicker';
import './TimeRangePicker.css';

/* ─── types ──────────────────────────────────────────────── */
export interface TimeRangeValue {
  preset: string | null;
  from: string;
  to: string;
}

export interface TimeRangePickerProps {
  value?: string;
  onApply: (range: TimeRangeValue) => void;
  defaultPreset?: string;
  timezone?: string;
  onTimezoneChange?: (tz: string) => void;
}

/* ─── static data ─────────────────────────────────────────── */
const PRESETS = [
  'Last 5 Minutes',
  'Last 15 Minutes',
  'Last 30 Minutes',
  'Last 1 Hour',
  'Last 3 Hours',
  'Last 6 Hours',
  'Last 12 Hours',
  'Last 24 Hours',
  'Last 7 Days',
  'Last 30 Days',
];

const TIMEZONES = [
  { label: 'IST – India Standard Time',       value: 'Asia/Kolkata',        abbr: 'IST'  },
  { label: 'UTC – Coordinated Universal Time', value: 'UTC',                 abbr: 'UTC'  },
  { label: 'EST – Eastern Standard Time',      value: 'America/New_York',    abbr: 'EST'  },
  { label: 'PST – Pacific Standard Time',      value: 'America/Los_Angeles', abbr: 'PST'  },
  { label: 'GMT – Greenwich Mean Time',        value: 'Europe/London',       abbr: 'GMT'  },
  { label: 'CET – Central European Time',      value: 'Europe/Paris',        abbr: 'CET'  },
  { label: 'JST – Japan Standard Time',        value: 'Asia/Tokyo',          abbr: 'JST'  },
  { label: 'AEST – Australian Eastern Time',   value: 'Australia/Sydney',    abbr: 'AEST' },
];

const MONTHS = [
  'January', 'February', 'March', 'April', 'May', 'June',
  'July', 'August', 'September', 'October', 'November', 'December',
];

/* ─── helpers ─────────────────────────────────────────────── */
function toLocalISO(d: Date): string {
  const p = (n: number) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}T${p(d.getHours())}:${p(d.getMinutes())}`;
}

function computePreset(preset: string): { from: string; to: string } {
  const now  = new Date();
  const from = new Date(now);
  const m    = preset.match(/Last\s+(\d+)\s+(Minute|Hour|Day|Month|Year)/i);
  if (m) {
    const n    = parseInt(m[1]);
    const unit = m[2].toLowerCase();
    if      (unit === 'minute') from.setMinutes(from.getMinutes() - n);
    else if (unit === 'hour')   from.setHours(from.getHours() - n);
    else if (unit === 'day')    from.setDate(from.getDate() - n);
    else if (unit === 'month')  from.setMonth(from.getMonth() - n);
    else if (unit === 'year')   from.setFullYear(from.getFullYear() - n);
  }
  return { from: toLocalISO(from), to: toLocalISO(now) };
}

/* ─── component ───────────────────────────────────────────── */
export function TimeRangePicker({
  value = 'Last 5 Minutes',
  onApply,
  defaultPreset,
  timezone: controlledTimezone,
  onTimezoneChange,
}: TimeRangePickerProps) {
  const initial        = defaultPreset ?? value;
  const initialRange   = computePreset(initial);

  const [isOpen,          setIsOpen]          = useState(false);
  const [fromDate,        setFromDate]        = useState(initialRange.from);
  const [toDate,          setToDate]          = useState(initialRange.to);
  const [selectedPreset,  setSelectedPreset]  = useState<string | null>(initial);
  const [searchQuery,     setSearchQuery]     = useState('');
  const [internalTz,      setInternalTz]      = useState('Asia/Kolkata');
  const [fiscalYearStart, setFiscalYearStart] = useState('January');
  const [showSettings,    setShowSettings]    = useState(false);
  const [settingsTab,     setSettingsTab]     = useState<'timezone' | 'fiscal'>('timezone');
  const [displayLabel,    setDisplayLabel]    = useState(value);

  const timezone    = controlledTimezone ?? internalTz;
  const wrapperRef  = useRef<HTMLDivElement>(null);

  /* sync display label when value prop changes externally */
  useEffect(() => {
    setDisplayLabel(value);
  }, [value]);

  /* close on outside click */
  useEffect(() => {
    if (!isOpen) return;
    const handler = (e: MouseEvent) => {
      if (wrapperRef.current && !wrapperRef.current.contains(e.target as Node)) {
        setIsOpen(false);
        setShowSettings(false);
      }
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, [isOpen]);

  /* close on ESC */
  useEffect(() => {
    if (!isOpen) return;
    const handler = (e: KeyboardEvent) => {
      if (e.key === 'Escape') { setIsOpen(false); setShowSettings(false); }
    };
    document.addEventListener('keydown', handler);
    return () => document.removeEventListener('keydown', handler);
  }, [isOpen]);

  const filteredPresets = PRESETS.filter(p =>
    p.toLowerCase().includes(searchQuery.toLowerCase())
  );

  /* clicking a preset immediately applies and closes */
  const handlePresetClick = (preset: string) => {
    const range = computePreset(preset);
    setSelectedPreset(preset);
    setFromDate(range.from);
    setToDate(range.to);
    setDisplayLabel(preset);
    onApply({ preset, from: range.from, to: range.to });
    setIsOpen(false);
    setShowSettings(false);
  };

  const handleFromChange = (v: string) => {
    setFromDate(v);
    setSelectedPreset(null);
  };

  const handleToChange = (v: string) => {
    setToDate(v);
    setSelectedPreset(null);
  };

  const handleApply = () => {
    const label = selectedPreset ?? 'Custom Range';
    setDisplayLabel(label);
    onApply({ preset: selectedPreset, from: fromDate, to: toDate });
    setIsOpen(false);
    setShowSettings(false);
  };

  const handleCopy = () => {
    const text = selectedPreset ?? `${fromDate} → ${toDate}`;
    navigator.clipboard.writeText(text).catch(() => {});
  };

  const handleTimezoneChange = (tz: string) => {
    setInternalTz(tz);
    onTimezoneChange?.(tz);
  };

  const tzAbbr = TIMEZONES.find(t => t.value === timezone)?.abbr ?? 'UTC';

  return (
    <div className="trp-wrapper" ref={wrapperRef}>

      {/* ── trigger button ── */}
      <button className="trp-trigger" onClick={() => setIsOpen(v => !v)}>
        <span>{displayLabel}</span>
        <ChevronDown size={13} className={`trp-chevron${isOpen ? ' trp-chevron--open' : ''}`} />
      </button>

      {/* ── dropdown panel ── */}
      {isOpen && (
        <div className="trp-panel">

          {/* ── row 1: two columns ── */}
          <div className="trp-body">

            {/* left: absolute time range */}
            <div className="trp-left">
              <p className="trp-abs-title">Absolute Time Range</p>

              <DateTimePicker
                label="From"
                value={fromDate}
                onChange={handleFromChange}
              />

              <DateTimePicker
                label="To"
                value={toDate}
                onChange={handleToChange}
              />

              {/* action buttons */}
              <div className="trp-actions">
                <button className="trp-icon-btn" title="Copy time range" onClick={handleCopy}>
                  <Copy size={15} />
                </button>
                <button className="trp-icon-btn" title="Current time">
                  <Clock size={15} />
                </button>
                <button className="trp-icon-btn" title="Time range info">
                  <Info size={15} />
                </button>
                <button className="trp-apply-btn" onClick={handleApply}>
                  Apply time range
                </button>
              </div>
            </div>

            {/* column divider */}
            <div className="trp-col-divider" />

            {/* right: search + presets */}
            <div className="trp-right">
              <div className="trp-search-wrap">
                <Search size={14} className="trp-search-icon" />
                <input
                  className="trp-search"
                  placeholder="Search time range (e.g., last 15 minutes, 1 hour)"
                  value={searchQuery}
                  onChange={e => setSearchQuery(e.target.value)}
                />
                {searchQuery && (
                  <button className="trp-search-clear" onClick={() => setSearchQuery('')}>
                    <X size={12} />
                  </button>
                )}
              </div>

              <ul className="trp-presets" role="listbox">
                {filteredPresets.length > 0
                  ? filteredPresets.map(p => (
                    <li
                      key={p}
                      role="option"
                      aria-selected={selectedPreset === p}
                      className={`trp-preset${selectedPreset === p ? ' trp-preset--active' : ''}`}
                      onClick={() => handlePresetClick(p)}
                    >
                      <span className="trp-preset-check">
                        {selectedPreset === p && <Check size={12} />}
                      </span>
                      {p}
                    </li>
                  ))
                  : <li className="trp-preset-empty">No results for &ldquo;{searchQuery}&rdquo;</li>
                }
              </ul>
            </div>
          </div>

          {/* ── row 2: footer ── */}
          <div className="trp-footer">
            <span className="trp-browser-time">
              Browser Time <span className="trp-tz-badge">{tzAbbr}</span>
            </span>

            <button
              className="trp-settings-btn"
              onClick={() => setShowSettings(v => !v)}
            >
              <span className="trp-settings-prefix">Browser Time</span>
              <span className="trp-settings-sep">|</span>
              <span>Change Time Settings</span>
              <ChevronDown
                size={13}
                className={`trp-chevron${showSettings ? ' trp-chevron--open' : ''}`}
              />
            </button>
          </div>

          {/* ── settings panel (inline expand) ── */}
          {showSettings && (
            <div className="trp-settings-panel">
              <div className="trp-tabs">
                <button
                  className={`trp-tab${settingsTab === 'timezone' ? ' trp-tab--active' : ''}`}
                  onClick={() => setSettingsTab('timezone')}
                >Time Zone</button>
                <button
                  className={`trp-tab${settingsTab === 'fiscal' ? ' trp-tab--active' : ''}`}
                  onClick={() => setSettingsTab('fiscal')}
                >Fiscal Year</button>
              </div>

              <div className="trp-settings-content">
                {settingsTab === 'timezone' && (
                  <>
                    <label className="trp-settings-label">
                      Time To Search (Country City Abbreviation)
                    </label>
                    <div className="trp-select-wrap">
                      <select
                        className="trp-select"
                        value={timezone}
                        onChange={e => handleTimezoneChange(e.target.value)}
                      >
                        {TIMEZONES.map(tz => (
                          <option key={tz.value} value={tz.value}>{tz.label}</option>
                        ))}
                      </select>
                      <ChevronDown size={13} className="trp-select-chevron" />
                    </div>
                  </>
                )}

                {settingsTab === 'fiscal' && (
                  <>
                    <label className="trp-settings-label">Fiscal Year Start Month</label>
                    <div className="trp-select-wrap">
                      <select
                        className="trp-select"
                        value={fiscalYearStart}
                        onChange={e => setFiscalYearStart(e.target.value)}
                      >
                        {MONTHS.map(m => (
                          <option key={m} value={m}>{m}</option>
                        ))}
                      </select>
                      <ChevronDown size={13} className="trp-select-chevron" />
                    </div>
                  </>
                )}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
