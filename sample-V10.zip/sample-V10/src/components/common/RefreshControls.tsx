import { useState, useEffect, useRef } from 'react';
import { RefreshCw, ChevronDown } from 'lucide-react';
import './RefreshControls.css';

interface RefreshControlsProps {
  onRefresh: () => void;
  spinning?: boolean;
}

interface IntervalOption {
  label: string;
  value: number | null;
}

const INTERVALS: IntervalOption[] = [
  { label: 'Off',        value: null },
  { label: 'Auto 5s',    value: 5_000 },
  { label: 'Auto 10s',   value: 10_000 },
  { label: 'Auto 30s',   value: 30_000 },
  { label: 'Auto 1m',    value: 60_000 },
  { label: 'Auto 5m',    value: 300_000 },
  { label: 'Auto 15m',   value: 900_000 },
  { label: 'Auto 1hr',   value: 3_600_000 },
  { label: 'Auto 2hr',   value: 7_200_000 },
  { label: 'Auto 1 day', value: 86_400_000 },
];

export function RefreshControls({ onRefresh, spinning = false }: RefreshControlsProps) {
  const [intervalValue, setIntervalValue] = useState<number | null>(null);
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const wrapRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!intervalValue) return;
    const id = setInterval(onRefresh, intervalValue);
    return () => clearInterval(id);
  }, [intervalValue, onRefresh]);

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (wrapRef.current && !wrapRef.current.contains(e.target as Node)) {
        setDropdownOpen(false);
      }
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  const selectedLabel = INTERVALS.find(i => i.value === intervalValue)?.label ?? 'Off';
  const isAutoActive = intervalValue !== null;

  return (
    <div className="rc-wrap">
      <button
        className={`rc-refresh-btn${spinning ? ' rc-refresh-btn--spinning' : ''}`}
        onClick={onRefresh}
        title="Refresh"
      >
        <RefreshCw size={14} />
        <span>Refresh</span>
      </button>

      <div className="rc-auto-wrap" ref={wrapRef}>
        <button
          className={`rc-auto-btn${isAutoActive ? ' rc-auto-btn--active' : ''}`}
          onClick={() => setDropdownOpen(o => !o)}
          title="Auto refresh"
          aria-label="Auto refresh interval"
        >
          {isAutoActive && <span className="rc-auto-label">{selectedLabel}</span>}
          <ChevronDown size={13} className={dropdownOpen ? 'rc-chevron-up' : undefined} />
        </button>

        {dropdownOpen && (
          <div className="rc-dropdown">
            {INTERVALS.map(({ label, value }) => (
              <button
                key={label}
                className={`rc-dropdown-item${intervalValue === value ? ' rc-dropdown-item--active' : ''}`}
                onClick={() => { setIntervalValue(value); setDropdownOpen(false); }}
              >
                {label}
              </button>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
