import { useState, useRef, useEffect } from 'react';
import {
  Bell, Settings, ChevronDown, Search, Menu,
  Sun, Moon, UserCircle, User, LifeBuoy,
  KeyRound, LogOut, SlidersHorizontal, Plus,
  LayoutDashboard, Upload, AlertTriangle,
} from 'lucide-react';
import { useTheme } from '@/contexts/ThemeContext';
import darkLogo from '@/assets/dark-logo.png';
import whiteLogo from '@/assets/white-logo.png';
import darkLogoLetter from '@/assets/dark-logo-letter.png';
import whiteLogoLetter from '@/assets/white-logo latter.png';
import './Topbar.css';

interface TopbarProps {
  onMenuToggle: () => void;
  collapsed: boolean;
}

const USER_MENU = [
  { icon: User, label: 'Profile' },
  { icon: SlidersHorizontal, label: 'Account Settings' },
  { icon: LifeBuoy, label: 'Help & Documentation' },
  { icon: KeyRound, label: 'Keyboard Shortcuts' },
];

const PLUS_MENU = [
  { icon: LayoutDashboard, label: 'New Dashboard' },
  { icon: Upload, label: 'Import Dashboard' },
  { icon: AlertTriangle, label: 'New Alert Rule' },
];

export default function Topbar({ onMenuToggle, collapsed }: TopbarProps) {
  const { theme, toggleTheme } = useTheme();
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const [plusMenuOpen, setPlusMenuOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);
  const plusMenuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target as Node)) {
        setDropdownOpen(false);
      }
      if (plusMenuRef.current && !plusMenuRef.current.contains(e.target as Node)) {
        setPlusMenuOpen(false);
      }
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  const logoSrc = collapsed
    ? (theme === 'dark' ? darkLogoLetter : whiteLogoLetter)
    : (theme === 'dark' ? darkLogo : whiteLogo);

  return (
    <header className="topbar">
      {/* Brand — always left-aligned, matches sidebar width */}
      <div className="topbar-brand-section">
        <img src={logoSrc} alt="Logo" className="topbar-logo-img" />
      </div>

      {/* Hamburger — between brand and search */}
      <button className="topbar-icon-btn topbar-menu-btn" onClick={onMenuToggle} aria-label="Toggle menu">
        <Menu size={20} />
      </button>

      {/* Center search + Plus button */}
      <div className="topbar-search-area">
        <div className="topbar-search-wrap">
          <Search size={15} className="topbar-search-icon" />
          <input
            type="text"
            className="topbar-search-input"
            placeholder="Search"
            aria-label="Global search"
          />
        </div>

        {/* Plus (+) quick-create button */}
        <div className="topbar-plus-wrap" ref={plusMenuRef}>
          <button
            className="topbar-icon-btn topbar-plus-btn"
            onClick={() => setPlusMenuOpen(o => !o)}
            aria-label="Create new"
            title="Create new"
          >
            <Plus size={18} />
          </button>

          {plusMenuOpen && (
            <div className="topbar-plus-dropdown">
              {PLUS_MENU.map(item => {
                const Icon = item.icon;
                return (
                  <button
                    key={item.label}
                    className="topbar-plus-item"
                    onClick={() => setPlusMenuOpen(false)}
                  >
                    <Icon size={15} />
                    <span>{item.label}</span>
                  </button>
                );
              })}
            </div>
          )}
        </div>
      </div>

      {/* Right actions */}
      <div className="topbar-right">
        <button className="topbar-icon-btn" aria-label="Notifications">
          <Bell size={19} />
        </button>
        <button className="topbar-icon-btn" aria-label="Settings">
          <Settings size={19} />
        </button>
        <button className="topbar-icon-btn" onClick={toggleTheme} aria-label="Toggle theme">
          {theme === 'dark' ? <Sun size={19} /> : <Moon size={19} />}
        </button>

        {/* User dropdown */}
        <div className="topbar-user-wrap" ref={dropdownRef}>
          <button
            className="topbar-user"
            onClick={() => setDropdownOpen(o => !o)}
            aria-label="User menu"
          >
            <div className="topbar-avatar">
              <UserCircle size={30} strokeWidth={1.5} />
            </div>
            <span className="topbar-username">User Name</span>
            <ChevronDown size={14} className={`topbar-chevron${dropdownOpen ? ' topbar-chevron--up' : ''}`} />
          </button>

          {dropdownOpen && (
            <div className="topbar-dropdown">
              <div className="topbar-dropdown-header">
                <span className="topbar-dropdown-name">User Name</span>
                <span className="topbar-dropdown-email">user@aictowers.com</span>
              </div>
              <div className="topbar-dropdown-divider" />
              {USER_MENU.map(item => {
                const Icon = item.icon;
                return (
                  <button key={item.label} className="topbar-dropdown-item">
                    <Icon size={15} />
                    <span>{item.label}</span>
                  </button>
                );
              })}
              <div className="topbar-dropdown-divider" />
              <button className="topbar-dropdown-item topbar-dropdown-item--danger">
                <LogOut size={15} />
                <span>Sign Out</span>
              </button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
}
