import { useState, useRef, useEffect } from 'react';
import { ChevronRight, HelpCircle, Copy, Eye, EyeOff, Trash2, Pencil, Check, X, Loader2 } from 'lucide-react';
import { Tooltip } from '../common/Tooltip';
import '../explore/QueryAccordion.css';
import './LokiQueryAccordion.css';

/* ─── Loki Options Panel ──────────────────────────────────── */
function LokiOptionsPanel({
  isExpanded,
  onToggle,
}: {
  isExpanded: boolean;
  onToggle: () => void;
}) {
  const [legendName, setLegendName] = useState('');
  const [lineLimit, setLineLimit] = useState('');
  const [direction, setDirection] = useState<'backward' | 'forward'>('backward');

  return (
    <div className="qa-opts">
      <button
        className="qa-opts-header"
        onClick={onToggle}
        aria-expanded={isExpanded}
      >
        <ChevronRight
          size={13}
          className={`qa-opts-chevron${isExpanded ? ' qa-opts-chevron--open' : ''}`}
          aria-hidden="true"
        />
        <span className="qa-opts-title">Options</span>
      </button>

      {isExpanded && (
        <div className="qa-opts-body">
          {/* Legend Name */}
          <div className="qa-opts-row">
            <label className="qa-opts-label">Legend Name</label>
            <div className="qa-opts-field-group">
              <input
                className="qa-opts-input"
                value={legendName}
                onChange={e => setLegendName(e.target.value)}
                placeholder="{label}"
                aria-label="Legend name"
              />
              <Tooltip placement="top" content="Controls the name of the series in the legend.">
                <button className="qa-opts-info-btn" aria-label="Legend Name help">
                  <HelpCircle size={13} />
                </button>
              </Tooltip>
            </div>
          </div>

          {/* Line Limit */}
          <div className="qa-opts-row">
            <label className="qa-opts-label">Line Limit</label>
            <div className="qa-opts-field-group">
              <input
                className="qa-opts-input qa-opts-input--sm"
                value={lineLimit}
                onChange={e => setLineLimit(e.target.value)}
                placeholder="1000"
                aria-label="Line limit"
              />
              <Tooltip placement="top" content="Maximum number of log lines to return.">
                <button className="qa-opts-info-btn" aria-label="Line Limit help">
                  <HelpCircle size={13} />
                </button>
              </Tooltip>
            </div>
          </div>

          {/* Direction */}
          <div className="qa-opts-row">
            <label className="qa-opts-label">Direction</label>
            <div className="qa-opts-field-group">
              <Tooltip placement="top" content="Direction to search: Backward from now, or Forward from the start.">
                <button className="qa-opts-info-btn" aria-label="Direction help">
                  <HelpCircle size={13} />
                </button>
              </Tooltip>
              <div className="qa-type-group" role="group" aria-label="Log direction">
                <button
                  className={`qa-type-btn${direction === 'backward' ? ' qa-type-btn--active' : ''}`}
                  onClick={() => setDirection('backward')}
                  aria-pressed={direction === 'backward'}
                >
                  Backward
                </button>
                <button
                  className={`qa-type-btn${direction === 'forward' ? ' qa-type-btn--active' : ''}`}
                  onClick={() => setDirection('forward')}
                  aria-pressed={direction === 'forward'}
                >
                  Forward
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

/* ─── LokiQueryAccordion ──────────────────────────────────── */
export interface LokiQueryAccordionProps {
  id: string;
  name: string;
  datasource: string;
  initialQuery?: string;
  onRename: (id: string, name: string) => void;
  onDuplicate: (id: string) => void;
  onDelete: (id: string) => void;
  onQueryChange?: (id: string, query: string) => void;
  onRun?: (id: string, query: string, datasource: string) => void;
  runLoading?: boolean;
  runError?: string | null;
}

export function LokiQueryAccordion({
  id,
  name,
  datasource,
  initialQuery,
  onRename,
  onDuplicate,
  onDelete,
  onQueryChange,
  onRun,
  runLoading,
  runError,
}: LokiQueryAccordionProps) {
  const [isExpanded, setIsExpanded] = useState(true);
  const [isVisible, setIsVisible] = useState(true);
  const [activeView, setActiveView] = useState<'builder' | 'code'>('code');
  const [codeQuery, setCodeQuery] = useState(initialQuery ?? '');
  const [explainQuery, setExplainQuery] = useState(false);
  const [optionsExpanded, setOptionsExpanded] = useState(false);

  /* Sync when the parent changes the initialQuery (e.g. datasource switch) */
  useEffect(() => {
    setCodeQuery(initialQuery ?? '');
  }, [initialQuery]);

  /* Inline rename — same pattern as QueryAccordion */
  const [isEditing, setIsEditing] = useState(false);
  const [editName, setEditName] = useState(name);
  const [isHovered, setIsHovered] = useState(false);
  const nameInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isEditing) nameInputRef.current?.focus();
  }, [isEditing]);

  const commitName = () => {
    const trimmed = editName.trim();
    onRename(id, trimmed || name);
    if (!trimmed) setEditName(name);
    setIsEditing(false);
  };

  const handleNameKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter')  commitName();
    if (e.key === 'Escape') { setEditName(name); setIsEditing(false); }
  };

  const handleCodeChange = (value: string) => {
    setCodeQuery(value);
    onQueryChange?.(id, value);
  };

  const handleRun = () => {
    onRun?.(id, codeQuery, datasource);
  };

  return (
    <div
      className={[
        'qa-accordion',
        isExpanded ? 'qa-accordion--expanded' : '',
        !isVisible ? 'qa-accordion--hidden' : '',
      ]
        .filter(Boolean)
        .join(' ')}
    >
      {/* ══ Header ══ */}
      <div
        className="qa-header"
        onMouseEnter={() => setIsHovered(true)}
        onMouseLeave={() => setIsHovered(false)}
      >
        <div className="qa-header-left">
          <button
            className="qa-expand-btn"
            onClick={() => setIsExpanded(v => !v)}
            aria-expanded={isExpanded}
            aria-label={isExpanded ? 'Collapse query' : 'Expand query'}
          >
            <ChevronRight
              size={15}
              className={`qa-expand-icon${isExpanded ? ' qa-expand-icon--open' : ''}`}
              aria-hidden="true"
            />
          </button>

          {/* Name — inline editable */}
          {isEditing ? (
            <div className="qa-name-edit-wrap">
              <input
                ref={nameInputRef}
                className="qa-name-input"
                value={editName}
                onChange={e => setEditName(e.target.value)}
                onBlur={commitName}
                onKeyDown={handleNameKeyDown}
                aria-label="Query name"
              />
              <button className="qa-name-confirm" onClick={commitName} aria-label="Confirm rename">
                <Check size={11} />
              </button>
              <button
                className="qa-name-cancel"
                onClick={() => { setEditName(name); setIsEditing(false); }}
                aria-label="Cancel rename"
              >
                <X size={11} />
              </button>
            </div>
          ) : (
            <div className="qa-name-display">
              <span className="qa-name-text">{name}</span>
              {isHovered && (
                <button
                  className="qa-name-edit-btn"
                  onClick={() => setIsEditing(true)}
                  aria-label="Rename query"
                >
                  <Pencil size={11} />
                </button>
              )}
            </div>
          )}

          <span className="qa-ds-badge">{datasource}</span>
        </div>

        <div className="qa-header-actions">
          <Tooltip content="Show data source help" placement="top">
            <button className="qa-icon-btn" aria-label="Show data source help">
              <HelpCircle size={15} />
            </button>
          </Tooltip>
          <Tooltip content="Duplicate Query" placement="top">
            <button
              className="qa-icon-btn"
              aria-label="Duplicate Query"
              onClick={() => onDuplicate(id)}
            >
              <Copy size={15} />
            </button>
          </Tooltip>
          <Tooltip content={isVisible ? 'Hide response' : 'Show response'} placement="top">
            <button
              className={`qa-icon-btn${!isVisible ? ' qa-icon-btn--muted' : ''}`}
              aria-label={isVisible ? 'Hide response' : 'Show response'}
              onClick={() => setIsVisible(v => !v)}
            >
              {isVisible ? <Eye size={15} /> : <EyeOff size={15} />}
            </button>
          </Tooltip>
          <Tooltip content="Remove Query" placement="top">
            <button
              className="qa-icon-btn qa-icon-btn--danger"
              aria-label="Remove Query"
              onClick={() => onDelete(id)}
            >
              <Trash2 size={15} />
            </button>
          </Tooltip>
        </div>
      </div>

      {/* ══ Content ══ */}
      {isExpanded && (
        <div className="qa-content">
          {/* Top bar: Label Browser + Explain Query | Builder | Code */}
          <div className="qa-content-topbar">
            <div className="lqa-left-controls">
              <button className="qa-kick-btn">Label Browser</button>
              <div className="lqa-explain">
                <span className="lqa-explain-label">Explain Query</span>
                <button
                  className={`qa-toggle${explainQuery ? ' qa-toggle--on' : ''}`}
                  onClick={() => setExplainQuery(v => !v)}
                  role="switch"
                  aria-checked={explainQuery}
                  aria-label="Toggle Explain Query"
                >
                  <span className="qa-toggle-thumb" />
                </button>
              </div>
            </div>

            <div className="qa-view-toggle" role="group" aria-label="Query editor view">
              {(['builder', 'code'] as const).map(v => (
                <button
                  key={v}
                  className={`qa-view-btn${activeView === v ? ' qa-view-btn--active' : ''}`}
                  onClick={() => setActiveView(v)}
                  aria-pressed={activeView === v}
                >
                  {v === 'builder' ? 'Builder' : 'Code'}
                </button>
              ))}
            </div>
          </div>

          {activeView === 'builder' ? (
            <div className="lqa-builder-placeholder" aria-label="Builder mode — coming soon" />
          ) : (
            <div className="qa-code-view">
              <div className="qa-code-toolbar">
                <textarea
                  className="qa-code-input lqa-code-textarea"
                  value={codeQuery}
                  onChange={e => handleCodeChange(e.target.value)}
                  placeholder={
                    datasource === 'Prometheus'
                      ? '{service_name=~"agent-name|..."}'
                      : '{service_name=~"agent-name|..."}  != `""`\n| json | label_format agent=service_name'
                  }
                  aria-label="Query editor"
                  spellCheck={false}
                  rows={codeQuery.split('\n').length > 1 ? codeQuery.split('\n').length + 1 : 2}
                />
                <button
                  className={`qa-code-run-btn${runLoading ? ' qa-code-run-btn--loading' : ''}`}
                  onClick={handleRun}
                  disabled={runLoading}
                  aria-label="Run queries"
                >
                  {runLoading ? (
                    <>
                      <Loader2 size={13} className="lqa-spin" aria-hidden="true" />
                      Running…
                    </>
                  ) : (
                    'Run Queries'
                  )}
                </button>
              </div>

              {runError && (
                <div className="lqa-run-error" role="alert">
                  {runError}
                </div>
              )}

              <LokiOptionsPanel
                isExpanded={optionsExpanded}
                onToggle={() => setOptionsExpanded(v => !v)}
              />
            </div>
          )}
        </div>
      )}
    </div>
  );
}
