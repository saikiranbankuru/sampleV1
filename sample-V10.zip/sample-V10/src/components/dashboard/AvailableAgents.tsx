import type { FC } from 'react';
import { Sparkle } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import type { AvailableAgent } from '../../types/dashboard';
import './DashboardWidgets.css';

interface AvailableAgentsProps {
  agents: AvailableAgent[];
}

export const AvailableAgents: FC<AvailableAgentsProps> = ({ agents }) => {
  const navigate = useNavigate();

  return (
    <ul className="avail-agent-list">
      {agents.map(agent => (
        <li key={agent.id} className="avail-agent-item">
          <Sparkle size={13} className="avail-agent-star" />
          <span className="avail-agent-name">{agent.name}</span>
          <button
            className="avail-agent-link"
            onClick={() => navigate(`/agents/${encodeURIComponent(agent.name)}`)}
          >
            View Dashboard
          </button>
        </li>
      ))}
    </ul>
  );
};
