import axios, { type AxiosInstance } from 'axios';

const TIMEOUT_MS = 30_000;

export const createAxiosInstance = (baseURL: string): AxiosInstance =>
  axios.create({
    baseURL,
    timeout: TIMEOUT_MS,
    headers: {
      'Content-Type': 'application/json',
      Accept: 'application/json',
    },
  });
