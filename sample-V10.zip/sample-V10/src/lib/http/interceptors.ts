import {
  type AxiosInstance,
  type AxiosError,
  type InternalAxiosRequestConfig,
} from 'axios';
import type { ApiError } from '@/types/api';

const TOKEN_KEY = 'auth_token';

const getToken = (): string | null => localStorage.getItem(TOKEN_KEY);
const clearToken = (): void => localStorage.removeItem(TOKEN_KEY);

export const registerInterceptors = (instance: AxiosInstance): void => {
  instance.interceptors.request.use(
    (config: InternalAxiosRequestConfig) => {
      const token = getToken();
      if (token) {
        config.headers.Authorization = `Bearer ${token}`;
      }
      return config;
    },
    (error: unknown) => Promise.reject(error),
  );

  instance.interceptors.response.use(
    (response) => response,
    (error: AxiosError) => {
      if (error.response?.status === 401) {
        clearToken();
        window.location.href = '/login';
      }
      return Promise.reject(toApiError(error));
    },
  );
};

const toApiError = (error: AxiosError): ApiError => {
  if (error.response) {
    const serverMessage = (error.response.data as Record<string, string>)?.message;
    return {
      message: serverMessage ?? `Request failed with status ${error.response.status}`,
      status: error.response.status,
      code: String(error.response.status),
    };
  }
  if (error.request) {
    return { message: 'Network error – no response received', code: 'NETWORK_ERROR' };
  }
  return { message: error.message ?? 'An unexpected error occurred', code: 'UNKNOWN' };
};
