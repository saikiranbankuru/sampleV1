import { createAxiosInstance } from './axiosInstance';
import { registerInterceptors } from './interceptors';
import type { AxiosInstance } from 'axios';

const build = (envKey: string, fallback: string): AxiosInstance => {
  const instance = createAxiosInstance(import.meta.env[envKey] ?? fallback);
  registerInterceptors(instance);
  return instance;
};

export const lokiInstance       = build('VITE_API_LOKI_BASE_URL',       '/loki');
export const prometheusInstance = build('VITE_API_PROMETHEUS_BASE_URL', '/prometheus');
export const dbInstance         = build('VITE_API_DB_BASE_URL',         '/api');
