import { http, HttpResponse } from 'msw';
import type { LokiQueryResponse, LokiStream } from '@/types/log';

const LOKI_BASE_URL       = import.meta.env.VITE_API_LOKI_BASE_URL       as string;
const PROMETHEUS_BASE_URL = import.meta.env.VITE_API_PROMETHEUS_BASE_URL  as string;
const DB_BASE_URL         = import.meta.env.VITE_API_DB_BASE_URL          as string;

void DB_BASE_URL; // handler not yet needed

// ---------------------------------------------------------------------------
// Mock log helper — builds a JSON log line string the way the real agent does
// ---------------------------------------------------------------------------

const logLine = (timestamp: string, caseNumber: string, agent: string, message: string): string =>
  JSON.stringify({ timestamp, case_number: caseNumber, agent, message });

// ---------------------------------------------------------------------------
// Mock streams — one LokiStream per ticket, matches LokiStream type exactly
// ---------------------------------------------------------------------------

const MOCK_STREAMS: LokiStream[] = [
  {
    stream_labels: { agent: 'Ticket approval Agent', case_number: 'CS0007894', detected_level: 'info', level: 'info', service_name: 'Digital-Agent' },
    logs: [{ timestamp_ns: '1748174400000000000', log: logLine('2026-05-21 12:00:00', 'CS0007894', 'Ticket approval Agent', 'Workflow completed (Incident branch)') }],
  },
  {
    stream_labels: { agent: 'Ticket approval Agent', case_number: 'CS0007895', detected_level: 'info', level: 'info', service_name: 'digital-agent' },
    logs: [{ timestamp_ns: '1748174700000000000', log: logLine('2026-05-25 12:05:00', 'CS0007895', 'Ticket approval Agent', 'Starting') }],
  },
  {
    stream_labels: { agent: 'Incident Crew', case_number: 'CS0007896', detected_level: 'error', level: 'error', service_name: 'Digital-Agent' },
    logs: [{ timestamp_ns: '1748175000000000000', log: logLine('2026-05-25 12:10:00', 'CS0007896', 'Incident Crew', 'Workflow failed') }],
  },
  {
    stream_labels: { agent: 'Change Crew', case_number: 'CS0007897', detected_level: 'info', level: 'info', service_name: 'digital-agent' },
    logs: [{ timestamp_ns: '1748175300000000000', log: logLine('2026-05-25 12:15:00', 'CS0007897', 'Change Crew', 'Workflow completed (Change branch)') }],
  },
  {
    stream_labels: { agent: 'Ticket approval Agent', case_number: 'CS0007898', detected_level: 'info', level: 'info', service_name: 'Digital-Agent' },
    logs: [{ timestamp_ns: '1748175600000000000', log: logLine('2026-05-25 12:20:00', 'CS0007898', 'Ticket approval Agent', 'Starting') }],
  },
  {
    stream_labels: { agent: 'Service Request Crew', case_number: 'CS0007899', detected_level: 'info', level: 'info', service_name: 'digital-agent' },
    logs: [{ timestamp_ns: '1748175900000000000', log: logLine('2026-05-25 12:25:00', 'CS0007899', 'Service Request Crew', 'Workflow completed (Service Request branch)') }],
  },
  {
    stream_labels: { agent: 'Incident Crew', case_number: 'CS0007900', detected_level: 'error', level: 'error', service_name: 'Digital-Agent' },
    logs: [{ timestamp_ns: '1748176200000000000', log: logLine('2026-05-25 12:30:00', 'CS0007900', 'Incident Crew', 'Workflow failed') }],
  },
  {
    stream_labels: { agent: 'Ticket approval Agent', case_number: 'CS0007901', detected_level: 'info', level: 'info', service_name: 'digital-agent' },
    logs: [{ timestamp_ns: '1748176500000000000', log: logLine('2026-05-25 12:35:00', 'CS0007901', 'Ticket approval Agent', 'Starting') }],
  },
];

// ---------------------------------------------------------------------------
// Handlers
// ---------------------------------------------------------------------------

export const handlers = [
  // Loki — log streams
  http.get(`${LOKI_BASE_URL}/query`, ({ request }) => {
    const url = new URL(request.url);
    const limit = Number(url.searchParams.get('limit') ?? 50);
    const streams = MOCK_STREAMS.slice(0, limit);

    const body: LokiQueryResponse = {
      success: true,
      message: 'Logs fetched successfully',
      data: {
        query: url.searchParams.get('logql') ?? '',
        total_streams: streams.length,
        total_logs: streams.length,
        streams,
      },
    };
    return HttpResponse.json(body);
  }),

  // Prometheus — individual PromQL queries (new format)
  http.get(`${PROMETHEUS_BASE_URL}/query`, ({ request }) => {
    const promql = new URL(request.url).searchParams.get('promql') ?? '';

    // Pick a mock scalar based on metric name keywords
    const pick = (): string => {
      if (promql.includes('chat_requests_total'))                return '52';
      if (promql.includes('chat_request_latency'))               return '0.77';
      if (promql.includes('total_tokens_input'))                 return '150000';
      if (promql.includes('total_tokens_output'))                return '50000';
      if (promql.includes('cpu_usage'))                          return '73';
      if (promql.includes('memory_usage'))                       return '9';
      if (promql.includes('accuracy_score'))                     return '24';
      if (promql.includes('Gauge AI Agent'))                     return '4';
      if (promql.includes('Incident Crew'))                      return '56';
      if (promql.includes('agent_processing_time'))              return '65';
      if (promql.includes('agent_interaction_count'))            return '56';
      if (promql.includes('task_completion'))                    return '65';
      return '1';
    };

    const body = {
      success: true,
      message: 'Prometheus query executed successfully',
      data: {
        query: promql,
        result_type: 'vector',
        results: [{ metric: {}, value: [Date.now() / 1000, pick()] }],
      },
    };
    return HttpResponse.json(body);
  }),
];
