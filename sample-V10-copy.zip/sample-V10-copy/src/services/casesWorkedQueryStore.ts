export const DEFAULT_CASES_LOKI_QUERY =
  '{service_name=~"Agentic-AI-IT-Operations|Azure-Wintel|Digital-Agent|digital-agent|wintel-agent|Linux-agent|aws-linux|db-agent|Wintel|azure-wintel|network-agent|aws-wintel"} | json | __error__=""';

export const DEFAULT_CASES_PROMETHEUS_QUERY =
  '{service_name=~"Agentic-AI-IT-Operations|Azure-Wintel|Digital-Agent|digital-agent|wintel-agent|Linux-agent|aws-linux|db-agent|Wintel|azure-wintel|network-agent|aws-wintel"}';

let _lokiQuery = DEFAULT_CASES_LOKI_QUERY;
let _prometheusQuery = DEFAULT_CASES_PROMETHEUS_QUERY;

export const getCasesLokiQuery = () => _lokiQuery;
export const getCasesPrometheusQuery = () => _prometheusQuery;

export const setCasesLokiQuery = (q: string) => { _lokiQuery = q; };
export const setCasesPrometheusQuery = (q: string) => { _prometheusQuery = q; };
