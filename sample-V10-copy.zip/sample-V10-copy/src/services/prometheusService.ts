import { prometheusApiClient } from './apiClient';
import { lokiApiClient } from './apiClient';
import type { PrometheusQueryResponse, AgentMetrics, InputTokenDataPoint, OutputTokenDataPoint } from '@/types/metrics';
import type { LokiQueryResponse } from '@/types/log';
import { getInputTokenPrometheusQuery, buildInputTokenQuery } from './inputTokenQueryStore';
import { getWarningsLokiQuery, buildWarningsQuery } from './warningsQueryStore';
import { getErrorsLokiQuery, buildErrorsQuery } from './errorsQueryStore';
import { getCostPerQueryPrometheusQuery, buildCostPerQuery } from './costPerQueryQueryStore';
import { getCpuUsagePrometheusQuery, buildCpuUsageQuery } from './cpuUsageQueryStore';
import { getMemoryUsagePrometheusQuery, buildMemoryUsageQuery } from './memoryUsageQueryStore';
import { getAccuracyScorePrometheusQuery, buildAccuracyScoreQuery } from './accuracyScoreQueryStore';
import { getAiChatRequestPrometheusQuery, buildAiChatRequestQuery } from './aiChatRequestQueryStore';
import { getAvgLatencyPrometheusQuery, buildAvgLatencyQuery } from './avgLatencyQueryStore';

// ---------------------------------------------------------------------------
// Low-level helpers
// ---------------------------------------------------------------------------

/** Send a PromQL expression, return the sum of all result values.
 *  Returns 0 on failure unless throwOnError is true (used by edit-page Run Query). */
export const executePrometheusQuery = async (
  promql: string,
  throwOnError = false,
): Promise<number> => {
  try {
    const response = await prometheusApiClient.get<PrometheusQueryResponse>('/query', {
      params: { promql },
    });
    const results = response.data?.results ?? [];
    if (results.length === 0) return 0;
    return results.reduce((sum, r) => {
      const v = parseFloat(r.value?.[1] ?? '0');
      return sum + (isFinite(v) ? v : 0);
    }, 0);
  } catch (err) {
    if (throwOnError) throw err;
    return 0;
  }
};

/** Count log lines matching a LogQL filter via the Loki query endpoint.
 *  Returns 0 on failure unless throwOnError is true (used by edit-page Run Query). */
export const executeLokiQuery = async (
  logql: string,
  lookbackSeconds = 3600,
  throwOnError = false,
): Promise<number> => {
  try {
    const response = await lokiApiClient.get<LokiQueryResponse>('/query', {
      params: { logql, lookback_seconds: lookbackSeconds, limit: 200, direction: 'backward' },
    });
    const streams = response.data?.streams ?? [];
    return streams.reduce((total, s) => total + s.logs.length, 0);
  } catch (err) {
    if (throwOnError) throw err;
    return 0;
  }
};

// ---------------------------------------------------------------------------
// Static chart data (per-platform / per-month breakdown — representative)
// ---------------------------------------------------------------------------

const DEFAULT_INPUT_TOKENS: InputTokenDataPoint[] = [
  { platform: 'Linux',   value: 28000 },
  { platform: 'Mac',     value: 20000 },
  { platform: 'iOS',     value: 12000 },
  { platform: 'Windows', value: 30000 },
  { platform: 'Android', value: 15000 },
  { platform: 'Other',   value: 22000 },
];

const DEFAULT_OUTPUT_TOKENS: OutputTokenDataPoint[] = [
  { month: 'Jan', value: 4000  },
  { month: 'Feb', value: 7500  },
  { month: 'Mar', value: 5200  },
  { month: 'Apr', value: 11000 },
  { month: 'May', value: 9000  },
  { month: 'Jun', value: 15500 },
];

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------

/**
 * Fetch all KPI metrics for a given agent + ticket in parallel.
 * Each individual query degrades to 0 if unreachable, so the page always renders.
 */
export const fetchAllTicketMetrics = async (
  agentName: string,
  ticketNumber: string,
  lookbackSeconds = 3600,
): Promise<AgentMetrics> => {
  const ag = agentName;
  const tk = ticketNumber;

  // Loki log-count queries for warning / error KPIs (driven by configurable query stores)
  const warningsLogQL = buildWarningsQuery(getWarningsLokiQuery(), ag, tk);
  const errorsLogQL   = buildErrorsQuery(getErrorsLokiQuery(), ag, tk);

  const [
    warnings,
    errors,
    aiChatRequests,
    avgLatencyRaw,
    costUsd,
    cpuRaw,
    memRaw,
    accuracyScore,
    procTime1Raw,
    procTime2Raw,
    procTime3Raw,
    messagesPerTask,
    tasksCompleted,
    avgInputTokens,
  ] = await Promise.all([
    // Warnings & errors come from Loki
    executeLokiQuery(warningsLogQL, lookbackSeconds),
    executeLokiQuery(errorsLogQL, lookbackSeconds),

    // Prometheus scalars — driven by configurable query stores
    executePrometheusQuery(buildAiChatRequestQuery(getAiChatRequestPrometheusQuery(), ag, tk)),
    executePrometheusQuery(buildAvgLatencyQuery(getAvgLatencyPrometheusQuery(), ag, tk)),
    // cost, cpu, memory, accuracy driven by configurable query stores
    executePrometheusQuery(buildCostPerQuery(getCostPerQueryPrometheusQuery(), ag, tk)),
    executePrometheusQuery(buildCpuUsageQuery(getCpuUsagePrometheusQuery(), ag, tk)),
    executePrometheusQuery(buildMemoryUsageQuery(getMemoryUsagePrometheusQuery(), ag, tk)),
    executePrometheusQuery(buildAccuracyScoreQuery(getAccuracyScorePrometheusQuery(), ag, tk)),

    // Processing time per sub-agent (ms → secs)
    executePrometheusQuery(
      `sum(agent_processing_time_ms_milliseconds_sum{agent="Gauge AI Agent", case_number="${tk}"})` +
      ` / sum(agent_processing_time_ms_milliseconds_count{agent="Gauge AI Agent", case_number="${tk}"}) / 1000`,
    ),
    executePrometheusQuery(
      `sum(agent_processing_time_ms_milliseconds_sum{agent="Incident Crew", case_number="${tk}"})` +
      ` / sum(agent_processing_time_ms_milliseconds_count{agent="Incident Crew", case_number="${tk}"}) / 1000`,
    ),
    executePrometheusQuery(
      `sum(agent_processing_time_ms_milliseconds_sum{agent="Ticket Approval Agent", case_number="${tk}"})` +
      ` / sum(agent_processing_time_ms_milliseconds_count{agent="Ticket Approval Agent", case_number="${tk}"}) / 1000`,
    ),

    executePrometheusQuery(`sum(agent_interaction_count_messages_count{agent="${ag}", case_number="${tk}"})`),
    executePrometheusQuery(`sum(task_completion_total{agent="${ag}", case_number="${tk}"})`),

    // Input token avg — driven by the configurable store query
    executePrometheusQuery(buildInputTokenQuery(getInputTokenPrometheusQuery(), ag, tk)),
  ]);

  const safe = (v: number) => (isFinite(v) ? v : 0);

  return {
    warnings,
    errors,
    aiChatRequests:  Math.round(aiChatRequests),
    avgLatencyMs:    safe(avgLatencyRaw),
    costUsd:         safe(costUsd),
    cpuUsage:        Math.round(safe(cpuRaw)),
    memoryUsage:     Math.round(safe(memRaw)),
    accuracyScore:   Math.round(accuracyScore),
    processingTime1: Math.round(safe(procTime1Raw)),
    processingTime2: Math.round(safe(procTime2Raw)),
    processingTime3: Math.round(safe(procTime3Raw)),
    messagesPerTask: Math.round(messagesPerTask),
    tasksCompleted:  Math.round(tasksCompleted),
    totalInputTokens: 0,
    avgInputTokens:  Math.round(safe(avgInputTokens)),
    inputTokensData:  DEFAULT_INPUT_TOKENS,
    outputTokensData: DEFAULT_OUTPUT_TOKENS,
  };
};

/** Backward-compatible alias — keeps the existing call site in TicketDetailsPage working. */
export const fetchAgentMetrics = fetchAllTicketMetrics;

/**
 * Fetch all KPI metrics for an agent dashboard (no ticket filter).
 * Used by AgentDetailsPage — queries cover the full agent across all cases.
 */
export const fetchAgentDashboardMetrics = async (
  agentName: string,
  lookbackSeconds = 3600,
): Promise<AgentMetrics> => {
  const ag = agentName;

  const warningsLogQL = buildWarningsQuery(getWarningsLokiQuery(), ag);
  const errorsLogQL   = buildErrorsQuery(getErrorsLokiQuery(), ag);

  const [
    warnings,
    errors,
    aiChatRequests,
    avgLatencyRaw,
    costUsd,
    cpuRaw,
    memRaw,
    accuracyScore,
    procTime1Raw,
    procTime2Raw,
    procTime3Raw,
    messagesPerTask,
    tasksCompleted,
    totalInputTokensRaw,
  ] = await Promise.all([
    executeLokiQuery(warningsLogQL, lookbackSeconds),
    executeLokiQuery(errorsLogQL, lookbackSeconds),
    executePrometheusQuery(`sum(chat_requests_total{agent="${ag}"})`),
    executePrometheusQuery(
      `sum(chat_request_latency_ms_milliseconds_sum)` +
      ` / sum(chat_request_latency_ms_milliseconds_count)`,
    ),
    // cost, cpu, memory, accuracy driven by configurable query stores
    executePrometheusQuery(buildCostPerQuery(getCostPerQueryPrometheusQuery(), ag)),
    executePrometheusQuery(buildCpuUsageQuery(getCpuUsagePrometheusQuery(), ag)),
    executePrometheusQuery(buildMemoryUsageQuery(getMemoryUsagePrometheusQuery(), ag)),
    executePrometheusQuery(buildAccuracyScoreQuery(getAccuracyScorePrometheusQuery(), ag)),
    executePrometheusQuery(
      `sum(agent_processing_time_ms_milliseconds_sum{agent="Gauge AI Agent"})` +
      ` / sum(agent_processing_time_ms_milliseconds_count{agent="Gauge AI Agent"}) / 1000`,
    ),
    executePrometheusQuery(
      `sum(agent_processing_time_ms_milliseconds_sum{agent="Incident Crew"})` +
      ` / sum(agent_processing_time_ms_milliseconds_count{agent="Incident Crew"}) / 1000`,
    ),
    executePrometheusQuery(
      `sum(agent_processing_time_ms_milliseconds_sum{agent="Ticket Approval Agent"})` +
      ` / sum(agent_processing_time_ms_milliseconds_count{agent="Ticket Approval Agent"}) / 1000`,
    ),
    executePrometheusQuery(`sum(agent_interaction_count_messages_count{agent="${ag}"})`),
    executePrometheusQuery(`sum(task_completion_total{agent="${ag}"})`),

    // Real total input tokens for this agent across all tickets
    executePrometheusQuery(`sum(last_over_time(token_usage_input_tokens_total{exported_job="${ag}"}[${lookbackSeconds}s]))`),
  ]);

  const safe = (v: number) => (isFinite(v) ? v : 0);

  return {
    warnings,
    errors,
    aiChatRequests:  Math.round(aiChatRequests),
    avgLatencyMs:    safe(avgLatencyRaw),
    costUsd:         safe(costUsd),
    cpuUsage:        Math.round(safe(cpuRaw)),
    memoryUsage:     Math.round(safe(memRaw)),
    accuracyScore:   Math.round(accuracyScore),
    processingTime1: Math.round(safe(procTime1Raw)),
    processingTime2: Math.round(safe(procTime2Raw)),
    processingTime3: Math.round(safe(procTime3Raw)),
    messagesPerTask: Math.round(messagesPerTask),
    tasksCompleted:  Math.round(tasksCompleted),
    totalInputTokens: Math.round(safe(totalInputTokensRaw)),
    avgInputTokens:  0,
    inputTokensData:  DEFAULT_INPUT_TOKENS,
    outputTokensData: DEFAULT_OUTPUT_TOKENS,
  };
};
